--
-- PostgreSQL database dump
--

\restrict zdPYBqGuzQMiHkwqkjrhEJzb6sddeA9icZNdtOnGkzlflcWIKVzSftOn5NGuFF1

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

-- Started on 2026-01-23 12:27:19 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_role_id_fkey;
ALTER TABLE IF EXISTS ONLY public.system_configurations DROP CONSTRAINT IF EXISTS system_configurations_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.system_configurations DROP CONSTRAINT IF EXISTS system_configurations_config_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.rate_profiles DROP CONSTRAINT IF EXISTS rate_profiles_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.rate_profiles DROP CONSTRAINT IF EXISTS rate_profiles_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_marked_by_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_loan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_cut_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payment_status_history DROP CONSTRAINT IF EXISTS payment_status_history_payment_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payment_status_history DROP CONSTRAINT IF EXISTS payment_status_history_old_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payment_status_history DROP CONSTRAINT IF EXISTS payment_status_history_new_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payment_status_history DROP CONSTRAINT IF EXISTS payment_status_history_changed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.loans DROP CONSTRAINT IF EXISTS loans_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.loans DROP CONSTRAINT IF EXISTS loans_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.loans DROP CONSTRAINT IF EXISTS loans_rejected_by_fkey;
ALTER TABLE IF EXISTS ONLY public.loans DROP CONSTRAINT IF EXISTS loans_associate_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.loans DROP CONSTRAINT IF EXISTS loans_approved_by_fkey;
ALTER TABLE IF EXISTS ONLY public.loan_renewals DROP CONSTRAINT IF EXISTS loan_renewals_renewed_loan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.loan_renewals DROP CONSTRAINT IF EXISTS loan_renewals_original_loan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.loan_renewals DROP CONSTRAINT IF EXISTS loan_renewals_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.legacy_payment_table DROP CONSTRAINT IF EXISTS legacy_payment_table_updated_by_fkey;
ALTER TABLE IF EXISTS ONLY public.legacy_payment_table DROP CONSTRAINT IF EXISTS legacy_payment_table_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.guarantors DROP CONSTRAINT IF EXISTS guarantors_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.guarantors DROP CONSTRAINT IF EXISTS guarantors_relationship_id_fkey;
ALTER TABLE IF EXISTS ONLY public.loans DROP CONSTRAINT IF EXISTS fk_loans_profile_code;
ALTER TABLE IF EXISTS ONLY public.loans DROP CONSTRAINT IF EXISTS fk_loans_contract_id;
ALTER TABLE IF EXISTS ONLY public.defaulted_client_reports DROP CONSTRAINT IF EXISTS defaulted_client_reports_reported_by_fkey;
ALTER TABLE IF EXISTS ONLY public.defaulted_client_reports DROP CONSTRAINT IF EXISTS defaulted_client_reports_loan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.defaulted_client_reports DROP CONSTRAINT IF EXISTS defaulted_client_reports_client_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.defaulted_client_reports DROP CONSTRAINT IF EXISTS defaulted_client_reports_associate_profile_id_fkey;
ALTER TABLE IF EXISTS ONLY public.defaulted_client_reports DROP CONSTRAINT IF EXISTS defaulted_client_reports_approved_by_fkey;
ALTER TABLE IF EXISTS ONLY public.cut_periods DROP CONSTRAINT IF EXISTS cut_periods_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.cut_periods DROP CONSTRAINT IF EXISTS cut_periods_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.cut_periods DROP CONSTRAINT IF EXISTS cut_periods_closed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_loan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.client_documents DROP CONSTRAINT IF EXISTS client_documents_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.client_documents DROP CONSTRAINT IF EXISTS client_documents_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.client_documents DROP CONSTRAINT IF EXISTS client_documents_reviewed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.client_documents DROP CONSTRAINT IF EXISTS client_documents_document_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.beneficiaries DROP CONSTRAINT IF EXISTS beneficiaries_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.beneficiaries DROP CONSTRAINT IF EXISTS beneficiaries_relationship_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_session_log DROP CONSTRAINT IF EXISTS audit_session_log_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_changed_by_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_statement_payments DROP CONSTRAINT IF EXISTS associate_statement_payments_statement_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_statement_payments DROP CONSTRAINT IF EXISTS associate_statement_payments_registered_by_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_statement_payments DROP CONSTRAINT IF EXISTS associate_statement_payments_payment_method_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_profiles DROP CONSTRAINT IF EXISTS associate_profiles_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_profiles DROP CONSTRAINT IF EXISTS associate_profiles_level_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_payment_statements DROP CONSTRAINT IF EXISTS associate_payment_statements_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_payment_statements DROP CONSTRAINT IF EXISTS associate_payment_statements_status_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_payment_statements DROP CONSTRAINT IF EXISTS associate_payment_statements_payment_method_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_payment_statements DROP CONSTRAINT IF EXISTS associate_payment_statements_cut_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_level_history DROP CONSTRAINT IF EXISTS associate_level_history_old_level_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_level_history DROP CONSTRAINT IF EXISTS associate_level_history_new_level_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_level_history DROP CONSTRAINT IF EXISTS associate_level_history_change_type_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_level_history DROP CONSTRAINT IF EXISTS associate_level_history_associate_profile_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_debt_payments DROP CONSTRAINT IF EXISTS associate_debt_payments_registered_by_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_debt_payments DROP CONSTRAINT IF EXISTS associate_debt_payments_payment_method_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_debt_payments DROP CONSTRAINT IF EXISTS associate_debt_payments_associate_profile_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_debt_breakdown DROP CONSTRAINT IF EXISTS associate_debt_breakdown_loan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_debt_breakdown DROP CONSTRAINT IF EXISTS associate_debt_breakdown_cut_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_debt_breakdown DROP CONSTRAINT IF EXISTS associate_debt_breakdown_client_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_debt_breakdown DROP CONSTRAINT IF EXISTS associate_debt_breakdown_associate_profile_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_accumulated_balances DROP CONSTRAINT IF EXISTS associate_accumulated_balances_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.associate_accumulated_balances DROP CONSTRAINT IF EXISTS associate_accumulated_balances_cut_period_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agreements DROP CONSTRAINT IF EXISTS agreements_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.agreements DROP CONSTRAINT IF EXISTS agreements_associate_profile_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agreements DROP CONSTRAINT IF EXISTS agreements_approved_by_fkey;
ALTER TABLE IF EXISTS ONLY public.agreement_payments DROP CONSTRAINT IF EXISTS agreement_payments_payment_method_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agreement_payments DROP CONSTRAINT IF EXISTS agreement_payments_agreement_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agreement_items DROP CONSTRAINT IF EXISTS agreement_items_loan_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agreement_items DROP CONSTRAINT IF EXISTS agreement_items_client_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.agreement_items DROP CONSTRAINT IF EXISTS agreement_items_agreement_id_fkey;
ALTER TABLE IF EXISTS ONLY public.addresses DROP CONSTRAINT IF EXISTS addresses_user_id_fkey;
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
DROP TRIGGER IF EXISTS update_system_configurations_updated_at ON public.system_configurations;
DROP TRIGGER IF EXISTS update_statement_statuses_updated_at ON public.statement_statuses;
DROP TRIGGER IF EXISTS update_payments_updated_at ON public.payments;
DROP TRIGGER IF EXISTS update_payment_methods_updated_at ON public.payment_methods;
DROP TRIGGER IF EXISTS update_loans_updated_at ON public.loans;
DROP TRIGGER IF EXISTS update_loan_statuses_updated_at ON public.loan_statuses;
DROP TRIGGER IF EXISTS update_level_change_types_updated_at ON public.level_change_types;
DROP TRIGGER IF EXISTS update_guarantors_updated_at ON public.guarantors;
DROP TRIGGER IF EXISTS update_document_statuses_updated_at ON public.document_statuses;
DROP TRIGGER IF EXISTS update_cut_periods_updated_at ON public.cut_periods;
DROP TRIGGER IF EXISTS update_cut_period_statuses_updated_at ON public.cut_period_statuses;
DROP TRIGGER IF EXISTS update_contracts_updated_at ON public.contracts;
DROP TRIGGER IF EXISTS update_contract_statuses_updated_at ON public.contract_statuses;
DROP TRIGGER IF EXISTS update_config_types_updated_at ON public.config_types;
DROP TRIGGER IF EXISTS update_client_documents_updated_at ON public.client_documents;
DROP TRIGGER IF EXISTS update_beneficiaries_updated_at ON public.beneficiaries;
DROP TRIGGER IF EXISTS update_associate_statement_payments_updated_at ON public.associate_statement_payments;
DROP TRIGGER IF EXISTS update_associate_profiles_updated_at ON public.associate_profiles;
DROP TRIGGER IF EXISTS update_associate_payment_statements_updated_at ON public.associate_payment_statements;
DROP TRIGGER IF EXISTS update_associate_debt_payments_updated_at ON public.associate_debt_payments;
DROP TRIGGER IF EXISTS update_addresses_updated_at ON public.addresses;
DROP TRIGGER IF EXISTS trigger_update_statement_on_payment ON public.associate_statement_payments;
DROP TRIGGER IF EXISTS trigger_update_credit_on_payment ON public.payments;
DROP TRIGGER IF EXISTS trigger_update_credit_on_loan_delete ON public.loans;
DROP TRIGGER IF EXISTS trigger_update_credit_on_loan_cancel ON public.loans;
DROP TRIGGER IF EXISTS trigger_update_associate_credit_on_loan_approval ON public.loans;
DROP TRIGGER IF EXISTS trigger_update_associate_credit_on_level_change ON public.associate_profiles;
DROP TRIGGER IF EXISTS trigger_log_payment_status_change ON public.payments;
DROP TRIGGER IF EXISTS trigger_legacy_payment_table_updated_at ON public.legacy_payment_table;
DROP TRIGGER IF EXISTS trigger_generate_payment_schedule ON public.loans;
DROP TRIGGER IF EXISTS handle_loan_approval_trigger ON public.loans;
DROP TRIGGER IF EXISTS audit_users_trigger ON public.users;
DROP TRIGGER IF EXISTS audit_payments_trigger ON public.payments;
DROP TRIGGER IF EXISTS audit_loans_trigger ON public.loans;
DROP TRIGGER IF EXISTS audit_cut_periods_trigger ON public.cut_periods;
DROP TRIGGER IF EXISTS audit_contracts_trigger ON public.contracts;
DROP INDEX IF EXISTS public.idx_users_username_lower;
DROP INDEX IF EXISTS public.idx_users_email_lower;
DROP INDEX IF EXISTS public.idx_users_active;
DROP INDEX IF EXISTS public.idx_statement_statuses_name;
DROP INDEX IF EXISTS public.idx_statement_payments_statement_id;
DROP INDEX IF EXISTS public.idx_statement_payments_statement_amount;
DROP INDEX IF EXISTS public.idx_statement_payments_registered_by;
DROP INDEX IF EXISTS public.idx_statement_payments_payment_date;
DROP INDEX IF EXISTS public.idx_statement_payments_method;
DROP INDEX IF EXISTS public.idx_session_log_user_id;
DROP INDEX IF EXISTS public.idx_session_log_login_at;
DROP INDEX IF EXISTS public.idx_session_log_is_active;
DROP INDEX IF EXISTS public.idx_rate_profiles_enabled;
DROP INDEX IF EXISTS public.idx_rate_profiles_display;
DROP INDEX IF EXISTS public.idx_rate_profiles_code;
DROP INDEX IF EXISTS public.idx_payments_status_id;
DROP INDEX IF EXISTS public.idx_payments_payment_number;
DROP INDEX IF EXISTS public.idx_payments_payment_due_date;
DROP INDEX IF EXISTS public.idx_payments_loan_number_unique;
DROP INDEX IF EXISTS public.idx_payments_loan_id;
DROP INDEX IF EXISTS public.idx_payments_late_loan;
DROP INDEX IF EXISTS public.idx_payments_is_late;
DROP INDEX IF EXISTS public.idx_payments_expected_amount;
DROP INDEX IF EXISTS public.idx_payments_due_date_status_expected;
DROP INDEX IF EXISTS public.idx_payments_cut_period_id;
DROP INDEX IF EXISTS public.idx_payments_balance_remaining;
DROP INDEX IF EXISTS public.idx_payment_statuses_name;
DROP INDEX IF EXISTS public.idx_payment_statuses_is_real;
DROP INDEX IF EXISTS public.idx_payment_statuses_active;
DROP INDEX IF EXISTS public.idx_payment_status_history_payment_id;
DROP INDEX IF EXISTS public.idx_payment_status_history_payment_changed_at;
DROP INDEX IF EXISTS public.idx_payment_status_history_new_status_id;
DROP INDEX IF EXISTS public.idx_payment_status_history_changed_by;
DROP INDEX IF EXISTS public.idx_payment_status_history_changed_at;
DROP INDEX IF EXISTS public.idx_payment_status_history_change_type;
DROP INDEX IF EXISTS public.idx_payment_methods_name;
DROP INDEX IF EXISTS public.idx_loans_user_id;
DROP INDEX IF EXISTS public.idx_loans_total_payment;
DROP INDEX IF EXISTS public.idx_loans_status_id_approved_at;
DROP INDEX IF EXISTS public.idx_loans_status_id;
DROP INDEX IF EXISTS public.idx_loans_profile_code_biweekly;
DROP INDEX IF EXISTS public.idx_loans_biweekly_payment;
DROP INDEX IF EXISTS public.idx_loans_associate_user_id;
DROP INDEX IF EXISTS public.idx_loans_approved_at;
DROP INDEX IF EXISTS public.idx_loan_statuses_name;
DROP INDEX IF EXISTS public.idx_loan_statuses_active;
DROP INDEX IF EXISTS public.idx_loan_renewals_renewed_loan_id;
DROP INDEX IF EXISTS public.idx_loan_renewals_original_loan_id;
DROP INDEX IF EXISTS public.idx_level_change_types_name;
DROP INDEX IF EXISTS public.idx_legacy_term;
DROP INDEX IF EXISTS public.idx_legacy_amount_term_unique;
DROP INDEX IF EXISTS public.idx_legacy_amount;
DROP INDEX IF EXISTS public.idx_guarantors_relationship_id;
DROP INDEX IF EXISTS public.idx_document_statuses_name;
DROP INDEX IF EXISTS public.idx_defaulted_reports_status;
DROP INDEX IF EXISTS public.idx_defaulted_reports_reported_at;
DROP INDEX IF EXISTS public.idx_defaulted_reports_loan_id;
DROP INDEX IF EXISTS public.idx_defaulted_reports_client_user_id;
DROP INDEX IF EXISTS public.idx_defaulted_reports_associate_profile_id;
DROP INDEX IF EXISTS public.idx_debt_payments_registered_by;
DROP INDEX IF EXISTS public.idx_debt_payments_payment_date;
DROP INDEX IF EXISTS public.idx_debt_payments_method;
DROP INDEX IF EXISTS public.idx_debt_payments_associate_id;
DROP INDEX IF EXISTS public.idx_debt_payments_associate_date;
DROP INDEX IF EXISTS public.idx_debt_payments_applied_items;
DROP INDEX IF EXISTS public.idx_debt_breakdown_is_liquidated;
DROP INDEX IF EXISTS public.idx_debt_breakdown_associate;
DROP INDEX IF EXISTS public.idx_cut_periods_status_id;
DROP INDEX IF EXISTS public.idx_cut_periods_dates;
DROP INDEX IF EXISTS public.idx_cut_periods_cut_code;
DROP INDEX IF EXISTS public.idx_cut_periods_active;
DROP INDEX IF EXISTS public.idx_cut_period_statuses_name;
DROP INDEX IF EXISTS public.idx_contracts_loan_id;
DROP INDEX IF EXISTS public.idx_contracts_document_number;
DROP INDEX IF EXISTS public.idx_contract_statuses_name;
DROP INDEX IF EXISTS public.idx_config_types_name;
DROP INDEX IF EXISTS public.idx_client_documents_user_id;
DROP INDEX IF EXISTS public.idx_client_documents_status_id;
DROP INDEX IF EXISTS public.idx_beneficiaries_relationship_id;
DROP INDEX IF EXISTS public.idx_audit_log_table_record;
DROP INDEX IF EXISTS public.idx_audit_log_operation;
DROP INDEX IF EXISTS public.idx_audit_log_changed_by;
DROP INDEX IF EXISTS public.idx_audit_log_changed_at;
DROP INDEX IF EXISTS public.idx_associate_profiles_user_id;
DROP INDEX IF EXISTS public.idx_associate_profiles_level_id;
DROP INDEX IF EXISTS public.idx_associate_profiles_credit_used;
DROP INDEX IF EXISTS public.idx_associate_profiles_active;
DROP INDEX IF EXISTS public.idx_agreements_status;
DROP INDEX IF EXISTS public.idx_agreements_associate_profile_id;
DROP INDEX IF EXISTS public.idx_agreement_payments_status;
DROP INDEX IF EXISTS public.idx_agreement_payments_agreement_id;
DROP INDEX IF EXISTS public.idx_agreement_items_loan_id;
DROP INDEX IF EXISTS public.idx_agreement_items_agreement_id;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_phone_number_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_curp_key;
ALTER TABLE IF EXISTS ONLY public.user_roles DROP CONSTRAINT IF EXISTS user_roles_pkey;
ALTER TABLE IF EXISTS ONLY public.rate_profile_reference_table DROP CONSTRAINT IF EXISTS uq_profile_amount_term;
ALTER TABLE IF EXISTS ONLY public.legacy_payment_table DROP CONSTRAINT IF EXISTS uq_legacy_amount_term;
ALTER TABLE IF EXISTS ONLY public.system_configurations DROP CONSTRAINT IF EXISTS system_configurations_pkey;
ALTER TABLE IF EXISTS ONLY public.system_configurations DROP CONSTRAINT IF EXISTS system_configurations_config_key_key;
ALTER TABLE IF EXISTS ONLY public.statement_statuses DROP CONSTRAINT IF EXISTS statement_statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.statement_statuses DROP CONSTRAINT IF EXISTS statement_statuses_name_key;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_pkey;
ALTER TABLE IF EXISTS ONLY public.roles DROP CONSTRAINT IF EXISTS roles_name_key;
ALTER TABLE IF EXISTS ONLY public.relationships DROP CONSTRAINT IF EXISTS relationships_pkey;
ALTER TABLE IF EXISTS ONLY public.relationships DROP CONSTRAINT IF EXISTS relationships_name_key;
ALTER TABLE IF EXISTS ONLY public.rate_profiles DROP CONSTRAINT IF EXISTS rate_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.rate_profiles DROP CONSTRAINT IF EXISTS rate_profiles_code_key;
ALTER TABLE IF EXISTS ONLY public.rate_profile_reference_table DROP CONSTRAINT IF EXISTS rate_profile_reference_table_pkey;
ALTER TABLE IF EXISTS ONLY public.payments DROP CONSTRAINT IF EXISTS payments_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_statuses DROP CONSTRAINT IF EXISTS payment_statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_statuses DROP CONSTRAINT IF EXISTS payment_statuses_name_key;
ALTER TABLE IF EXISTS ONLY public.payment_status_history DROP CONSTRAINT IF EXISTS payment_status_history_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_methods DROP CONSTRAINT IF EXISTS payment_methods_pkey;
ALTER TABLE IF EXISTS ONLY public.payment_methods DROP CONSTRAINT IF EXISTS payment_methods_name_key;
ALTER TABLE IF EXISTS ONLY public.loans DROP CONSTRAINT IF EXISTS loans_pkey;
ALTER TABLE IF EXISTS ONLY public.loan_statuses DROP CONSTRAINT IF EXISTS loan_statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.loan_statuses DROP CONSTRAINT IF EXISTS loan_statuses_name_key;
ALTER TABLE IF EXISTS ONLY public.loan_renewals DROP CONSTRAINT IF EXISTS loan_renewals_pkey;
ALTER TABLE IF EXISTS ONLY public.level_change_types DROP CONSTRAINT IF EXISTS level_change_types_pkey;
ALTER TABLE IF EXISTS ONLY public.level_change_types DROP CONSTRAINT IF EXISTS level_change_types_name_key;
ALTER TABLE IF EXISTS ONLY public.legacy_payment_table DROP CONSTRAINT IF EXISTS legacy_payment_table_pkey;
ALTER TABLE IF EXISTS ONLY public.guarantors DROP CONSTRAINT IF EXISTS guarantors_user_id_key;
ALTER TABLE IF EXISTS ONLY public.guarantors DROP CONSTRAINT IF EXISTS guarantors_pkey;
ALTER TABLE IF EXISTS ONLY public.guarantors DROP CONSTRAINT IF EXISTS guarantors_curp_key;
ALTER TABLE IF EXISTS ONLY public.document_types DROP CONSTRAINT IF EXISTS document_types_pkey;
ALTER TABLE IF EXISTS ONLY public.document_types DROP CONSTRAINT IF EXISTS document_types_name_key;
ALTER TABLE IF EXISTS ONLY public.document_statuses DROP CONSTRAINT IF EXISTS document_statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.document_statuses DROP CONSTRAINT IF EXISTS document_statuses_name_key;
ALTER TABLE IF EXISTS ONLY public.defaulted_client_reports DROP CONSTRAINT IF EXISTS defaulted_client_reports_pkey;
ALTER TABLE IF EXISTS ONLY public.cut_periods DROP CONSTRAINT IF EXISTS cut_periods_pkey;
ALTER TABLE IF EXISTS ONLY public.cut_periods DROP CONSTRAINT IF EXISTS cut_periods_cut_code_key;
ALTER TABLE IF EXISTS ONLY public.cut_period_statuses DROP CONSTRAINT IF EXISTS cut_period_statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.cut_period_statuses DROP CONSTRAINT IF EXISTS cut_period_statuses_name_key;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_pkey;
ALTER TABLE IF EXISTS ONLY public.contracts DROP CONSTRAINT IF EXISTS contracts_document_number_key;
ALTER TABLE IF EXISTS ONLY public.contract_statuses DROP CONSTRAINT IF EXISTS contract_statuses_pkey;
ALTER TABLE IF EXISTS ONLY public.contract_statuses DROP CONSTRAINT IF EXISTS contract_statuses_name_key;
ALTER TABLE IF EXISTS ONLY public.config_types DROP CONSTRAINT IF EXISTS config_types_pkey;
ALTER TABLE IF EXISTS ONLY public.config_types DROP CONSTRAINT IF EXISTS config_types_name_key;
ALTER TABLE IF EXISTS ONLY public.client_documents DROP CONSTRAINT IF EXISTS client_documents_pkey;
ALTER TABLE IF EXISTS ONLY public.beneficiaries DROP CONSTRAINT IF EXISTS beneficiaries_user_id_key;
ALTER TABLE IF EXISTS ONLY public.beneficiaries DROP CONSTRAINT IF EXISTS beneficiaries_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_session_log DROP CONSTRAINT IF EXISTS audit_session_log_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_log DROP CONSTRAINT IF EXISTS audit_log_pkey;
ALTER TABLE IF EXISTS ONLY public.associate_statement_payments DROP CONSTRAINT IF EXISTS associate_statement_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.associate_profiles DROP CONSTRAINT IF EXISTS associate_profiles_user_id_key;
ALTER TABLE IF EXISTS ONLY public.associate_profiles DROP CONSTRAINT IF EXISTS associate_profiles_pkey;
ALTER TABLE IF EXISTS ONLY public.associate_profiles DROP CONSTRAINT IF EXISTS associate_profiles_contact_email_key;
ALTER TABLE IF EXISTS ONLY public.associate_payment_statements DROP CONSTRAINT IF EXISTS associate_payment_statements_pkey;
ALTER TABLE IF EXISTS ONLY public.associate_levels DROP CONSTRAINT IF EXISTS associate_levels_pkey;
ALTER TABLE IF EXISTS ONLY public.associate_levels DROP CONSTRAINT IF EXISTS associate_levels_name_key;
ALTER TABLE IF EXISTS ONLY public.associate_level_history DROP CONSTRAINT IF EXISTS associate_level_history_pkey;
ALTER TABLE IF EXISTS ONLY public.associate_debt_payments DROP CONSTRAINT IF EXISTS associate_debt_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.associate_debt_breakdown DROP CONSTRAINT IF EXISTS associate_debt_breakdown_pkey;
ALTER TABLE IF EXISTS ONLY public.associate_accumulated_balances DROP CONSTRAINT IF EXISTS associate_accumulated_balances_user_id_cut_period_id_key;
ALTER TABLE IF EXISTS ONLY public.associate_accumulated_balances DROP CONSTRAINT IF EXISTS associate_accumulated_balances_pkey;
ALTER TABLE IF EXISTS ONLY public.agreements DROP CONSTRAINT IF EXISTS agreements_pkey;
ALTER TABLE IF EXISTS ONLY public.agreements DROP CONSTRAINT IF EXISTS agreements_agreement_number_key;
ALTER TABLE IF EXISTS ONLY public.agreement_payments DROP CONSTRAINT IF EXISTS agreement_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.agreement_items DROP CONSTRAINT IF EXISTS agreement_items_pkey;
ALTER TABLE IF EXISTS ONLY public.addresses DROP CONSTRAINT IF EXISTS addresses_user_id_key;
ALTER TABLE IF EXISTS ONLY public.addresses DROP CONSTRAINT IF EXISTS addresses_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.system_configurations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.statement_statuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.roles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.relationships ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rate_profiles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.rate_profile_reference_table ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.payments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.payment_statuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.payment_status_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.payment_methods ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.loans ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.loan_statuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.loan_renewals ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.level_change_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.legacy_payment_table ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.guarantors ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.document_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.document_statuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.defaulted_client_reports ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cut_periods ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.cut_period_statuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contracts ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contract_statuses ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.config_types ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.client_documents ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.beneficiaries ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_session_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.audit_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.associate_statement_payments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.associate_profiles ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.associate_payment_statements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.associate_levels ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.associate_level_history ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.associate_debt_payments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.associate_debt_breakdown ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.associate_accumulated_balances ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.agreements ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.agreement_payments ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.agreement_items ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.addresses ALTER COLUMN id DROP DEFAULT;
DROP VIEW IF EXISTS public.v_statement_payment_history;
DROP VIEW IF EXISTS public.v_recent_payment_changes;
DROP VIEW IF EXISTS public.v_rate_reference_12q;
DROP VIEW IF EXISTS public.v_period_closure_summary;
DROP VIEW IF EXISTS public.v_payments_summary;
DROP VIEW IF EXISTS public.v_payments_multiple_changes;
DROP VIEW IF EXISTS public.v_payments_by_status_detailed;
DROP VIEW IF EXISTS public.v_payments_absorbed_by_associate;
DROP VIEW IF EXISTS public.v_payment_changes_summary;
DROP VIEW IF EXISTS public.v_loans_summary;
DROP VIEW IF EXISTS public.v_cut_periods_readable;
DROP VIEW IF EXISTS public.v_associate_real_debt_summary;
DROP VIEW IF EXISTS public.v_associate_late_fees;
DROP VIEW IF EXISTS public.v_associate_credit_summary;
DROP VIEW IF EXISTS public.v_associate_credit_complete;
DROP VIEW IF EXISTS public.v_associate_all_payments;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.user_roles;
DROP SEQUENCE IF EXISTS public.system_configurations_id_seq;
DROP TABLE IF EXISTS public.system_configurations;
DROP SEQUENCE IF EXISTS public.statement_statuses_id_seq;
DROP TABLE IF EXISTS public.statement_statuses;
DROP SEQUENCE IF EXISTS public.roles_id_seq;
DROP TABLE IF EXISTS public.roles;
DROP SEQUENCE IF EXISTS public.relationships_id_seq;
DROP TABLE IF EXISTS public.relationships;
DROP SEQUENCE IF EXISTS public.rate_profiles_id_seq;
DROP TABLE IF EXISTS public.rate_profiles;
DROP SEQUENCE IF EXISTS public.rate_profile_reference_table_id_seq;
DROP TABLE IF EXISTS public.rate_profile_reference_table;
DROP SEQUENCE IF EXISTS public.payments_id_seq;
DROP TABLE IF EXISTS public.payments;
DROP SEQUENCE IF EXISTS public.payment_statuses_id_seq;
DROP TABLE IF EXISTS public.payment_statuses;
DROP SEQUENCE IF EXISTS public.payment_status_history_id_seq;
DROP TABLE IF EXISTS public.payment_status_history;
DROP SEQUENCE IF EXISTS public.payment_methods_id_seq;
DROP TABLE IF EXISTS public.payment_methods;
DROP SEQUENCE IF EXISTS public.loans_id_seq;
DROP TABLE IF EXISTS public.loans;
DROP SEQUENCE IF EXISTS public.loan_statuses_id_seq;
DROP TABLE IF EXISTS public.loan_statuses;
DROP SEQUENCE IF EXISTS public.loan_renewals_id_seq;
DROP TABLE IF EXISTS public.loan_renewals;
DROP SEQUENCE IF EXISTS public.level_change_types_id_seq;
DROP TABLE IF EXISTS public.level_change_types;
DROP SEQUENCE IF EXISTS public.legacy_payment_table_id_seq;
DROP TABLE IF EXISTS public.legacy_payment_table;
DROP SEQUENCE IF EXISTS public.guarantors_id_seq;
DROP TABLE IF EXISTS public.guarantors;
DROP SEQUENCE IF EXISTS public.document_types_id_seq;
DROP TABLE IF EXISTS public.document_types;
DROP SEQUENCE IF EXISTS public.document_statuses_id_seq;
DROP TABLE IF EXISTS public.document_statuses;
DROP SEQUENCE IF EXISTS public.defaulted_client_reports_id_seq;
DROP TABLE IF EXISTS public.defaulted_client_reports;
DROP SEQUENCE IF EXISTS public.cut_periods_id_seq;
DROP TABLE IF EXISTS public.cut_periods;
DROP SEQUENCE IF EXISTS public.cut_period_statuses_id_seq;
DROP TABLE IF EXISTS public.cut_period_statuses;
DROP SEQUENCE IF EXISTS public.contracts_id_seq;
DROP TABLE IF EXISTS public.contracts;
DROP SEQUENCE IF EXISTS public.contract_statuses_id_seq;
DROP TABLE IF EXISTS public.contract_statuses;
DROP SEQUENCE IF EXISTS public.config_types_id_seq;
DROP TABLE IF EXISTS public.config_types;
DROP SEQUENCE IF EXISTS public.client_documents_id_seq;
DROP TABLE IF EXISTS public.client_documents;
DROP SEQUENCE IF EXISTS public.beneficiaries_id_seq;
DROP TABLE IF EXISTS public.beneficiaries;
DROP SEQUENCE IF EXISTS public.audit_session_log_id_seq;
DROP TABLE IF EXISTS public.audit_session_log;
DROP SEQUENCE IF EXISTS public.audit_log_id_seq;
DROP TABLE IF EXISTS public.audit_log;
DROP SEQUENCE IF EXISTS public.associate_statement_payments_id_seq;
DROP TABLE IF EXISTS public.associate_statement_payments;
DROP SEQUENCE IF EXISTS public.associate_profiles_id_seq;
DROP TABLE IF EXISTS public.associate_profiles;
DROP SEQUENCE IF EXISTS public.associate_payment_statements_id_seq;
DROP TABLE IF EXISTS public.associate_payment_statements;
DROP SEQUENCE IF EXISTS public.associate_levels_id_seq;
DROP TABLE IF EXISTS public.associate_levels;
DROP SEQUENCE IF EXISTS public.associate_level_history_id_seq;
DROP TABLE IF EXISTS public.associate_level_history;
DROP SEQUENCE IF EXISTS public.associate_debt_payments_id_seq;
DROP TABLE IF EXISTS public.associate_debt_payments;
DROP SEQUENCE IF EXISTS public.associate_debt_breakdown_id_seq;
DROP TABLE IF EXISTS public.associate_debt_breakdown;
DROP SEQUENCE IF EXISTS public.associate_accumulated_balances_id_seq;
DROP TABLE IF EXISTS public.associate_accumulated_balances;
DROP SEQUENCE IF EXISTS public.agreements_id_seq;
DROP TABLE IF EXISTS public.agreements;
DROP SEQUENCE IF EXISTS public.agreement_payments_id_seq;
DROP TABLE IF EXISTS public.agreement_payments;
DROP SEQUENCE IF EXISTS public.agreement_items_id_seq;
DROP TABLE IF EXISTS public.agreement_items;
DROP SEQUENCE IF EXISTS public.addresses_id_seq;
DROP TABLE IF EXISTS public.addresses;
DROP FUNCTION IF EXISTS public.validate_payment_breakdown(p_payment_id integer);
DROP FUNCTION IF EXISTS public.validate_loan_payment_schedule(p_loan_id integer);
DROP FUNCTION IF EXISTS public.validate_loan_calculated_fields(p_loan_id integer);
DROP FUNCTION IF EXISTS public.validate_credit_liberation_logic();
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.update_statement_on_payment();
DROP FUNCTION IF EXISTS public.update_legacy_payment_table_timestamp();
DROP FUNCTION IF EXISTS public.trigger_update_associate_credit_on_payment();
DROP FUNCTION IF EXISTS public.trigger_update_associate_credit_on_loan_delete();
DROP FUNCTION IF EXISTS public.trigger_update_associate_credit_on_loan_cancel();
DROP FUNCTION IF EXISTS public.trigger_update_associate_credit_on_loan_approval();
DROP FUNCTION IF EXISTS public.trigger_update_associate_credit_on_level_change();
DROP FUNCTION IF EXISTS public.trigger_update_associate_credit_on_debt_payment();
DROP FUNCTION IF EXISTS public.sync_associate_consolidated_debt(p_associate_profile_id integer);
DROP FUNCTION IF EXISTS public.simulate_loan_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_approval_date date);
DROP FUNCTION IF EXISTS public.simulate_loan_complete(p_amount numeric, p_term_biweeks integer, p_profile_code character varying, p_approval_date date);
DROP FUNCTION IF EXISTS public.simulate_loan(p_amount numeric, p_term_biweeks integer, p_profile_code character varying, p_approval_date date);
DROP FUNCTION IF EXISTS public.rollback_credit_liberation_v2();
DROP FUNCTION IF EXISTS public.revert_last_payment_change(p_payment_id integer, p_admin_user_id integer, p_reason text);
DROP FUNCTION IF EXISTS public.report_defaulted_client(p_associate_profile_id integer, p_loan_id integer, p_reported_by integer, p_total_debt_amount numeric, p_evidence_details text, p_evidence_file_path character varying);
DROP FUNCTION IF EXISTS public.renew_loan(p_original_loan_id integer, p_new_amount numeric, p_new_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_created_by integer);
DROP FUNCTION IF EXISTS public.log_payment_status_change();
DROP FUNCTION IF EXISTS public.handle_loan_approval_status();
DROP FUNCTION IF EXISTS public.get_payment_history(p_payment_id integer);
DROP FUNCTION IF EXISTS public.get_debt_payment_detail(p_debt_payment_id integer);
DROP FUNCTION IF EXISTS public.get_cut_period_for_payment(p_payment_date date);
DROP FUNCTION IF EXISTS public.generate_payment_schedule();
DROP FUNCTION IF EXISTS public.generate_loan_summary(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric);
DROP FUNCTION IF EXISTS public.generate_amortization_schedule(p_amount numeric, p_biweekly_payment numeric, p_term_biweeks integer, p_commission_rate numeric, p_start_date date);
DROP FUNCTION IF EXISTS public.finalize_statements_manual(p_cut_period_id integer);
DROP FUNCTION IF EXISTS public.detect_suspicious_payment_changes(p_days_back integer, p_min_changes integer);
DROP FUNCTION IF EXISTS public.close_period_and_accumulate_debt(p_cut_period_id integer, p_closed_by integer);
DROP FUNCTION IF EXISTS public.check_associate_credit_available(p_associate_profile_id integer, p_requested_amount numeric);
DROP FUNCTION IF EXISTS public.check_associate_available_credit(p_associate_profile_id integer, p_requested_amount numeric);
DROP FUNCTION IF EXISTS public.calculate_payment_preview(p_approval_timestamp timestamp with time zone, p_term_biweeks integer, p_amount numeric);
DROP FUNCTION IF EXISTS public.calculate_loan_remaining_balance(p_loan_id integer);
DROP FUNCTION IF EXISTS public.calculate_loan_payment_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric);
DROP FUNCTION IF EXISTS public.calculate_loan_payment(p_amount numeric, p_term_biweeks integer, p_profile_code character varying);
DROP FUNCTION IF EXISTS public.calculate_late_fee_for_statement(p_statement_id integer);
DROP FUNCTION IF EXISTS public.calculate_first_payment_date(p_approval_date date);
DROP FUNCTION IF EXISTS public.auto_generate_statements_at_midnight();
DROP FUNCTION IF EXISTS public.audit_trigger_function();
DROP FUNCTION IF EXISTS public.approve_defaulted_report(p_report_id integer, p_approved_by integer);
DROP FUNCTION IF EXISTS public.approve_defaulted_client_report(p_report_id integer, p_approved_by integer, p_cut_period_id integer);
DROP FUNCTION IF EXISTS public.apply_excess_to_debt_fifo(p_associate_profile_id integer, p_excess_amount numeric, p_payment_reference character varying);
DROP FUNCTION IF EXISTS public.apply_debt_payment_v2(p_associate_profile_id integer, p_payment_amount numeric, p_payment_method_id integer, p_payment_reference character varying, p_registered_by integer, p_notes text);
DROP FUNCTION IF EXISTS public.apply_debt_payment_v2(p_associate_profile_id integer, p_payment_amount numeric, p_payment_date date, p_notes text);
DROP FUNCTION IF EXISTS public.admin_mark_payment_status(p_payment_id integer, p_new_status_id integer, p_admin_user_id integer, p_notes text);
--
-- TOC entry 4421 (class 0 OID 0)
-- Dependencies: 4
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'Schema público de CrediCuenta v2.0.3 con sistema de perfiles de tasa flexible.';


--
-- TOC entry 313 (class 1255 OID 16385)
-- Name: admin_mark_payment_status(integer, integer, integer, text); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.admin_mark_payment_status(p_payment_id integer, p_new_status_id integer, p_admin_user_id integer, p_notes text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_old_status_id INTEGER;
BEGIN
    -- Obtener estado actual
    SELECT status_id INTO v_old_status_id
    FROM payments
    WHERE id = p_payment_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Pago % no encontrado', p_payment_id;
    END IF;
    
    -- Actualizar estado del pago
    UPDATE payments
    SET 
        status_id = p_new_status_id,
        marked_by = p_admin_user_id,
        marked_at = CURRENT_TIMESTAMP,
        marking_notes = p_notes,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_payment_id;
    
    RAISE NOTICE 'Pago % marcado como estado % por usuario %', p_payment_id, p_new_status_id, p_admin_user_id;
END;
$$;


ALTER FUNCTION public.admin_mark_payment_status(p_payment_id integer, p_new_status_id integer, p_admin_user_id integer, p_notes text) OWNER TO credinet_user;

--
-- TOC entry 4422 (class 0 OID 0)
-- Dependencies: 313
-- Name: FUNCTION admin_mark_payment_status(p_payment_id integer, p_new_status_id integer, p_admin_user_id integer, p_notes text); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.admin_mark_payment_status(p_payment_id integer, p_new_status_id integer, p_admin_user_id integer, p_notes text) IS '⭐ MIGRACIÓN 11: Permite a un administrador marcar manualmente el estado de un pago con notas. El trigger de auditoría registrará el cambio automáticamente.';


--
-- TOC entry 327 (class 1255 OID 16386)
-- Name: apply_debt_payment_v2(integer, numeric, date, text); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.apply_debt_payment_v2(p_associate_profile_id integer, p_payment_amount numeric, p_payment_date date, p_notes text DEFAULT NULL::text) RETURNS TABLE(payment_id integer, amount_applied numeric, remaining_amount numeric, items_liquidated integer)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_remaining DECIMAL(12,2) := p_payment_amount;
    v_debt_item RECORD;
    v_amount_to_apply DECIMAL(12,2);
    v_items_liquidated INTEGER := 0;
    v_new_payment_id INTEGER;
    v_total_applied DECIMAL(12,2) := 0;
BEGIN
    -- Crear registro del pago
    INSERT INTO associate_debt_payments (
        associate_profile_id, payment_amount, payment_date, notes, created_at
    ) VALUES (
        p_associate_profile_id, p_payment_amount, p_payment_date, p_notes, CURRENT_TIMESTAMP
    ) RETURNING id INTO v_new_payment_id;

    -- Aplicar a items de deuda
    FOR v_debt_item IN
        SELECT id, amount, paid_amount
        FROM associate_debt_breakdown
        WHERE associate_profile_id = p_associate_profile_id
          AND is_liquidated = false
        ORDER BY created_at ASC
    LOOP
        EXIT WHEN v_remaining <= 0;

        v_amount_to_apply := LEAST(v_remaining, v_debt_item.amount - COALESCE(v_debt_item.paid_amount, 0));

        IF v_amount_to_apply > 0 THEN
            UPDATE associate_debt_breakdown
            SET paid_amount = COALESCE(paid_amount, 0) + v_amount_to_apply,
                is_liquidated = (COALESCE(paid_amount, 0) + v_amount_to_apply >= amount),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = v_debt_item.id;

            IF (COALESCE(v_debt_item.paid_amount, 0) + v_amount_to_apply >= v_debt_item.amount) THEN
                v_items_liquidated := v_items_liquidated + 1;
            END IF;

            INSERT INTO debt_payment_breakdown (
                debt_payment_id, debt_item_id, amount_applied, created_at
            ) VALUES (
                v_new_payment_id, v_debt_item.id, v_amount_to_apply, CURRENT_TIMESTAMP
            );

            v_remaining := v_remaining - v_amount_to_apply;
            v_total_applied := v_total_applied + v_amount_to_apply;
        END IF;
    END LOOP;

    -- Actualizar consolidated_debt del perfil (antes debt_balance)
    UPDATE associate_profiles
    SET consolidated_debt = GREATEST(0, consolidated_debt - v_total_applied),
        credit_last_updated = CURRENT_TIMESTAMP
    WHERE id = p_associate_profile_id;

    payment_id := v_new_payment_id;
    amount_applied := v_total_applied;
    remaining_amount := v_remaining;
    items_liquidated := v_items_liquidated;

    RETURN NEXT;
END;
$$;


ALTER FUNCTION public.apply_debt_payment_v2(p_associate_profile_id integer, p_payment_amount numeric, p_payment_date date, p_notes text) OWNER TO credinet_user;

--
-- TOC entry 328 (class 1255 OID 16387)
-- Name: apply_debt_payment_v2(integer, numeric, integer, character varying, integer, text); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.apply_debt_payment_v2(p_associate_profile_id integer, p_payment_amount numeric, p_payment_method_id integer, p_payment_reference character varying, p_registered_by integer, p_notes text DEFAULT NULL::text) RETURNS TABLE(payment_id integer, amount_applied numeric, remaining_debt numeric, applied_items jsonb, credit_released numeric)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_user_id INTEGER;
    v_remaining_amount DECIMAL(12,2);
    v_debt_record RECORD;
    v_applied_items JSONB := '[]'::jsonb;
    v_item JSONB;
    v_amount_to_apply DECIMAL(12,2);
    v_total_applied DECIMAL(12,2) := 0;
    v_payment_id INTEGER;
    v_debt_before DECIMAL(12,2);
    v_debt_after DECIMAL(12,2);
BEGIN
    -- Validaciones iniciales
    IF p_payment_amount <= 0 THEN
        RAISE EXCEPTION 'El monto del abono debe ser mayor a 0';
    END IF;

    -- Obtener user_id y deuda actual
    SELECT ap.user_id, ap.debt_balance
    INTO v_user_id, v_debt_before
    FROM associate_profiles ap WHERE ap.id = p_associate_profile_id;

    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Perfil de asociado % no encontrado', p_associate_profile_id;
    END IF;

    v_remaining_amount := p_payment_amount;

    -- ⭐ APLICAR FIFO: liquidar deudas más antiguas primero desde accumulated_balances
    FOR v_debt_record IN (
        SELECT
            aab.id,
            aab.accumulated_debt,
            aab.cut_period_id,
            aab.created_at,
            cp.cut_code
        FROM associate_accumulated_balances aab
        JOIN cut_periods cp ON cp.id = aab.cut_period_id
        WHERE aab.user_id = v_user_id
          AND aab.accumulated_debt > 0
        ORDER BY aab.created_at ASC, aab.id ASC  -- ⭐ FIFO por fecha
    )
    LOOP
        EXIT WHEN v_remaining_amount <= 0;

        IF v_remaining_amount >= v_debt_record.accumulated_debt THEN
            -- Liquidar completamente este item
            v_amount_to_apply := v_debt_record.accumulated_debt;

            UPDATE associate_accumulated_balances
            SET
                accumulated_debt = 0,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = v_debt_record.id;

            v_remaining_amount := v_remaining_amount - v_amount_to_apply;

            v_item := jsonb_build_object(
                'accumulated_balance_id', v_debt_record.id,
                'cut_period_id', v_debt_record.cut_period_id,
                'period_code', v_debt_record.cut_code,
                'original_debt', v_debt_record.accumulated_debt,
                'amount_applied', v_amount_to_apply,
                'remaining_debt', 0,
                'fully_liquidated', true
            );
        ELSE
            -- Liquidar parcialmente
            v_amount_to_apply := v_remaining_amount;

            UPDATE associate_accumulated_balances
            SET
                accumulated_debt = accumulated_debt - v_remaining_amount,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = v_debt_record.id;

            v_item := jsonb_build_object(
                'accumulated_balance_id', v_debt_record.id,
                'cut_period_id', v_debt_record.cut_period_id,
                'period_code', v_debt_record.cut_code,
                'original_debt', v_debt_record.accumulated_debt,
                'amount_applied', v_amount_to_apply,
                'remaining_debt', v_debt_record.accumulated_debt - v_remaining_amount,
                'fully_liquidated', false
            );

            v_remaining_amount := 0;
        END IF;

        v_applied_items := v_applied_items || v_item;
        v_total_applied := v_total_applied + v_amount_to_apply;
    END LOOP;

    -- Si no se aplicó nada (no había deuda en accumulated_balances), advertir
    IF v_total_applied = 0 THEN
        RAISE EXCEPTION 'No se encontró deuda pendiente (sin convenio) para aplicar el abono. Use el sistema de convenios para pagos a convenios.';
    END IF;

    -- Insertar registro de pago
    INSERT INTO associate_debt_payments (
        associate_profile_id,
        payment_amount,
        payment_date,
        payment_method_id,
        payment_reference,
        registered_by,
        applied_breakdown_items,
        notes
    ) VALUES (
        p_associate_profile_id,
        v_total_applied,
        CURRENT_DATE,
        p_payment_method_id,
        p_payment_reference,
        p_registered_by,
        v_applied_items,
        CASE
            WHEN v_remaining_amount > 0 THEN
                COALESCE(p_notes, '') || ' [Sobrante no aplicado: ' || v_remaining_amount || ']'
            ELSE p_notes
        END
    )
    RETURNING id INTO v_payment_id;

    -- ⭐ CORREGIDO: Solo actualizar debt_balance (NO credit_used)
    -- El pago de deuda acumulada reduce debt_balance, NO libera credit_used
    -- credit_used solo se libera cuando el CLIENTE paga su préstamo
    UPDATE associate_profiles
    SET
        debt_balance = GREATEST(0, debt_balance - v_total_applied),
        credit_last_updated = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_associate_profile_id
    RETURNING debt_balance INTO v_debt_after;

    -- Retornar resultado
    -- credit_released = reducción de debt_balance (que aumenta credit_available automáticamente)
    RETURN QUERY SELECT
        v_payment_id,
        v_total_applied,
        v_debt_after,  -- deuda restante después del pago
        v_applied_items,
        v_debt_before - v_debt_after;  -- crédito liberado (por reducción de debt_balance)
END;
$$;


ALTER FUNCTION public.apply_debt_payment_v2(p_associate_profile_id integer, p_payment_amount numeric, p_payment_method_id integer, p_payment_reference character varying, p_registered_by integer, p_notes text) OWNER TO credinet_user;

--
-- TOC entry 329 (class 1255 OID 16389)
-- Name: apply_excess_to_debt_fifo(integer, numeric, character varying); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.apply_excess_to_debt_fifo(p_associate_profile_id integer, p_excess_amount numeric, p_payment_reference character varying) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_remaining_amount DECIMAL(12,2);
    v_debt_record RECORD;
BEGIN
    v_remaining_amount := p_excess_amount;
    
    -- Aplicar FIFO: liquidar deudas más antiguas primero
    FOR v_debt_record IN (
        SELECT id, amount
        FROM associate_debt_breakdown
        WHERE associate_profile_id = p_associate_profile_id
          AND is_liquidated = false
        ORDER BY created_at ASC, id ASC  -- ⭐ FIFO
    )
    LOOP
        EXIT WHEN v_remaining_amount <= 0;
        
        IF v_remaining_amount >= v_debt_record.amount THEN
            -- Liquidar completamente este item
            UPDATE associate_debt_breakdown
            SET 
                is_liquidated = true,
                liquidated_at = CURRENT_TIMESTAMP,
                liquidation_reference = p_payment_reference,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = v_debt_record.id;
            
            v_remaining_amount := v_remaining_amount - v_debt_record.amount;
            
            RAISE NOTICE 'Deuda % liquidada completamente (monto: %)', 
                         v_debt_record.id, v_debt_record.amount;
        ELSE
            -- Liquidar parcialmente (reducir monto del item)
            UPDATE associate_debt_breakdown
            SET 
                amount = amount - v_remaining_amount,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = v_debt_record.id;
            
            RAISE NOTICE 'Deuda % liquidada parcialmente (abono: %, restante: %)', 
                         v_debt_record.id, v_remaining_amount, v_debt_record.amount - v_remaining_amount;
            
            v_remaining_amount := 0;
        END IF;
    END LOOP;
    
    -- Actualizar debt_balance del asociado
    UPDATE associate_profiles
    SET 
        debt_balance = (
            SELECT COALESCE(SUM(amount), 0)
            FROM associate_debt_breakdown
            WHERE associate_profile_id = p_associate_profile_id
              AND is_liquidated = false
        ),
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_associate_profile_id;
    
    RAISE NOTICE 'Excedente aplicado: % (sobrante: %)', p_excess_amount - v_remaining_amount, v_remaining_amount;
END;
$$;


ALTER FUNCTION public.apply_excess_to_debt_fifo(p_associate_profile_id integer, p_excess_amount numeric, p_payment_reference character varying) OWNER TO credinet_user;

--
-- TOC entry 4423 (class 0 OID 0)
-- Dependencies: 329
-- Name: FUNCTION apply_excess_to_debt_fifo(p_associate_profile_id integer, p_excess_amount numeric, p_payment_reference character varying); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.apply_excess_to_debt_fifo(p_associate_profile_id integer, p_excess_amount numeric, p_payment_reference character varying) IS '⭐ v2.0.4: Aplica excedente de pago a deuda acumulada usando estrategia FIFO (más antiguos primero). Actualiza debt_balance automáticamente.';


--
-- TOC entry 330 (class 1255 OID 16390)
-- Name: approve_defaulted_client_report(integer, integer, integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.approve_defaulted_client_report(p_report_id integer, p_approved_by integer, p_cut_period_id integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_associate_profile_id INTEGER;
    v_loan_id INTEGER;
    v_client_user_id INTEGER;
    v_total_debt_amount DECIMAL(12,2);
    v_paid_by_associate_id INTEGER;
BEGIN
    -- Obtener datos del reporte
    SELECT 
        associate_profile_id,
        loan_id,
        client_user_id,
        total_debt_amount
    INTO 
        v_associate_profile_id,
        v_loan_id,
        v_client_user_id,
        v_total_debt_amount
    FROM defaulted_client_reports
    WHERE id = p_report_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Reporte % no encontrado', p_report_id;
    END IF;
    
    -- Obtener ID del estado PAID_BY_ASSOCIATE
    SELECT id INTO v_paid_by_associate_id FROM payment_statuses WHERE name = 'PAID_BY_ASSOCIATE';
    
    -- Actualizar reporte como aprobado
    UPDATE defaulted_client_reports
    SET status = 'APPROVED',
        approved_by = p_approved_by,
        approved_at = CURRENT_TIMESTAMP
    WHERE id = p_report_id;
    
    -- Marcar pagos del préstamo como PAID_BY_ASSOCIATE
    UPDATE payments
    SET status_id = v_paid_by_associate_id,
        updated_at = CURRENT_TIMESTAMP
    WHERE loan_id = v_loan_id
      AND status_id NOT IN (
          SELECT id FROM payment_statuses WHERE name IN ('PAID', 'PAID_BY_ASSOCIATE')
      );
    
    -- Crear registro de deuda en associate_debt_breakdown
    INSERT INTO associate_debt_breakdown (
        associate_profile_id,
        cut_period_id,
        debt_type,
        loan_id,
        client_user_id,
        amount,
        description,
        is_liquidated
    ) VALUES (
        v_associate_profile_id,
        p_cut_period_id,
        'DEFAULTED_CLIENT',
        v_loan_id,
        v_client_user_id,
        v_total_debt_amount,
        'Cliente moroso aprobado - Reporte #' || p_report_id,
        false
    );
    
    -- Actualizar debt_balance del asociado
    UPDATE associate_profiles
    SET debt_balance = debt_balance + v_total_debt_amount
    WHERE id = v_associate_profile_id;
    
    RAISE NOTICE '✅ Reporte % aprobado. Deuda de % agregada a asociado %', 
        p_report_id, v_total_debt_amount, v_associate_profile_id;
END;
$$;


ALTER FUNCTION public.approve_defaulted_client_report(p_report_id integer, p_approved_by integer, p_cut_period_id integer) OWNER TO credinet_user;

--
-- TOC entry 4424 (class 0 OID 0)
-- Dependencies: 330
-- Name: FUNCTION approve_defaulted_client_report(p_report_id integer, p_approved_by integer, p_cut_period_id integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.approve_defaulted_client_report(p_report_id integer, p_approved_by integer, p_cut_period_id integer) IS '⭐ MIGRACIÓN 09: Aprueba un reporte de cliente moroso, marca pagos como PAID_BY_ASSOCIATE y crea registro de deuda en associate_debt_breakdown.';


--
-- TOC entry 331 (class 1255 OID 16391)
-- Name: approve_defaulted_report(integer, integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.approve_defaulted_report(p_report_id integer, p_approved_by integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_associate_profile_id INTEGER;
    v_total_debt_amount DECIMAL(12,2);
BEGIN
    SELECT associate_profile_id, total_debt_amount
    INTO v_associate_profile_id, v_total_debt_amount
    FROM defaulted_client_reports
    WHERE id = p_report_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Reporte % no encontrado', p_report_id;
    END IF;

    UPDATE defaulted_client_reports
    SET status = 'APPROVED',
        approved_by = p_approved_by,
        approved_date = CURRENT_DATE,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_report_id;

    -- Actualizar consolidated_debt (antes debt_balance)
    UPDATE associate_profiles
    SET consolidated_debt = consolidated_debt + v_total_debt_amount
    WHERE id = v_associate_profile_id;

    RAISE NOTICE '✅ Reporte % aprobado. Deuda de % agregada a asociado %',
        p_report_id, v_total_debt_amount, v_associate_profile_id;
END;
$$;


ALTER FUNCTION public.approve_defaulted_report(p_report_id integer, p_approved_by integer) OWNER TO credinet_user;

--
-- TOC entry 314 (class 1255 OID 16392)
-- Name: audit_trigger_function(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.audit_trigger_function() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO audit_log (table_name, record_id, operation, old_data)
        VALUES (TG_TABLE_NAME, OLD.id, 'DELETE', row_to_json(OLD)::jsonb);
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO audit_log (table_name, record_id, operation, old_data, new_data)
        VALUES (TG_TABLE_NAME, NEW.id, 'UPDATE', row_to_json(OLD)::jsonb, row_to_json(NEW)::jsonb);
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO audit_log (table_name, record_id, operation, new_data)
        VALUES (TG_TABLE_NAME, NEW.id, 'INSERT', row_to_json(NEW)::jsonb);
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$$;


ALTER FUNCTION public.audit_trigger_function() OWNER TO credinet_user;

--
-- TOC entry 4425 (class 0 OID 0)
-- Dependencies: 314
-- Name: FUNCTION audit_trigger_function(); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.audit_trigger_function() IS 'Función genérica de auditoría que registra INSERT, UPDATE y DELETE en audit_log con snapshots JSON completos.';


--
-- TOC entry 332 (class 1255 OID 16393)
-- Name: auto_generate_statements_at_midnight(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.auto_generate_statements_at_midnight() RETURNS TABLE(period_code character varying, statements_generated integer, total_amount numeric)
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_current_day INTEGER;
    v_is_cut_day BOOLEAN;
    v_period_id INTEGER;
    v_period_code VARCHAR(20);
    v_count INTEGER;
    v_total NUMERIC(12,2);
BEGIN
    v_current_day := EXTRACT(DAY FROM CURRENT_DATE);
    
    -- Verificar si es día de corte (8 o 23)
    v_is_cut_day := v_current_day IN (8, 23);
    
    IF NOT v_is_cut_day THEN
        RAISE NOTICE 'Hoy no es día de corte (día %, esperado 8 o 23)', v_current_day;
        RETURN;
    END IF;
    
    -- Obtener periodo correspondiente a hoy (día de impresión)
    SELECT id, cut_code INTO v_period_id, v_period_code
    FROM cut_periods
    WHERE period_end_date + 1 = CURRENT_DATE;
    
    IF v_period_id IS NULL THEN
        RAISE EXCEPTION 'No se encontró periodo para hoy: %', CURRENT_DATE;
    END IF;
    
    RAISE NOTICE '🔄 Iniciando corte automático para periodo: %', v_period_code;
    
    -- Generar statements automáticos con estado DRAFT (ID 6)
    INSERT INTO associate_payment_statements (
        cut_period_id,
        user_id,
        statement_number,
        total_payments_count,
        total_amount_collected,
        total_commission_owed,
        commission_rate_applied,
        status_id,
        generated_date,
        due_date
    )
    SELECT 
        v_period_id,
        l.associate_user_id,
        CONCAT(v_period_code, '-A', l.associate_user_id) as statement_number,
        COUNT(p.id) as total_payments,
        SUM(p.expected_amount) as total_amount,
        SUM(p.commission_amount) as total_commission,
        l.commission_rate,
        6,  -- DRAFT
        CURRENT_DATE,
        CURRENT_DATE + INTERVAL '7 days'
    FROM payments p
    JOIN loans l ON p.loan_id = l.id
    WHERE p.cut_period_id = v_period_id
      AND p.status_id = 1  -- PENDING
      AND l.associate_user_id IS NOT NULL
    GROUP BY v_period_id, l.associate_user_id, v_period_code, l.commission_rate
    ON CONFLICT DO NOTHING;
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    -- Calcular total generado
    SELECT COALESCE(SUM(total_amount_collected), 0) INTO v_total
    FROM associate_payment_statements
    WHERE cut_period_id = v_period_id AND status_id = 6;
    
    RAISE NOTICE '✅ Corte automático completado: % statements en DRAFT, Total: $%',
        v_count, v_total;
    
    -- Retornar resumen
    RETURN QUERY SELECT v_period_code, v_count, v_total;
END;
$_$;


ALTER FUNCTION public.auto_generate_statements_at_midnight() OWNER TO credinet_user;

--
-- TOC entry 4426 (class 0 OID 0)
-- Dependencies: 332
-- Name: FUNCTION auto_generate_statements_at_midnight(); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.auto_generate_statements_at_midnight() IS '✅ CORTE AUTOMÁTICO (00:00 hrs - Días 8 y 23)
Genera statements automáticamente en estado DRAFT (editable).
Admin puede revisar y ajustar antes de ejecutar corte manual.
Ejecutar con cron: 0 0 * * * SELECT auto_generate_statements_at_midnight()';


--
-- TOC entry 333 (class 1255 OID 16394)
-- Name: calculate_first_payment_date(date); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.calculate_first_payment_date(p_approval_date date) RETURNS date
    LANGUAGE plpgsql IMMUTABLE STRICT PARALLEL SAFE
    AS $$
DECLARE
    v_approval_day INTEGER;
    v_approval_year INTEGER;
    v_approval_month INTEGER;
    v_first_payment_date DATE;
    v_next_month_date DATE;
    v_last_day_current_month DATE;
BEGIN
    -- Extraer componentes de la fecha
    v_approval_day := EXTRACT(DAY FROM p_approval_date)::INTEGER;
    v_approval_year := EXTRACT(YEAR FROM p_approval_date)::INTEGER;
    v_approval_month := EXTRACT(MONTH FROM p_approval_date)::INTEGER;
    
    -- Pre-calcular fechas comunes
    v_next_month_date := p_approval_date + INTERVAL '1 month';
    v_last_day_current_month := (DATE_TRUNC('month', p_approval_date) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
    
    -- Aplicar lógica del doble calendario
    v_first_payment_date := CASE
        -- CASO 1: Aprobación días 1-7 → Primer pago día 15 del mes ACTUAL
        WHEN v_approval_day >= 1 AND v_approval_day < 8 THEN
            MAKE_DATE(v_approval_year, v_approval_month, 15)
        
        -- CASO 2: Aprobación días 8-22 → Primer pago ÚLTIMO día del mes ACTUAL
        WHEN v_approval_day >= 8 AND v_approval_day < 23 THEN
            v_last_day_current_month
        
        -- CASO 3: Aprobación día 23+ → Primer pago día 15 del mes SIGUIENTE
        WHEN v_approval_day >= 23 THEN
            MAKE_DATE(
                EXTRACT(YEAR FROM v_next_month_date)::INTEGER,
                EXTRACT(MONTH FROM v_next_month_date)::INTEGER,
                15
            )
        
        ELSE NULL
    END;
    
    -- Validaciones
    IF p_approval_date IS NULL THEN
        RAISE EXCEPTION 'La fecha de aprobación no puede ser NULL';
    END IF;
    
    IF v_approval_day < 1 OR v_approval_day > 31 THEN
        RAISE EXCEPTION 'Día de aprobación inválido: %. Debe estar entre 1 y 31.', v_approval_day;
    END IF;
    
    IF v_first_payment_date < p_approval_date THEN
        RAISE WARNING 'ALERTA: La fecha de primer pago (%) es anterior a la fecha de aprobación (%).',
            v_first_payment_date, p_approval_date;
    END IF;
    
    RETURN v_first_payment_date;
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error al calcular primera fecha de pago para %: % (%)',
            p_approval_date, SQLERRM, SQLSTATE;
END;
$$;


ALTER FUNCTION public.calculate_first_payment_date(p_approval_date date) OWNER TO credinet_user;

--
-- TOC entry 4427 (class 0 OID 0)
-- Dependencies: 333
-- Name: FUNCTION calculate_first_payment_date(p_approval_date date); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.calculate_first_payment_date(p_approval_date date) IS '⭐ ORÁCULO: Calcula la primera fecha de pago del cliente según lógica del doble calendario (cortes días 8 y 23, vencimientos días 15 y último). INMUTABLE y PURA.';


--
-- TOC entry 334 (class 1255 OID 16395)
-- Name: calculate_late_fee_for_statement(integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.calculate_late_fee_for_statement(p_statement_id integer) RETURNS numeric
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_total_payments_count INTEGER;
    v_total_commission_owed DECIMAL(12,2);
    v_late_fee DECIMAL(12,2);
BEGIN
    -- Obtener datos del statement
    SELECT total_payments_count, total_commission_owed
    INTO v_total_payments_count, v_total_commission_owed
    FROM associate_payment_statements
    WHERE id = p_statement_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Statement % no encontrado', p_statement_id;
    END IF;
    
    -- Aplicar regla: Si NO reportó ningún pago, mora del 30% sobre comisión
    IF v_total_payments_count = 0 AND v_total_commission_owed > 0 THEN
        v_late_fee := v_total_commission_owed * 0.30;
        RAISE NOTICE 'Mora del 30%% aplicada: % (comisión: %)', v_late_fee, v_total_commission_owed;
    ELSE
        v_late_fee := 0.00;
    END IF;
    
    RETURN ROUND(v_late_fee, 2);
END;
$$;


ALTER FUNCTION public.calculate_late_fee_for_statement(p_statement_id integer) OWNER TO credinet_user;

--
-- TOC entry 4428 (class 0 OID 0)
-- Dependencies: 334
-- Name: FUNCTION calculate_late_fee_for_statement(p_statement_id integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.calculate_late_fee_for_statement(p_statement_id integer) IS '⭐ MIGRACIÓN 10: Calcula mora del 30% sobre comisión si el asociado NO reportó ningún pago en el período (total_payments_count = 0).';


--
-- TOC entry 335 (class 1255 OID 16396)
-- Name: calculate_loan_payment(numeric, integer, character varying); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.calculate_loan_payment(p_amount numeric, p_term_biweeks integer, p_profile_code character varying) RETURNS TABLE(profile_code character varying, profile_name character varying, calculation_method character varying, interest_rate_percent numeric, commission_rate_percent numeric, biweekly_payment numeric, total_payment numeric, total_interest numeric, effective_rate_percent numeric, commission_per_payment numeric, total_commission numeric, associate_payment numeric, associate_total numeric)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_profile RECORD;
    v_legacy_entry RECORD;
    v_factor DECIMAL(10,6);
    v_total DECIMAL(12,2);
    v_payment DECIMAL(10,2);
    v_commission_per_payment DECIMAL(10,2);
BEGIN
    -- Obtener perfil
    SELECT * INTO v_profile
    FROM rate_profiles
    WHERE code = p_profile_code AND enabled = true;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Perfil de tasa no encontrado o deshabilitado: %', p_profile_code;
    END IF;
    
    -- MÉTODO 1: Table Lookup (perfil legacy)
    IF v_profile.calculation_type = 'table_lookup' THEN
        SELECT * INTO v_legacy_entry
        FROM legacy_payment_table
        WHERE amount = p_amount AND term_biweeks = p_term_biweeks;
        
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Monto % no encontrado en tabla legacy para plazo %Q', p_amount, p_term_biweeks;
        END IF;
        
        v_payment := v_legacy_entry.biweekly_payment;
        v_total := v_legacy_entry.total_payment;
        v_commission_per_payment := COALESCE(v_legacy_entry.commission_per_payment, 0);
        
        RETURN QUERY SELECT
            v_profile.code,
            v_profile.name,
            v_profile.calculation_type,
            v_legacy_entry.biweekly_rate_percent AS interest_rate,
            ROUND(((COALESCE(v_legacy_entry.commission_per_payment, 0) / NULLIF(v_payment, 0)) * 100)::NUMERIC, 3) AS commission_rate,
            v_payment,
            v_total,
            v_legacy_entry.total_interest,
            v_legacy_entry.effective_rate_percent,
            ROUND(v_commission_per_payment, 2),
            ROUND(COALESCE(v_legacy_entry.total_commission, 0), 2),
            ROUND(COALESCE(v_legacy_entry.associate_biweekly_payment, 0), 2),
            ROUND(COALESCE(v_legacy_entry.associate_total_payment, 0), 2);
        
        RETURN;
    END IF;
    
    -- MÉTODO 2: Formula (perfiles standard, custom)
    IF v_profile.calculation_type = 'formula' THEN
        IF v_profile.interest_rate_percent IS NULL THEN
            RAISE EXCEPTION 'Perfil % tipo formula requiere interest_rate_percent configurado', p_profile_code;
        END IF;
        
        IF v_profile.commission_rate_percent IS NULL THEN
            RAISE EXCEPTION 'Perfil % tipo formula requiere commission_rate_percent configurado', p_profile_code;
        END IF;
        
        -- Calcular pago del CLIENTE (interés simple)
        v_factor := 1 + (v_profile.interest_rate_percent / 100) * p_term_biweeks;
        v_total := p_amount * v_factor;
        v_payment := v_total / p_term_biweeks;
        
        -- ⭐ CAMBIO CRÍTICO: Comisión sobre el MONTO, no sobre el pago
        v_commission_per_payment := p_amount * (v_profile.commission_rate_percent / 100);
        
        RETURN QUERY SELECT
            v_profile.code,
            v_profile.name,
            v_profile.calculation_type,
            v_profile.interest_rate_percent,
            v_profile.commission_rate_percent,
            ROUND(v_payment, 2) AS biweekly_payment,
            ROUND(v_total, 2) AS total_payment,
            ROUND(v_total - p_amount, 2) AS total_interest,
            ROUND(((v_total - p_amount) / p_amount * 100)::NUMERIC, 2) AS effective_rate,
            ROUND(v_commission_per_payment, 2),
            ROUND(v_commission_per_payment * p_term_biweeks, 2),
            ROUND(v_payment - v_commission_per_payment, 2),
            ROUND((v_payment - v_commission_per_payment) * p_term_biweeks, 2);
        
        RETURN;
    END IF;
    
    RAISE EXCEPTION 'Tipo de cálculo no soportado: %', v_profile.calculation_type;
END;
$$;


ALTER FUNCTION public.calculate_loan_payment(p_amount numeric, p_term_biweeks integer, p_profile_code character varying) OWNER TO credinet_user;

--
-- TOC entry 4429 (class 0 OID 0)
-- Dependencies: 335
-- Name: FUNCTION calculate_loan_payment(p_amount numeric, p_term_biweeks integer, p_profile_code character varying); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.calculate_loan_payment(p_amount numeric, p_term_biweeks integer, p_profile_code character varying) IS 'Calcula pagos de préstamo. Para formulas, la comisión se calcula como % del MONTO (no del pago), igual que Legacy.';


--
-- TOC entry 336 (class 1255 OID 16397)
-- Name: calculate_loan_payment_custom(numeric, integer, numeric, numeric); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.calculate_loan_payment_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric) RETURNS TABLE(profile_code character varying, profile_name character varying, calculation_method character varying, interest_rate_percent numeric, commission_rate_percent numeric, biweekly_payment numeric, total_payment numeric, total_interest numeric, effective_rate_percent numeric, commission_per_payment numeric, total_commission numeric, associate_payment numeric, associate_total numeric)
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    v_factor DECIMAL(10,6);
    v_total DECIMAL(12,2);
    v_payment DECIMAL(10,2);
    v_commission_per_payment DECIMAL(10,2);
BEGIN
    -- Calcular pago del CLIENTE (interés simple)
    v_factor := 1 + (p_interest_rate / 100) * p_term_biweeks;
    v_total := p_amount * v_factor;
    v_payment := v_total / p_term_biweeks;
    
    -- ⭐ CAMBIO CRÍTICO: Comisión sobre el MONTO, no sobre el pago
    v_commission_per_payment := p_amount * (p_commission_rate / 100);
    
    RETURN QUERY SELECT
        'custom'::VARCHAR(50),
        'Personalizado'::VARCHAR(100),
        'formula'::VARCHAR(20),
        p_interest_rate,
        p_commission_rate,
        ROUND(v_payment, 2) AS biweekly_payment,
        ROUND(v_total, 2) AS total_payment,
        ROUND(v_total - p_amount, 2) AS total_interest,
        ROUND(((v_total - p_amount) / p_amount * 100)::NUMERIC, 2) AS effective_rate,
        ROUND(v_commission_per_payment, 2),
        ROUND(v_commission_per_payment * p_term_biweeks, 2),
        ROUND(v_payment - v_commission_per_payment, 2),
        ROUND((v_payment - v_commission_per_payment) * p_term_biweeks, 2);
END;
$$;


ALTER FUNCTION public.calculate_loan_payment_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric) OWNER TO credinet_user;

--
-- TOC entry 4430 (class 0 OID 0)
-- Dependencies: 336
-- Name: FUNCTION calculate_loan_payment_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.calculate_loan_payment_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric) IS 'Calcula préstamo personalizado. La comisión se calcula como % del MONTO prestado (no del pago), igual que Legacy.';


--
-- TOC entry 337 (class 1255 OID 16398)
-- Name: calculate_loan_remaining_balance(integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.calculate_loan_remaining_balance(p_loan_id integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_pending_status_id INTEGER;
    v_remaining_balance DECIMAL(12,2);
BEGIN
    -- Obtener ID del estado PENDING
    SELECT id INTO v_pending_status_id 
    FROM payment_statuses 
    WHERE name = 'PENDING';
    
    IF v_pending_status_id IS NULL THEN
        RAISE EXCEPTION 'CRITICAL: payment_statuses.PENDING no encontrado';
    END IF;
    
    -- ✅ CORRECCIÓN CRÍTICA:
    -- Sumar associate_payment (lo que debe pagar a CrediCuenta)
    -- NO expected_amount (lo que el cliente paga al asociado)
    --
    -- Lógica:
    -- - expected_amount = capital + interés (lo que cliente paga)
    -- - commission_amount = ganancia del asociado
    -- - associate_payment = expected_amount - commission_amount
    --                     = lo que el asociado debe entregar a CrediCuenta
    --
    -- El saldo pendiente del préstamo es lo que el asociado aún debe
    -- entregar a CrediCuenta, NO lo que el cliente debe al asociado.
    
    SELECT COALESCE(SUM(associate_payment), 0)
    INTO v_remaining_balance
    FROM payments
    WHERE loan_id = p_loan_id 
    AND status_id = v_pending_status_id;
    
    RETURN v_remaining_balance;
END;
$$;


ALTER FUNCTION public.calculate_loan_remaining_balance(p_loan_id integer) OWNER TO credinet_user;

--
-- TOC entry 4431 (class 0 OID 0)
-- Dependencies: 337
-- Name: FUNCTION calculate_loan_remaining_balance(p_loan_id integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.calculate_loan_remaining_balance(p_loan_id integer) IS '⭐ CORRECCIÓN 2026-01-07: Calcula el saldo pendiente del préstamo sumando associate_payment de pagos PENDING. Esto representa lo que el asociado aún debe pagar a CrediCuenta, no lo que el cliente debe al asociado. Ejemplo: si quedan 3 pagos de $1,000 cada uno (associate_payment), el saldo es $3,000.';


--
-- TOC entry 338 (class 1255 OID 16399)
-- Name: calculate_payment_preview(timestamp with time zone, integer, numeric); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.calculate_payment_preview(p_approval_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP, p_term_biweeks integer DEFAULT 12, p_amount numeric DEFAULT 100000.00) RETURNS TABLE(payment_number integer, payment_due_date date, payment_amount numeric, payment_type text, cut_period_estimated text)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_approval_date DATE;
    v_approval_day INTEGER;
    v_current_payment_date DATE;
    v_payment_amount DECIMAL(12,2);
    i INTEGER;
BEGIN
    v_approval_date := p_approval_timestamp::DATE;
    v_approval_day := EXTRACT(DAY FROM v_approval_date);
    v_payment_amount := ROUND(p_amount / p_term_biweeks, 2);
    
    -- Calcular primera fecha usando el oráculo
    v_current_payment_date := calculate_first_payment_date(v_approval_date);
    
    -- Generar preview de todos los pagos
    FOR i IN 1..p_term_biweeks LOOP
        RETURN QUERY SELECT 
            i,
            v_current_payment_date,
            v_payment_amount,
            CASE 
                WHEN EXTRACT(DAY FROM v_current_payment_date) = 15 THEN 'DÍA_15'
                ELSE 'ÚLTIMO_DÍA'
            END::TEXT,
            CASE 
                WHEN EXTRACT(DAY FROM v_current_payment_date) <= 8 THEN 'CORTE_8_' || EXTRACT(MONTH FROM v_current_payment_date)::TEXT
                ELSE 'CORTE_23_' || EXTRACT(MONTH FROM v_current_payment_date)::TEXT
            END::TEXT;
        
        -- Alternar fechas: día 15 ↔ último día del mes
        IF EXTRACT(DAY FROM v_current_payment_date) = 15 THEN
            v_current_payment_date := (DATE_TRUNC('month', v_current_payment_date) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
        ELSE
            v_current_payment_date := MAKE_DATE(
                EXTRACT(YEAR FROM v_current_payment_date + INTERVAL '1 month')::INTEGER,
                EXTRACT(MONTH FROM v_current_payment_date + INTERVAL '1 month')::INTEGER,
                15
            );
        END IF;
    END LOOP;
    
    RETURN;
END;
$$;


ALTER FUNCTION public.calculate_payment_preview(p_approval_timestamp timestamp with time zone, p_term_biweeks integer, p_amount numeric) OWNER TO credinet_user;

--
-- TOC entry 4432 (class 0 OID 0)
-- Dependencies: 338
-- Name: FUNCTION calculate_payment_preview(p_approval_timestamp timestamp with time zone, p_term_biweeks integer, p_amount numeric); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.calculate_payment_preview(p_approval_timestamp timestamp with time zone, p_term_biweeks integer, p_amount numeric) IS 'Genera un preview del cronograma de pagos sin persistir en BD (útil para mostrar al usuario antes de aprobar).';


--
-- TOC entry 339 (class 1255 OID 16400)
-- Name: check_associate_available_credit(integer, numeric); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.check_associate_available_credit(p_associate_profile_id integer, p_requested_amount numeric) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Simplemente llamar a la función correcta
    RETURN check_associate_credit_available(p_associate_profile_id, p_requested_amount);
END;
$$;


ALTER FUNCTION public.check_associate_available_credit(p_associate_profile_id integer, p_requested_amount numeric) OWNER TO credinet_user;

--
-- TOC entry 4433 (class 0 OID 0)
-- Dependencies: 339
-- Name: FUNCTION check_associate_available_credit(p_associate_profile_id integer, p_requested_amount numeric); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.check_associate_available_credit(p_associate_profile_id integer, p_requested_amount numeric) IS 'Alias de check_associate_credit_available para compatibilidad con código Python.';


--
-- TOC entry 340 (class 1255 OID 16401)
-- Name: check_associate_credit_available(integer, numeric); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.check_associate_credit_available(p_associate_profile_id integer, p_requested_amount numeric) RETURNS boolean
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_available_credit DECIMAL(12,2);
    v_credit_limit DECIMAL(12,2);
    v_pending_payments_total DECIMAL(12,2);
    v_consolidated_debt DECIMAL(12,2);
BEGIN
    SELECT credit_limit, pending_payments_total, consolidated_debt
    INTO v_credit_limit, v_pending_payments_total, v_consolidated_debt
    FROM associate_profiles
    WHERE id = p_associate_profile_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Perfil de asociado % no encontrado', p_associate_profile_id;
    END IF;

    v_available_credit := v_credit_limit - v_pending_payments_total - v_consolidated_debt;

    IF v_available_credit >= p_requested_amount THEN
        RETURN TRUE;
    ELSE
        RAISE NOTICE 'Crédito insuficiente. Disponible: %, Solicitado: %', v_available_credit, p_requested_amount;
        RETURN FALSE;
    END IF;
END;
$$;


ALTER FUNCTION public.check_associate_credit_available(p_associate_profile_id integer, p_requested_amount numeric) OWNER TO credinet_user;

--
-- TOC entry 4434 (class 0 OID 0)
-- Dependencies: 340
-- Name: FUNCTION check_associate_credit_available(p_associate_profile_id integer, p_requested_amount numeric); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.check_associate_credit_available(p_associate_profile_id integer, p_requested_amount numeric) IS '⭐ MIGRACIÓN 07: Valida si un asociado tiene crédito disponible suficiente para absorber un préstamo (credit_limit - credit_used - debt_balance >= monto).';


--
-- TOC entry 341 (class 1255 OID 16402)
-- Name: close_period_and_accumulate_debt(integer, integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.close_period_and_accumulate_debt(p_cut_period_id integer, p_closed_by integer) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_period_start DATE;
    v_period_end DATE;
    v_paid_status_id INTEGER;
    v_paid_not_reported_id INTEGER;
    v_paid_by_associate_id INTEGER;
    v_total_payments_marked INTEGER := 0;
    v_unreported_count INTEGER := 0;
    v_morosos_count INTEGER := 0;
BEGIN
    SELECT period_start_date, period_end_date
    INTO v_period_start, v_period_end
    FROM cut_periods
    WHERE id = p_cut_period_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Período de corte % no encontrado', p_cut_period_id;
    END IF;

    SELECT id INTO v_paid_status_id FROM payment_statuses WHERE name = 'PAID';
    SELECT id INTO v_paid_not_reported_id FROM payment_statuses WHERE name = 'PAID_NOT_REPORTED';
    SELECT id INTO v_paid_by_associate_id FROM payment_statuses WHERE name = 'PAID_BY_ASSOCIATE';

    RAISE NOTICE '🔒 Cerrando período %: % a %', p_cut_period_id, v_period_start, v_period_end;

    WITH updated AS (
        UPDATE payments
        SET status_id = v_paid_status_id,
            updated_at = CURRENT_TIMESTAMP
        WHERE cut_period_id = p_cut_period_id
          AND status_id NOT IN (v_paid_status_id, v_paid_not_reported_id, v_paid_by_associate_id)
          AND amount_paid > 0
        RETURNING id
    )
    SELECT COUNT(*) INTO v_total_payments_marked FROM updated;

    RAISE NOTICE '✅ Pagos reportados marcados como PAID: %', v_total_payments_marked;

    WITH updated AS (
        UPDATE payments
        SET status_id = v_paid_not_reported_id,
            updated_at = CURRENT_TIMESTAMP
        WHERE cut_period_id = p_cut_period_id
          AND status_id NOT IN (v_paid_status_id, v_paid_not_reported_id, v_paid_by_associate_id)
          AND (amount_paid = 0 OR amount_paid IS NULL)
        RETURNING id
    )
    SELECT COUNT(*) INTO v_unreported_count FROM updated;

    RAISE NOTICE '⚠️ Pagos NO reportados: %', v_unreported_count;

    UPDATE cut_periods
    SET status_id = (SELECT id FROM cut_period_statuses WHERE name = 'CLOSED'),
        closed_by = p_closed_by,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_cut_period_id;

    INSERT INTO associate_debt_breakdown (
        associate_profile_id, cut_period_id, debt_type, loan_id, client_user_id, amount, description, is_liquidated
    )
    SELECT 
        ap.id, p.cut_period_id, 'UNREPORTED_PAYMENT', l.id, l.user_id,
        p.expected_amount, 'Pago no reportado al cierre del período', false
    FROM payments p
    JOIN loans l ON p.loan_id = l.id
    JOIN associate_profiles ap ON l.associate_user_id = ap.user_id
    WHERE p.cut_period_id = p_cut_period_id
      AND p.status_id = v_paid_not_reported_id;

    -- Actualizar consolidated_debt (antes debt_balance)
    UPDATE associate_profiles ap
    SET consolidated_debt = (
        SELECT COALESCE(SUM(amount), 0)
        FROM associate_debt_breakdown adb
        WHERE adb.associate_profile_id = ap.id
          AND adb.is_liquidated = false
    );

    RAISE NOTICE '✅ Período % cerrado exitosamente', p_cut_period_id;
END;
$$;


ALTER FUNCTION public.close_period_and_accumulate_debt(p_cut_period_id integer, p_closed_by integer) OWNER TO credinet_user;

--
-- TOC entry 4435 (class 0 OID 0)
-- Dependencies: 341
-- Name: FUNCTION close_period_and_accumulate_debt(p_cut_period_id integer, p_closed_by integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.close_period_and_accumulate_debt(p_cut_period_id integer, p_closed_by integer) IS '⭐ MIGRACIÓN 08 v3: Cierra un período de corte marcando TODOS los pagos según regla: reportados→PAID, no reportados→PAID_NOT_REPORTED, morosos→PAID_BY_ASSOCIATE.';


--
-- TOC entry 342 (class 1255 OID 16403)
-- Name: detect_suspicious_payment_changes(integer, integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.detect_suspicious_payment_changes(p_days_back integer DEFAULT 7, p_min_changes integer DEFAULT 3) RETURNS TABLE(payment_id integer, loan_id integer, client_name text, total_changes bigint, last_change timestamp with time zone, status_sequence text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        p.id,
        p.loan_id,
        CONCAT(u.first_name, ' ', u.last_name),
        COUNT(psh.id),
        MAX(psh.changed_at),
        STRING_AGG(ps.name, ' → ' ORDER BY psh.changed_at)
    FROM payments p
    JOIN payment_status_history psh ON p.id = psh.payment_id
    JOIN payment_statuses ps ON psh.new_status_id = ps.id
    JOIN loans l ON p.loan_id = l.id
    JOIN users u ON l.user_id = u.id
    WHERE psh.changed_at >= CURRENT_TIMESTAMP - (p_days_back || ' days')::INTERVAL
    GROUP BY p.id, p.loan_id, u.first_name, u.last_name
    HAVING COUNT(psh.id) >= p_min_changes
    ORDER BY COUNT(psh.id) DESC, MAX(psh.changed_at) DESC;
END;
$$;


ALTER FUNCTION public.detect_suspicious_payment_changes(p_days_back integer, p_min_changes integer) OWNER TO credinet_user;

--
-- TOC entry 4436 (class 0 OID 0)
-- Dependencies: 342
-- Name: FUNCTION detect_suspicious_payment_changes(p_days_back integer, p_min_changes integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.detect_suspicious_payment_changes(p_days_back integer, p_min_changes integer) IS '⭐ MIGRACIÓN 12: Detecta pagos con patrones anómalos (3+ cambios de estado en N días). Útil para detección de fraude o errores.';


--
-- TOC entry 343 (class 1255 OID 16404)
-- Name: finalize_statements_manual(integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.finalize_statements_manual(p_cut_period_id integer) RETURNS TABLE(finalized_count integer, total_finalized numeric, period_code character varying)
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_draft_count INTEGER;
    v_updated_count INTEGER;
    v_total NUMERIC(12,2);
    v_period_code VARCHAR(20);
BEGIN
    -- Obtener información del periodo
    SELECT cut_code INTO v_period_code
    FROM cut_periods
    WHERE id = p_cut_period_id;
    
    IF v_period_code IS NULL THEN
        RAISE EXCEPTION 'Periodo con ID % no encontrado', p_cut_period_id;
    END IF;
    
    -- Verificar que existan statements en DRAFT
    SELECT COUNT(*) INTO v_draft_count
    FROM associate_payment_statements
    WHERE cut_period_id = p_cut_period_id
      AND status_id = 6;  -- DRAFT
    
    IF v_draft_count = 0 THEN
        RAISE EXCEPTION 'No hay statements en DRAFT para finalizar en periodo %', v_period_code;
    END IF;
    
    RAISE NOTICE '🔒 Finalizando % statements en periodo %', v_draft_count, v_period_code;
    
    -- Cambiar estado de DRAFT (6) → FINALIZED (7)
    UPDATE associate_payment_statements
    SET 
        status_id = 7,  -- FINALIZED
        updated_at = CURRENT_TIMESTAMP
    WHERE cut_period_id = p_cut_period_id
      AND status_id = 6;
    
    GET DIAGNOSTICS v_updated_count = ROW_COUNT;
    
    -- Calcular total finalizado
    SELECT COALESCE(SUM(total_amount_collected), 0) INTO v_total
    FROM associate_payment_statements
    WHERE cut_period_id = p_cut_period_id AND status_id = 7;
    
    RAISE NOTICE '✅ Corte manual completado: % statements FINALIZADOS (bloqueados), Total: $%',
        v_updated_count, v_total;
    
    RAISE NOTICE '📧 TODO: Enviar notificaciones a asociados';
    
    -- Retornar resumen
    RETURN QUERY SELECT v_updated_count, v_total, v_period_code;
END;
$_$;


ALTER FUNCTION public.finalize_statements_manual(p_cut_period_id integer) OWNER TO credinet_user;

--
-- TOC entry 4437 (class 0 OID 0)
-- Dependencies: 343
-- Name: FUNCTION finalize_statements_manual(p_cut_period_id integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.finalize_statements_manual(p_cut_period_id integer) IS '✅ CORTE MANUAL (Horario Laboral - Admin ejecuta)
Cambia statements de DRAFT → FINALIZED (bloqueados).
Después de esto, NO se permiten modificaciones.
Admin debe ejecutar manualmente después de revisar statements en DRAFT.';


--
-- TOC entry 344 (class 1255 OID 16405)
-- Name: generate_amortization_schedule(numeric, numeric, integer, numeric, date); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.generate_amortization_schedule(p_amount numeric, p_biweekly_payment numeric, p_term_biweeks integer, p_commission_rate numeric, p_start_date date) RETURNS TABLE(periodo integer, fecha_pago date, pago_cliente numeric, interes_cliente numeric, capital_cliente numeric, saldo_pendiente numeric, comision_socio numeric, pago_socio numeric, saldo_asociado numeric)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_current_date DATE;
    v_balance DECIMAL(12,2);
    v_associate_balance DECIMAL(12,2); -- ✅ NUEVO
    v_total_interest DECIMAL(12,2);
    v_period_interest DECIMAL(10,2);
    v_period_principal DECIMAL(10,2);
    v_commission DECIMAL(10,2);
    v_payment_to_associate DECIMAL(10,2);
    v_is_day_15 BOOLEAN;
BEGIN
    -- Inicializar
    v_balance := p_amount;
    v_total_interest := (p_biweekly_payment * p_term_biweeks) - p_amount;
    v_current_date := p_start_date;
    
    -- Calcular comisión y pago al asociado (fijos por periodo)
    v_commission := p_amount * (p_commission_rate / 100);
    v_payment_to_associate := p_biweekly_payment - v_commission;
    
    -- Inicializar saldo asociado (Total a pagar por asociado)
    v_associate_balance := v_payment_to_associate * p_term_biweeks;

    -- Generar cronograma completo
    FOR v_period IN 1..p_term_biweeks LOOP
        -- Calcular interés y capital del período (distribución proporcional)
        v_period_interest := v_total_interest / p_term_biweeks;
        v_period_principal := p_biweekly_payment - v_period_interest;

        -- Actualizar saldo cliente
        v_balance := v_balance - v_period_principal;
        IF v_balance < 0.01 THEN v_balance := 0; END IF;
        
        -- Actualizar saldo asociado
        v_associate_balance := v_associate_balance - v_payment_to_associate;
        IF v_associate_balance < 0.01 THEN v_associate_balance := 0; END IF;

        -- Retornar fila
        RETURN QUERY SELECT
            v_period,
            v_current_date,
            p_biweekly_payment,
            ROUND(v_period_interest, 2),
            ROUND(v_period_principal, 2),
            ROUND(v_balance, 2),
            ROUND(v_commission, 2),
            ROUND(v_payment_to_associate, 2),
            ROUND(v_associate_balance, 2); -- ✅ RETORNAR NUEVO SALDO

        -- Calcular siguiente fecha
        v_is_day_15 := EXTRACT(DAY FROM v_current_date) = 15;

        IF v_is_day_15 THEN
            v_current_date := (DATE_TRUNC('month', v_current_date) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
        ELSE
            v_current_date := MAKE_DATE(
                EXTRACT(YEAR FROM v_current_date + INTERVAL '1 month')::INTEGER,
                EXTRACT(MONTH FROM v_current_date + INTERVAL '1 month')::INTEGER,
                15
            );
        END IF;
    END LOOP;
END;
$$;


ALTER FUNCTION public.generate_amortization_schedule(p_amount numeric, p_biweekly_payment numeric, p_term_biweeks integer, p_commission_rate numeric, p_start_date date) OWNER TO credinet_user;

--
-- TOC entry 345 (class 1255 OID 16406)
-- Name: generate_loan_summary(numeric, integer, numeric, numeric); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.generate_loan_summary(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric) RETURNS TABLE(capital numeric, plazo_quincenas integer, tasa_interes_quincenal numeric, tasa_comision numeric, pago_quincenal_cliente numeric, pago_total_cliente numeric, interes_total_cliente numeric, tasa_efectiva_cliente numeric, comision_por_pago numeric, comision_total_socio numeric, pago_quincenal_socio numeric, pago_total_socio numeric)
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    v_factor DECIMAL(10,6);
    v_total_cliente DECIMAL(12,2);
    v_pago_q_cliente DECIMAL(10,2);
    v_interes_cliente DECIMAL(12,2);
    v_comision_por_pago DECIMAL(10,2);
    v_comision_total DECIMAL(12,2);
    v_pago_q_socio DECIMAL(10,2);
BEGIN
    -- Calcular CLIENTE (Interés Simple)
    v_factor := 1 + (p_interest_rate / 100) * p_term_biweeks;
    v_total_cliente := p_amount * v_factor;
    v_pago_q_cliente := v_total_cliente / p_term_biweeks;
    v_interes_cliente := v_total_cliente - p_amount;
    
    -- Calcular SOCIO (Comisión sobre pago del cliente)
    v_comision_por_pago := v_pago_q_cliente * (p_commission_rate / 100);
    v_comision_total := v_comision_por_pago * p_term_biweeks;
    v_pago_q_socio := v_pago_q_cliente - v_comision_por_pago;
    
    RETURN QUERY SELECT
        p_amount AS capital,
        p_term_biweeks AS plazo_quincenas,
        
        p_interest_rate AS tasa_interes_quincenal,
        p_commission_rate AS tasa_comision,
        
        ROUND(v_pago_q_cliente, 2) AS pago_quincenal_cliente,
        ROUND(v_total_cliente, 2) AS pago_total_cliente,
        ROUND(v_interes_cliente, 2) AS interes_total_cliente,
        ROUND(((v_interes_cliente / p_amount * 100)::NUMERIC), 2) AS tasa_efectiva_cliente,
        
        ROUND(v_comision_por_pago, 2) AS comision_por_pago,
        ROUND(v_comision_total, 2) AS comision_total_socio,
        ROUND(v_pago_q_socio, 2) AS pago_quincenal_socio,
        ROUND(v_pago_q_socio * p_term_biweeks, 2) AS pago_total_socio;
END;
$$;


ALTER FUNCTION public.generate_loan_summary(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric) OWNER TO credinet_user;

--
-- TOC entry 4438 (class 0 OID 0)
-- Dependencies: 345
-- Name: FUNCTION generate_loan_summary(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.generate_loan_summary(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric) IS 'Genera tabla resumen completa con cálculos de CLIENTE y SOCIO (asociado). Muestra: pagos quincenales, totales, intereses, comisiones. Similar a tabla "Importe de prestamos" de la UI.';


--
-- TOC entry 346 (class 1255 OID 16407)
-- Name: generate_payment_schedule(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.generate_payment_schedule() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_approval_date DATE;
    v_first_payment_date DATE;
    v_active_status_id INTEGER;
    v_pending_status_id INTEGER;
    v_amortization_row RECORD;
    v_period_id INTEGER;
    v_total_inserted INTEGER := 0;
    v_sum_expected DECIMAL(12,2) := 0;
    v_start_time TIMESTAMP;
    v_end_time TIMESTAMP;
    v_total_associate_payment DECIMAL(12,2);
    v_cumulative_associate_paid DECIMAL(12,2) := 0;
    v_commission_rate_for_function DECIMAL(10,4);
BEGIN
    -- Get status IDs
    SELECT id INTO v_active_status_id FROM loan_statuses WHERE name = 'ACTIVE';
    SELECT id INTO v_pending_status_id FROM payment_statuses WHERE name = 'PENDING';

    IF v_active_status_id IS NULL THEN
        RAISE EXCEPTION 'CRITICAL: loan_statuses.ACTIVE not found';
    END IF;

    IF v_pending_status_id IS NULL THEN
        RAISE EXCEPTION 'CRITICAL: payment_statuses.PENDING not found';
    END IF;

    -- Only execute if loan just got activated
    IF NEW.status_id = v_active_status_id
       AND (OLD.status_id IS NULL OR OLD.status_id != v_active_status_id)
    THEN
        v_start_time := CLOCK_TIMESTAMP();

        -- Validations
        IF NEW.approved_at IS NULL THEN
            RAISE EXCEPTION 'CRITICAL: Loan % marked as ACTIVE but approved_at is NULL', NEW.id;
        END IF;

        IF NEW.term_biweeks IS NULL OR NEW.term_biweeks <= 0 THEN
            RAISE EXCEPTION 'CRITICAL: Loan % has invalid term_biweeks: %', NEW.id, NEW.term_biweeks;
        END IF;

        IF NEW.biweekly_payment IS NULL THEN
            RAISE EXCEPTION 'CRITICAL: Loan % does not have biweekly_payment calculated', NEW.id;
        END IF;

        v_approval_date := NEW.approved_at::DATE;
        v_first_payment_date := calculate_first_payment_date(v_approval_date);

        -- Calculate commission rate for the function
        IF COALESCE(NEW.commission_per_payment, 0) > 0 AND NEW.amount > 0 THEN
            v_commission_rate_for_function := (NEW.commission_per_payment / NEW.amount) * 100;
        ELSE
            v_commission_rate_for_function := 0;
        END IF;

        RAISE NOTICE 'Generating schedule for loan %: Amount=$%, Term=%, Biweekly=$%, CommPerPmt=$%, Profile=%',
            NEW.id, NEW.amount, NEW.term_biweeks, NEW.biweekly_payment,
            COALESCE(NEW.commission_per_payment, 0), COALESCE(NEW.profile_code, 'N/A');

        -- Calculate total associate payment for this loan
        SELECT SUM(pago_socio) INTO v_total_associate_payment
        FROM generate_amortization_schedule(
            NEW.amount,
            NEW.biweekly_payment,
            NEW.term_biweeks,
            v_commission_rate_for_function,
            v_first_payment_date
        );

        -- Generate complete schedule with breakdown
        FOR v_amortization_row IN
            SELECT
                periodo,
                fecha_pago,
                pago_cliente,
                interes_cliente,
                capital_cliente,
                saldo_pendiente,
                comision_socio,
                pago_socio
            FROM generate_amortization_schedule(
                NEW.amount,
                NEW.biweekly_payment,
                NEW.term_biweeks,
                v_commission_rate_for_function,
                v_first_payment_date
            )
        LOOP
            -- Accumulate associate payment
            v_cumulative_associate_paid := v_cumulative_associate_paid + v_amortization_row.pago_socio;

            -- ✅ LÓGICA CORRECTA: Buscar el período cuyo period_end_date sea 
            -- INMEDIATAMENTE ANTERIOR a la fecha de pago
            -- (El pago del día 15 va al corte del 8, el del 31 va al corte del 23)
            SELECT id INTO v_period_id
            FROM cut_periods
            WHERE period_end_date < v_amortization_row.fecha_pago
            ORDER BY period_end_date DESC
            LIMIT 1;

            IF v_period_id IS NULL THEN
                RAISE WARNING 'No cut_period found for date %. Payment will have NULL period.',
                    v_amortization_row.fecha_pago;
            END IF;

            -- Insert payment
            INSERT INTO payments (
                loan_id, payment_number, expected_amount,
                principal_amount, interest_amount, commission_amount, associate_payment,
                cumulative_associate_paid, total_associate_payment,
                payment_due_date, status_id, cut_period_id, notes
            ) VALUES (
                NEW.id, v_amortization_row.periodo, v_amortization_row.pago_cliente,
                v_amortization_row.capital_cliente, v_amortization_row.interes_cliente,
                v_amortization_row.comision_socio, v_amortization_row.pago_socio,
                v_cumulative_associate_paid, v_total_associate_payment,
                v_amortization_row.fecha_pago, v_pending_status_id, v_period_id,
                FORMAT('Generado automáticamente - Perfil: %s', COALESCE(NEW.profile_code, 'N/A'))
            );

            v_total_inserted := v_total_inserted + 1;
            v_sum_expected := v_sum_expected + v_amortization_row.pago_cliente;
        END LOOP;

        v_end_time := CLOCK_TIMESTAMP();
        RAISE NOTICE 'Generated % payments in % ms - Total=$%',
            v_total_inserted,
            EXTRACT(MILLISECONDS FROM (v_end_time - v_start_time)),
            v_sum_expected;
    END IF;

    RETURN NEW;
END;
$_$;


ALTER FUNCTION public.generate_payment_schedule() OWNER TO credinet_user;

--
-- TOC entry 4439 (class 0 OID 0)
-- Dependencies: 346
-- Name: FUNCTION generate_payment_schedule(); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.generate_payment_schedule() IS 'Trigger that generates payment schedule when a loan is approved.
✅ VERSION 2.1 - FIXED
- Includes associate_balance_remaining calculation
- Uses cumulative sum to track associate debt';


--
-- TOC entry 347 (class 1255 OID 16409)
-- Name: get_cut_period_for_payment(date); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.get_cut_period_for_payment(p_payment_date date) RETURNS integer
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    v_period_id INTEGER;
    v_day INTEGER;
    v_month INTEGER;
    v_year INTEGER;
BEGIN
    v_day := EXTRACT(DAY FROM p_payment_date)::INTEGER;
    v_month := EXTRACT(MONTH FROM p_payment_date)::INTEGER;
    v_year := EXTRACT(YEAR FROM p_payment_date)::INTEGER;
    
    -- Determinar si es día 15 o último día del mes
    IF v_day = 15 THEN
        -- Pago día 15 → Buscar periodo que cierra día 7-8 (aproximado) ANTES del día 15
        SELECT id INTO v_period_id
        FROM cut_periods
        WHERE EXTRACT(DAY FROM period_end_date) BETWEEN 6 AND 8  -- Cierra ~día 7
          AND period_end_date < p_payment_date  -- Cierra ANTES del vencimiento
          AND EXTRACT(MONTH FROM period_end_date) = v_month  -- Mismo mes
          AND EXTRACT(YEAR FROM period_end_date) = v_year
        ORDER BY period_end_date DESC
        LIMIT 1;
        
        -- Si no encontró en el mismo mes, buscar a fin del mes anterior
        IF v_period_id IS NULL THEN
            SELECT id INTO v_period_id
            FROM cut_periods
            WHERE EXTRACT(DAY FROM period_end_date) BETWEEN 6 AND 8
              AND period_end_date < p_payment_date
              AND (
                  (EXTRACT(MONTH FROM period_end_date) = v_month - 1 AND EXTRACT(YEAR FROM period_end_date) = v_year) OR
                  (v_month = 1 AND EXTRACT(MONTH FROM period_end_date) = 12 AND EXTRACT(YEAR FROM period_end_date) = v_year - 1)
              )
            ORDER BY period_end_date DESC
            LIMIT 1;
        END IF;
        
    ELSE
        -- Pago último día → Buscar periodo que cierra día 22-23 ANTES del último día
        SELECT id INTO v_period_id
        FROM cut_periods
        WHERE EXTRACT(DAY FROM period_end_date) BETWEEN 21 AND 23  -- Cierra ~día 22
          AND period_end_date < p_payment_date  -- Cierra ANTES del vencimiento
          AND EXTRACT(MONTH FROM period_end_date) = v_month  -- Mismo mes
          AND EXTRACT(YEAR FROM period_end_date) = v_year
        ORDER BY period_end_date DESC
        LIMIT 1;
    END IF;
    
    -- Si aún no encontró, usar lógica de fallback (contención)
    IF v_period_id IS NULL THEN
        RAISE WARNING 'No se encontró periodo con cierre antes de %. Usando fallback.', p_payment_date;
        SELECT id INTO v_period_id
        FROM cut_periods
        WHERE period_start_date <= p_payment_date
          AND period_end_date >= p_payment_date
        ORDER BY period_start_date DESC
        LIMIT 1;
    END IF;
    
    RETURN v_period_id;
END;
$$;


ALTER FUNCTION public.get_cut_period_for_payment(p_payment_date date) OWNER TO credinet_user;

--
-- TOC entry 4440 (class 0 OID 0)
-- Dependencies: 347
-- Name: FUNCTION get_cut_period_for_payment(p_payment_date date); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.get_cut_period_for_payment(p_payment_date date) IS 'Asigna el periodo de corte correcto para una fecha de pago. 
Día 15 → periodo con cierre ~día 8 anterior.
Último día → periodo con cierre ~día 23 anterior.';


--
-- TOC entry 348 (class 1255 OID 16410)
-- Name: get_debt_payment_detail(integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.get_debt_payment_detail(p_debt_payment_id integer) RETURNS TABLE(breakdown_id integer, cut_period_id integer, period_description character varying, original_amount numeric, amount_applied numeric, liquidated boolean, remaining_amount numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        (item->>'breakdown_id')::INTEGER AS breakdown_id,
        (item->>'cut_period_id')::INTEGER AS cut_period_id,
        COALESCE(
            cp.description,
            'Período ' || TO_CHAR(cp.start_date, 'DD/MM/YYYY') || ' - ' || TO_CHAR(cp.end_date, 'DD/MM/YYYY')
        ) AS period_description,
        (item->>'original_amount')::DECIMAL(12,2) AS original_amount,
        (item->>'amount_applied')::DECIMAL(12,2) AS amount_applied,
        (item->>'liquidated')::BOOLEAN AS liquidated,
        COALESCE((item->>'remaining_amount')::DECIMAL(12,2), 0) AS remaining_amount
    FROM associate_debt_payments adp
    CROSS JOIN jsonb_array_elements(adp.applied_breakdown_items) AS item
    LEFT JOIN cut_periods cp ON cp.id = (item->>'cut_period_id')::INTEGER
    WHERE adp.id = p_debt_payment_id;
END;
$$;


ALTER FUNCTION public.get_debt_payment_detail(p_debt_payment_id integer) OWNER TO credinet_user;

--
-- TOC entry 4441 (class 0 OID 0)
-- Dependencies: 348
-- Name: FUNCTION get_debt_payment_detail(p_debt_payment_id integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.get_debt_payment_detail(p_debt_payment_id integer) IS '⭐ v2.0.4: Función helper para obtener el detalle desglosado de items de deuda liquidados por un abono específico. Retorna tabla con breakdown_id, montos aplicados, y estado de liquidación.';


--
-- TOC entry 315 (class 1255 OID 16411)
-- Name: get_payment_history(integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.get_payment_history(p_payment_id integer) RETURNS TABLE(change_id integer, old_status character varying, new_status character varying, change_type character varying, changed_by_username character varying, change_reason text, changed_at timestamp with time zone)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        psh.id,
        ps_old.name,
        ps_new.name,
        psh.change_type,
        u.username,
        psh.change_reason,
        psh.changed_at
    FROM payment_status_history psh
    LEFT JOIN payment_statuses ps_old ON psh.old_status_id = ps_old.id
    JOIN payment_statuses ps_new ON psh.new_status_id = ps_new.id
    LEFT JOIN users u ON psh.changed_by = u.id
    WHERE psh.payment_id = p_payment_id
    ORDER BY psh.changed_at DESC;
END;
$$;


ALTER FUNCTION public.get_payment_history(p_payment_id integer) OWNER TO credinet_user;

--
-- TOC entry 4442 (class 0 OID 0)
-- Dependencies: 315
-- Name: FUNCTION get_payment_history(p_payment_id integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.get_payment_history(p_payment_id integer) IS '⭐ MIGRACIÓN 12: Obtiene el historial completo de cambios de estado de un pago (timeline forense).';


--
-- TOC entry 349 (class 1255 OID 16412)
-- Name: handle_loan_approval_status(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.handle_loan_approval_status() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_approved_status_id INTEGER;
    v_rejected_status_id INTEGER;
BEGIN
    -- Obtener IDs de estados APPROVED y REJECTED
    SELECT id INTO v_approved_status_id FROM loan_statuses WHERE name = 'APPROVED';
    SELECT id INTO v_rejected_status_id FROM loan_statuses WHERE name = 'REJECTED';
    
    -- Si cambió a APPROVED, setear timestamp
    IF NEW.status_id = v_approved_status_id AND (OLD.status_id IS NULL OR OLD.status_id != v_approved_status_id) AND NEW.approved_at IS NULL THEN
        NEW.approved_at = CURRENT_TIMESTAMP;
    END IF;
    
    -- Si cambió a REJECTED, setear timestamp  
    IF NEW.status_id = v_rejected_status_id AND (OLD.status_id IS NULL OR OLD.status_id != v_rejected_status_id) AND NEW.rejected_at IS NULL THEN
        NEW.rejected_at = CURRENT_TIMESTAMP;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.handle_loan_approval_status() OWNER TO credinet_user;

--
-- TOC entry 4443 (class 0 OID 0)
-- Dependencies: 349
-- Name: FUNCTION handle_loan_approval_status(); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.handle_loan_approval_status() IS 'Trigger function: Setea automáticamente approved_at o rejected_at cuando el estado del préstamo cambia.';


--
-- TOC entry 350 (class 1255 OID 16413)
-- Name: log_payment_status_change(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.log_payment_status_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_change_type VARCHAR(50);
    v_changed_by INTEGER;
BEGIN
    -- Solo registrar si el status_id cambió
    IF OLD.status_id IS DISTINCT FROM NEW.status_id THEN
        
        -- Determinar tipo de cambio
        IF NEW.marked_by IS NOT NULL THEN
            v_change_type := 'MANUAL_ADMIN';
            v_changed_by := NEW.marked_by;
        ELSE
            v_change_type := 'AUTOMATIC';
            v_changed_by := NULL;
        END IF;
        
        -- Insertar en historial
        INSERT INTO payment_status_history (
            payment_id,
            old_status_id,
            new_status_id,
            change_type,
            changed_by,
            change_reason,
            changed_at
        ) VALUES (
            NEW.id,
            OLD.status_id,
            NEW.status_id,
            v_change_type,
            v_changed_by,
            NEW.marking_notes,
            CURRENT_TIMESTAMP
        );
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.log_payment_status_change() OWNER TO credinet_user;

--
-- TOC entry 4444 (class 0 OID 0)
-- Dependencies: 350
-- Name: FUNCTION log_payment_status_change(); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.log_payment_status_change() IS '⭐ MIGRACIÓN 12: Trigger function que registra automáticamente todos los cambios de estado de pagos en payment_status_history para auditoría completa.';


--
-- TOC entry 351 (class 1255 OID 16414)
-- Name: renew_loan(integer, numeric, integer, numeric, numeric, integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.renew_loan(p_original_loan_id integer, p_new_amount numeric, p_new_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_created_by integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_client_user_id INTEGER;
    v_associate_user_id INTEGER;
    v_pending_balance DECIMAL(12,2);
    v_new_loan_id INTEGER;
    v_pending_status_id INTEGER;
BEGIN
    -- Obtener datos del préstamo original
    SELECT 
        user_id,
        associate_user_id
    INTO 
        v_client_user_id,
        v_associate_user_id
    FROM loans
    WHERE id = p_original_loan_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Préstamo original % no encontrado', p_original_loan_id;
    END IF;
    
    -- Calcular saldo pendiente
    v_pending_balance := calculate_loan_remaining_balance(p_original_loan_id);
    
    -- Obtener ID del estado PENDING
    SELECT id INTO v_pending_status_id FROM loan_statuses WHERE name = 'PENDING';
    
    -- Crear nuevo préstamo
    INSERT INTO loans (
        user_id,
        associate_user_id,
        amount,
        interest_rate,
        commission_rate,
        term_biweeks,
        status_id,
        notes,
        created_at
    ) VALUES (
        v_client_user_id,
        v_associate_user_id,
        p_new_amount,
        p_interest_rate,
        p_commission_rate,
        p_new_term_biweeks,
        v_pending_status_id,
        'Renovación de préstamo #' || p_original_loan_id || '. Saldo pendiente: ' || v_pending_balance,
        CURRENT_TIMESTAMP
    ) RETURNING id INTO v_new_loan_id;
    
    -- Registrar la renovación
    INSERT INTO loan_renewals (
        original_loan_id,
        renewed_loan_id,
        renewal_date,
        pending_balance,
        new_amount,
        reason,
        created_by
    ) VALUES (
        p_original_loan_id,
        v_new_loan_id,
        CURRENT_DATE,
        v_pending_balance,
        p_new_amount,
        'Renovación estándar',
        p_created_by
    );
    
    RAISE NOTICE '✅ Préstamo % renovado como préstamo %. Saldo pendiente: %, Nuevo monto: %',
        p_original_loan_id, v_new_loan_id, v_pending_balance, p_new_amount;
    
    RETURN v_new_loan_id;
END;
$$;


ALTER FUNCTION public.renew_loan(p_original_loan_id integer, p_new_amount numeric, p_new_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_created_by integer) OWNER TO credinet_user;

--
-- TOC entry 4445 (class 0 OID 0)
-- Dependencies: 351
-- Name: FUNCTION renew_loan(p_original_loan_id integer, p_new_amount numeric, p_new_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_created_by integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.renew_loan(p_original_loan_id integer, p_new_amount numeric, p_new_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_created_by integer) IS 'Renueva un préstamo existente creando uno nuevo. Calcula automáticamente el saldo pendiente y lo registra en loan_renewals.';


--
-- TOC entry 352 (class 1255 OID 16415)
-- Name: report_defaulted_client(integer, integer, integer, numeric, text, character varying); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.report_defaulted_client(p_associate_profile_id integer, p_loan_id integer, p_reported_by integer, p_total_debt_amount numeric, p_evidence_details text, p_evidence_file_path character varying DEFAULT NULL::character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_client_user_id INTEGER;
    v_report_id INTEGER;
BEGIN
    -- Obtener ID del cliente desde el préstamo
    SELECT user_id INTO v_client_user_id
    FROM loans
    WHERE id = p_loan_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Préstamo % no encontrado', p_loan_id;
    END IF;
    
    -- Insertar reporte de morosidad
    INSERT INTO defaulted_client_reports (
        associate_profile_id,
        loan_id,
        client_user_id,
        reported_by,
        total_debt_amount,
        evidence_details,
        evidence_file_path,
        status
    ) VALUES (
        p_associate_profile_id,
        p_loan_id,
        v_client_user_id,
        p_reported_by,
        p_total_debt_amount,
        p_evidence_details,
        p_evidence_file_path,
        'PENDING'
    ) RETURNING id INTO v_report_id;
    
    RAISE NOTICE '📋 Reporte de morosidad creado: ID %, Cliente %, Deuda: %', 
        v_report_id, v_client_user_id, p_total_debt_amount;
    
    RETURN v_report_id;
END;
$$;


ALTER FUNCTION public.report_defaulted_client(p_associate_profile_id integer, p_loan_id integer, p_reported_by integer, p_total_debt_amount numeric, p_evidence_details text, p_evidence_file_path character varying) OWNER TO credinet_user;

--
-- TOC entry 4446 (class 0 OID 0)
-- Dependencies: 352
-- Name: FUNCTION report_defaulted_client(p_associate_profile_id integer, p_loan_id integer, p_reported_by integer, p_total_debt_amount numeric, p_evidence_details text, p_evidence_file_path character varying); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.report_defaulted_client(p_associate_profile_id integer, p_loan_id integer, p_reported_by integer, p_total_debt_amount numeric, p_evidence_details text, p_evidence_file_path character varying) IS '⭐ MIGRACIÓN 09: Permite a un asociado reportar un cliente moroso con evidencia. El reporte queda en estado PENDING hasta aprobación administrativa.';


--
-- TOC entry 353 (class 1255 OID 16416)
-- Name: revert_last_payment_change(integer, integer, text); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.revert_last_payment_change(p_payment_id integer, p_admin_user_id integer, p_reason text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_last_old_status_id INTEGER;
    v_current_status_id INTEGER;
BEGIN
    -- Obtener estado actual
    SELECT status_id INTO v_current_status_id
    FROM payments
    WHERE id = p_payment_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Pago % no encontrado', p_payment_id;
    END IF;
    
    -- Obtener el estado anterior (último cambio)
    SELECT old_status_id INTO v_last_old_status_id
    FROM payment_status_history
    WHERE payment_id = p_payment_id
    ORDER BY changed_at DESC
    LIMIT 1;
    
    IF v_last_old_status_id IS NULL THEN
        RAISE EXCEPTION 'No hay historial previo para revertir el pago %', p_payment_id;
    END IF;
    
    -- Revertir al estado anterior
    UPDATE payments
    SET 
        status_id = v_last_old_status_id,
        marked_by = p_admin_user_id,
        marked_at = CURRENT_TIMESTAMP,
        marking_notes = 'REVERSIÓN: ' || p_reason,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_payment_id;
    
    RAISE NOTICE 'Pago % revertido de estado % a estado % por usuario %', 
        p_payment_id, v_current_status_id, v_last_old_status_id, p_admin_user_id;
END;
$$;


ALTER FUNCTION public.revert_last_payment_change(p_payment_id integer, p_admin_user_id integer, p_reason text) OWNER TO credinet_user;

--
-- TOC entry 4447 (class 0 OID 0)
-- Dependencies: 353
-- Name: FUNCTION revert_last_payment_change(p_payment_id integer, p_admin_user_id integer, p_reason text); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.revert_last_payment_change(p_payment_id integer, p_admin_user_id integer, p_reason text) IS '⭐ MIGRACIÓN 12: Revierte el último cambio de estado de un pago (función de emergencia para corregir errores).';


--
-- TOC entry 354 (class 1255 OID 16417)
-- Name: rollback_credit_liberation_v2(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.rollback_credit_liberation_v2() RETURNS text
    LANGUAGE plpgsql
    AS $$
BEGIN
    -- Recrear el trigger que eliminamos (por si se necesita rollback)
    CREATE TRIGGER trigger_update_associate_credit_on_payment
        AFTER UPDATE OF amount_paid ON payments
        FOR EACH ROW
        EXECUTE FUNCTION trigger_update_associate_credit_on_payment();
    
    RETURN 'Trigger restaurado. NOTA: Este trigger libera crédito prematuramente.';
END;
$$;


ALTER FUNCTION public.rollback_credit_liberation_v2() OWNER TO credinet_user;

--
-- TOC entry 4448 (class 0 OID 0)
-- Dependencies: 354
-- Name: FUNCTION rollback_credit_liberation_v2(); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.rollback_credit_liberation_v2() IS '⚠️ ROLLBACK: Restaura el trigger en payments (NO recomendado). Solo usar si se detectan problemas graves.';


--
-- TOC entry 355 (class 1255 OID 16418)
-- Name: simulate_loan(numeric, integer, character varying, date); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.simulate_loan(p_amount numeric, p_term_biweeks integer, p_profile_code character varying, p_approval_date date DEFAULT CURRENT_DATE) RETURNS TABLE(payment_number integer, payment_date date, cut_period_code character varying, client_payment numeric, associate_payment numeric, commission_amount numeric, remaining_balance numeric, associate_remaining_balance numeric)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_calc RECORD;
    v_current_date DATE;
    v_balance DECIMAL(12,2);
    v_associate_balance DECIMAL(12,2); -- ✅ NUEVO
    v_cut_code VARCHAR(20);
    v_period_capital DECIMAL(12,2);
    v_period_id INTEGER;
    i INTEGER;
BEGIN
    -- Obtener cálculos del perfil
    SELECT * INTO v_calc
    FROM calculate_loan_payment(p_amount, p_term_biweeks, p_profile_code);

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Perfil % no encontrado', p_profile_code;
    END IF;

    v_current_date := calculate_first_payment_date(p_approval_date);
    v_balance := p_amount;
    
    -- Inicializar saldo asociado
    v_associate_balance := v_calc.associate_payment * p_term_biweeks;

    v_period_capital := p_amount / p_term_biweeks;

    FOR i IN 1..p_term_biweeks LOOP
        v_period_id := get_cut_period_for_payment(v_current_date);

        IF v_period_id IS NOT NULL THEN
            SELECT cut_code INTO v_cut_code FROM cut_periods WHERE id = v_period_id;
        ELSE
            v_cut_code := EXTRACT(YEAR FROM v_current_date)::TEXT || '-Q' || LPAD(CEIL(EXTRACT(DOY FROM v_current_date) / 15)::TEXT, 2, '0');
        END IF;

        v_balance := v_balance - v_period_capital;
        IF v_balance < 0.01 THEN v_balance := 0; END IF;
        
        -- Actualizar saldo asociado
        v_associate_balance := v_associate_balance - v_calc.associate_payment;
        IF v_associate_balance < 0.01 THEN v_associate_balance := 0; END IF;

        RETURN QUERY SELECT
            i::INTEGER,
            v_current_date::DATE,
            v_cut_code::VARCHAR(20),
            v_calc.biweekly_payment::DECIMAL(10,2),
            v_calc.associate_payment::DECIMAL(10,2),
            v_calc.commission_per_payment::DECIMAL(10,2),
            v_balance::DECIMAL(12,2),
            v_associate_balance::DECIMAL(12,2); -- ✅ RETORNAR

        IF EXTRACT(DAY FROM v_current_date) = 15 THEN
            v_current_date := (DATE_TRUNC('month', v_current_date) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
        ELSE
            v_current_date := MAKE_DATE(
                EXTRACT(YEAR FROM v_current_date + INTERVAL '1 month')::INTEGER,
                EXTRACT(MONTH FROM v_current_date + INTERVAL '1 month')::INTEGER,
                15
            );
        END IF;
    END LOOP;
END;
$$;


ALTER FUNCTION public.simulate_loan(p_amount numeric, p_term_biweeks integer, p_profile_code character varying, p_approval_date date) OWNER TO credinet_user;

--
-- TOC entry 356 (class 1255 OID 16419)
-- Name: simulate_loan_complete(numeric, integer, character varying, date); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.simulate_loan_complete(p_amount numeric, p_term_biweeks integer, p_profile_code character varying, p_approval_date date DEFAULT CURRENT_DATE) RETURNS TABLE(section_type character varying, label character varying, value_text character varying, value_numeric numeric, payment_num integer, payment_date date, cut_code character varying, client_pay numeric, associate_pay numeric, commission numeric, balance numeric)
    LANGUAGE plpgsql STABLE
    AS $_$
DECLARE
    v_calc RECORD;
    v_profile RECORD;
BEGIN
    -- Obtener información del perfil y cálculos
    SELECT 
        rp.name as profile_name,
        c.*
    INTO v_calc
    FROM calculate_loan_payment(p_amount, p_term_biweeks, p_profile_code) c
    JOIN rate_profiles rp ON rp.code = p_profile_code;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Perfil % no encontrado o deshabilitado', p_profile_code;
    END IF;
    
    -- =========================================================================
    -- SECCIÓN 1: RESUMEN DEL PRÉSTAMO
    -- =========================================================================
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20),
        'Perfil'::VARCHAR(100),
        v_calc.profile_name::VARCHAR(100),
        NULL::DECIMAL(12,2),
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20), 'Monto Solicitado'::VARCHAR(100),
        ('$' || p_amount::TEXT)::VARCHAR(100), p_amount,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20), 'Plazo'::VARCHAR(100),
        (p_term_biweeks || ' quincenas')::VARCHAR(100), p_term_biweeks::DECIMAL(12,2),
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20), 'Tasa de Interés'::VARCHAR(100),
        (v_calc.interest_rate_percent || '%')::VARCHAR(100), v_calc.interest_rate_percent,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20), 'Tasa de Comisión'::VARCHAR(100),
        (v_calc.commission_rate_percent || '%')::VARCHAR(100), v_calc.commission_rate_percent,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20), 'Fecha de Aprobación'::VARCHAR(100),
        TO_CHAR(p_approval_date, 'DD/MM/YYYY')::VARCHAR(100), NULL::DECIMAL(12,2),
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    -- Totales
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Pago Quincenal Cliente'::VARCHAR(100),
        ('$' || v_calc.biweekly_payment::TEXT)::VARCHAR(100), v_calc.biweekly_payment,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Total a Pagar (Cliente)'::VARCHAR(100),
        ('$' || v_calc.total_payment::TEXT)::VARCHAR(100), v_calc.total_payment,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Pago Quincenal Asociado'::VARCHAR(100),
        ('$' || v_calc.associate_payment::TEXT)::VARCHAR(100), v_calc.associate_payment,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Total Asociado → CrediCuenta'::VARCHAR(100),
        ('$' || v_calc.associate_total::TEXT)::VARCHAR(100), v_calc.associate_total,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Comisión por Pago'::VARCHAR(100),
        ('$' || v_calc.commission_per_payment::TEXT)::VARCHAR(100), v_calc.commission_per_payment,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Comisión Total Asociado'::VARCHAR(100),
        ('$' || v_calc.total_commission::TEXT)::VARCHAR(100), v_calc.total_commission,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    -- =========================================================================
    -- SECCIÓN 2: TABLA DE AMORTIZACIÓN
    -- =========================================================================
    RETURN QUERY 
    SELECT 
        'AMORTIZACIÓN'::VARCHAR(20),
        NULL::VARCHAR(100),
        NULL::VARCHAR(100),
        NULL::DECIMAL(12,2),
        s.payment_number,
        s.payment_date,
        s.cut_period_code,
        s.client_payment,
        s.associate_payment,
        s.commission_amount,
        s.remaining_balance
    FROM simulate_loan(p_amount, p_term_biweeks, p_profile_code, p_approval_date) s;
END;
$_$;


ALTER FUNCTION public.simulate_loan_complete(p_amount numeric, p_term_biweeks integer, p_profile_code character varying, p_approval_date date) OWNER TO credinet_user;

--
-- TOC entry 4449 (class 0 OID 0)
-- Dependencies: 356
-- Name: FUNCTION simulate_loan_complete(p_amount numeric, p_term_biweeks integer, p_profile_code character varying, p_approval_date date); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.simulate_loan_complete(p_amount numeric, p_term_biweeks integer, p_profile_code character varying, p_approval_date date) IS 'Simulador completo de préstamos con RESUMEN + TABLA DE AMORTIZACIÓN.
Incluye: perfil, tasas, totales, fechas de pago, períodos de corte.
Uso: SELECT * FROM simulate_loan_complete(10000, 12, ''standard'', ''2025-11-15'');';


--
-- TOC entry 357 (class 1255 OID 16420)
-- Name: simulate_loan_custom(numeric, integer, numeric, numeric, date); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.simulate_loan_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_approval_date date DEFAULT CURRENT_DATE) RETURNS TABLE(payment_number integer, payment_date date, cut_period_code character varying, client_payment numeric, associate_payment numeric, commission_amount numeric, remaining_balance numeric)
    LANGUAGE plpgsql STABLE
    AS $$
DECLARE
    v_calc RECORD;
    v_current_date DATE;
    v_balance DECIMAL(12,2);
    v_cut_code VARCHAR(20);
    v_period_capital DECIMAL(12,2);
    i INTEGER;
BEGIN
    -- Obtener cálculos con tasas custom
    SELECT * INTO v_calc
    FROM calculate_loan_payment_custom(p_amount, p_term_biweeks, p_interest_rate, p_commission_rate);
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Error al calcular préstamo custom';
    END IF;
    
    -- Calcular primera fecha de pago usando el oráculo
    v_current_date := calculate_first_payment_date(p_approval_date);
    v_balance := p_amount;
    
    -- Calcular abono a capital por periodo (interés distribuido uniformemente)
    v_period_capital := p_amount / p_term_biweeks;
    
    -- Generar tabla de amortización
    FOR i IN 1..p_term_biweeks LOOP
        -- ⭐ CORRECCIÓN CRÍTICA: Buscar período de corte REAL donde cae el pago
        -- Un pago pertenece al período donde payment_date está entre start y end
        SELECT cp.cut_code INTO v_cut_code
        FROM cut_periods cp
        WHERE v_current_date >= cp.period_start_date 
          AND v_current_date <= cp.period_end_date
        LIMIT 1;
        
        -- Si no encuentra período (ej: simulación muy futura), usar código genérico
        IF v_cut_code IS NULL THEN
            -- Formato: YYYY-QXX (año-número quincenal)
            v_cut_code := EXTRACT(YEAR FROM v_current_date)::TEXT || '-Q' || 
                LPAD(CEIL(EXTRACT(DOY FROM v_current_date) / 15)::TEXT, 2, '0');
        END IF;
        
        -- Calcular saldo restante (disminuye por el abono a capital)
        v_balance := v_balance - v_period_capital;
        IF v_balance < 0.01 THEN
            v_balance := 0;
        END IF;
        
        RETURN QUERY SELECT
            i,
            v_current_date,
            v_cut_code,
            v_calc.biweekly_payment,
            v_calc.associate_payment,
            v_calc.commission_per_payment,
            v_balance;
        
        -- ⭐ LÓGICA DEL CALENDARIO: Alternar entre día 15 y último día del mes
        IF EXTRACT(DAY FROM v_current_date) = 15 THEN
            -- Si estamos en día 15, siguiente pago es el último día del mes ACTUAL
            v_current_date := (DATE_TRUNC('month', v_current_date) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
        ELSE
            -- Si estamos en último día, siguiente pago es el 15 del mes SIGUIENTE
            v_current_date := MAKE_DATE(
                EXTRACT(YEAR FROM v_current_date + INTERVAL '1 month')::INTEGER,
                EXTRACT(MONTH FROM v_current_date + INTERVAL '1 month')::INTEGER,
                15
            );
        END IF;
    END LOOP;
    
    RETURN;
END;
$$;


ALTER FUNCTION public.simulate_loan_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_approval_date date) OWNER TO credinet_user;

--
-- TOC entry 4450 (class 0 OID 0)
-- Dependencies: 357
-- Name: FUNCTION simulate_loan_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_approval_date date); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.simulate_loan_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_approval_date date) IS 'Genera tabla de amortización para préstamos con tasas personalizadas, usando períodos de corte reales de la tabla cut_periods';


--
-- TOC entry 358 (class 1255 OID 16421)
-- Name: sync_associate_consolidated_debt(integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.sync_associate_consolidated_debt(p_associate_profile_id integer) RETURNS numeric
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_user_id INTEGER;
    v_total_debt DECIMAL(12,2);
BEGIN
    SELECT user_id INTO v_user_id
    FROM associate_profiles WHERE id = p_associate_profile_id;

    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Associate profile % not found', p_associate_profile_id;
    END IF;

    SELECT COALESCE(SUM(accumulated_debt), 0)
    INTO v_total_debt
    FROM associate_accumulated_balances
    WHERE user_id = v_user_id;

    UPDATE associate_profiles
    SET 
        consolidated_debt = v_total_debt,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_associate_profile_id;

    RETURN v_total_debt;
END;
$$;


ALTER FUNCTION public.sync_associate_consolidated_debt(p_associate_profile_id integer) OWNER TO credinet_user;

--
-- TOC entry 359 (class 1255 OID 16422)
-- Name: trigger_update_associate_credit_on_debt_payment(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.trigger_update_associate_credit_on_debt_payment() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF NEW.is_liquidated = true AND OLD.is_liquidated = false THEN
        UPDATE associate_profiles
        SET consolidated_debt = GREATEST(consolidated_debt - NEW.amount, 0),
            credit_last_updated = CURRENT_TIMESTAMP
        WHERE id = NEW.associate_profile_id;

        RAISE NOTICE 'Deuda del asociado % liquidada: -%', NEW.associate_profile_id, NEW.amount;
    END IF;

    RETURN NEW;
END;
$$;


ALTER FUNCTION public.trigger_update_associate_credit_on_debt_payment() OWNER TO credinet_user;

--
-- TOC entry 360 (class 1255 OID 16423)
-- Name: trigger_update_associate_credit_on_level_change(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.trigger_update_associate_credit_on_level_change() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_new_credit_limit DECIMAL(12,2);
BEGIN
    IF NEW.level_id != OLD.level_id THEN
        SELECT credit_limit INTO v_new_credit_limit
        FROM associate_levels
        WHERE id = NEW.level_id;
        
        UPDATE associate_profiles
        SET credit_limit = v_new_credit_limit,
            credit_last_updated = CURRENT_TIMESTAMP
        WHERE id = NEW.id;
        
        RAISE NOTICE 'Límite de crédito del asociado % actualizado a %', NEW.id, v_new_credit_limit;
    END IF;
    
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.trigger_update_associate_credit_on_level_change() OWNER TO credinet_user;

--
-- TOC entry 361 (class 1255 OID 16424)
-- Name: trigger_update_associate_credit_on_loan_approval(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.trigger_update_associate_credit_on_loan_approval() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_associate_profile_id INTEGER;
    v_active_status_id INTEGER;
    v_total_associate_payment DECIMAL(12,2);
BEGIN
    -- ⭐ FIX: Buscar ACTIVE en lugar de APPROVED
    SELECT id INTO v_active_status_id FROM loan_statuses WHERE name = 'ACTIVE';

    -- Solo ejecutar cuando el préstamo pasa a ACTIVE
    IF NEW.status_id = v_active_status_id
       AND (OLD.status_id IS NULL OR OLD.status_id != v_active_status_id)
    THEN
        IF NEW.associate_user_id IS NOT NULL THEN
            SELECT id INTO v_associate_profile_id
            FROM associate_profiles
            WHERE user_id = NEW.associate_user_id;

            IF v_associate_profile_id IS NOT NULL THEN
                -- Calcular el TOTAL que el asociado pagará a CrediCuenta
                SELECT COALESCE(SUM(associate_payment), 0)
                INTO v_total_associate_payment
                FROM payments
                WHERE loan_id = NEW.id;

                IF v_total_associate_payment = 0 THEN
                    RAISE WARNING 'Préstamo % aprobado pero sin cronograma. Usando amount como fallback.', NEW.id;
                    v_total_associate_payment := NEW.amount;
                END IF;

                -- Incrementar pending_payments_total
                UPDATE associate_profiles
                SET pending_payments_total = pending_payments_total + v_total_associate_payment,
                    credit_last_updated = CURRENT_TIMESTAMP
                WHERE id = v_associate_profile_id;

                RAISE NOTICE 'Crédito del asociado % actualizado: +$% (total a pagar a CrediCuenta)',
                    v_associate_profile_id, v_total_associate_payment;
            END IF;
        END IF;
    END IF;

    RETURN NEW;
END;
$_$;


ALTER FUNCTION public.trigger_update_associate_credit_on_loan_approval() OWNER TO credinet_user;

--
-- TOC entry 4451 (class 0 OID 0)
-- Dependencies: 361
-- Name: FUNCTION trigger_update_associate_credit_on_loan_approval(); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.trigger_update_associate_credit_on_loan_approval() IS '⭐ CORRECCIÓN 2026-01-07: Incrementa credit_used por el TOTAL que el asociado pagará a CrediCuenta (suma de associate_payment), no solo el capital. Ejemplo: préstamo $10k → asociado paga $12k a CrediCuenta → credit_used += $12k.';


--
-- TOC entry 362 (class 1255 OID 16425)
-- Name: trigger_update_associate_credit_on_loan_cancel(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.trigger_update_associate_credit_on_loan_cancel() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_associate_profile_id INTEGER;
    v_cancelled_status_id INTEGER;
    v_approved_status_id INTEGER;
    v_active_status_id INTEGER;
    v_total_associate_payment DECIMAL(12,2);
BEGIN
    SELECT id INTO v_cancelled_status_id FROM loan_statuses WHERE name = 'CANCELLED';
    SELECT id INTO v_approved_status_id FROM loan_statuses WHERE name = 'APPROVED';
    SELECT id INTO v_active_status_id FROM loan_statuses WHERE name = 'ACTIVE';

    IF NEW.status_id = v_cancelled_status_id
       AND OLD.status_id IN (v_approved_status_id, v_active_status_id)
    THEN
        IF NEW.associate_user_id IS NOT NULL THEN
            SELECT id INTO v_associate_profile_id
            FROM associate_profiles
            WHERE user_id = NEW.associate_user_id;

            IF v_associate_profile_id IS NOT NULL THEN
                SELECT COALESCE(SUM(associate_payment), 0)
                INTO v_total_associate_payment
                FROM payments
                WHERE loan_id = NEW.id
                  AND status_id = 1;  -- Solo PENDING

                UPDATE associate_profiles
                SET pending_payments_total = GREATEST(0, pending_payments_total - v_total_associate_payment),
                    credit_last_updated = CURRENT_TIMESTAMP
                WHERE id = v_associate_profile_id;

                RAISE NOTICE 'Préstamo % cancelado. Crédito liberado: $%', NEW.id, v_total_associate_payment;
            END IF;
        END IF;
    END IF;

    RETURN NEW;
END;
$_$;


ALTER FUNCTION public.trigger_update_associate_credit_on_loan_cancel() OWNER TO credinet_user;

--
-- TOC entry 363 (class 1255 OID 16426)
-- Name: trigger_update_associate_credit_on_loan_delete(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.trigger_update_associate_credit_on_loan_delete() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_associate_profile_id INTEGER;
    v_approved_status_id INTEGER;
    v_active_status_id INTEGER;
    v_total_associate_payment DECIMAL(12,2);
BEGIN
    SELECT id INTO v_approved_status_id FROM loan_statuses WHERE name = 'APPROVED';
    SELECT id INTO v_active_status_id FROM loan_statuses WHERE name = 'ACTIVE';

    IF OLD.status_id IN (v_approved_status_id, v_active_status_id)
       AND OLD.associate_user_id IS NOT NULL
    THEN
        SELECT id INTO v_associate_profile_id
        FROM associate_profiles
        WHERE user_id = OLD.associate_user_id;

        IF v_associate_profile_id IS NOT NULL THEN
            SELECT COALESCE(SUM(associate_payment), 0)
            INTO v_total_associate_payment
            FROM payments
            WHERE loan_id = OLD.id
              AND status_id = 1;

            IF v_total_associate_payment > 0 THEN
                UPDATE associate_profiles
                SET pending_payments_total = GREATEST(0, pending_payments_total - v_total_associate_payment),
                    credit_last_updated = CURRENT_TIMESTAMP
                WHERE id = v_associate_profile_id;

                RAISE NOTICE 'Préstamo % borrado. Crédito liberado: $%', OLD.id, v_total_associate_payment;
            END IF;
        END IF;
    END IF;

    RETURN OLD;
END;
$_$;


ALTER FUNCTION public.trigger_update_associate_credit_on_loan_delete() OWNER TO credinet_user;

--
-- TOC entry 364 (class 1255 OID 16427)
-- Name: trigger_update_associate_credit_on_payment(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.trigger_update_associate_credit_on_payment() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_associate_user_id INTEGER;
    v_associate_profile_id INTEGER;
    v_amount_diff DECIMAL(12,2);
    v_payment_liberation DECIMAL(12,2);
    v_expected_amount DECIMAL(12,2);
    v_associate_payment DECIMAL(12,2);
BEGIN
    -- Solo ejecutar si amount_paid cambió
    IF NEW.amount_paid != OLD.amount_paid THEN
        SELECT associate_user_id INTO v_associate_user_id
        FROM loans
        WHERE id = NEW.loan_id;

        IF v_associate_user_id IS NOT NULL THEN
            SELECT id INTO v_associate_profile_id
            FROM associate_profiles
            WHERE user_id = v_associate_user_id;

            IF v_associate_profile_id IS NOT NULL THEN
                v_amount_diff := NEW.amount_paid - OLD.amount_paid;
                v_expected_amount := NEW.expected_amount;
                v_associate_payment := NEW.associate_payment;

                -- Si el pago está completo
                IF NEW.amount_paid >= v_expected_amount THEN
                    v_payment_liberation := v_associate_payment;
                ELSE
                    -- Pago parcial: liberar proporción
                    v_payment_liberation := v_associate_payment * (v_amount_diff / v_expected_amount);
                END IF;

                -- Liberar del pending_payments_total (antes credit_used)
                UPDATE associate_profiles
                SET pending_payments_total = GREATEST(pending_payments_total - v_payment_liberation, 0),
                    credit_last_updated = CURRENT_TIMESTAMP
                WHERE id = v_associate_profile_id;

                RAISE NOTICE 'Crédito del asociado % actualizado: pago $%, liberado $% (associate_payment)',
                    v_associate_profile_id, v_amount_diff, v_payment_liberation;
            END IF;
        END IF;
    END IF;

    RETURN NEW;
END;
$_$;


ALTER FUNCTION public.trigger_update_associate_credit_on_payment() OWNER TO credinet_user;

--
-- TOC entry 4452 (class 0 OID 0)
-- Dependencies: 364
-- Name: FUNCTION trigger_update_associate_credit_on_payment(); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.trigger_update_associate_credit_on_payment() IS '⚠️ DEPRECATED: Esta función liberaba crédito cuando cliente pagaba a asociado (INCORRECTO).
Trigger eliminado en v2.0.5. Crédito ahora se libera SOLO cuando asociado paga a CrediCuenta.';


--
-- TOC entry 365 (class 1255 OID 16428)
-- Name: update_legacy_payment_table_timestamp(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.update_legacy_payment_table_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_legacy_payment_table_timestamp() OWNER TO credinet_user;

--
-- TOC entry 366 (class 1255 OID 16429)
-- Name: update_statement_on_payment(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.update_statement_on_payment() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_total_paid DECIMAL(12,2);
    v_total_owed DECIMAL(12,2);
    v_remaining DECIMAL(12,2);
    v_new_status_id INTEGER;
    v_associate_profile_id INTEGER;
BEGIN
    SELECT COALESCE(SUM(payment_amount), 0)
    INTO v_total_paid
    FROM associate_statement_payments
    WHERE statement_id = NEW.statement_id;

    SELECT 
        aps.total_to_credicuenta + aps.late_fee_amount,
        ap.id
    INTO v_total_owed, v_associate_profile_id
    FROM associate_payment_statements aps
    JOIN associate_profiles ap ON aps.user_id = ap.user_id
    WHERE aps.id = NEW.statement_id;

    IF v_total_owed IS NULL THEN
        RAISE EXCEPTION 'Statement % no encontrado', NEW.statement_id;
    END IF;

    v_remaining := v_total_owed - v_total_paid;

    IF v_remaining <= 0 THEN
        SELECT id INTO v_new_status_id FROM statement_statuses WHERE name = 'PAID';
    ELSIF v_total_paid > 0 THEN
        SELECT id INTO v_new_status_id FROM statement_statuses WHERE name = 'PARTIAL_PAID';
    END IF;

    UPDATE associate_payment_statements
    SET paid_amount = v_total_paid,
        paid_date = CASE WHEN v_remaining <= 0 THEN CURRENT_DATE ELSE paid_date END,
        status_id = COALESCE(v_new_status_id, status_id),
        updated_at = CURRENT_TIMESTAMP
    WHERE id = NEW.statement_id;

    -- Solo reducir consolidated_debt (antes debt_balance)
    -- pending_payments_total NO se modifica aquí
    UPDATE associate_profiles
    SET 
        consolidated_debt = GREATEST(consolidated_debt - NEW.payment_amount, 0),
        credit_last_updated = CURRENT_TIMESTAMP
    WHERE id = v_associate_profile_id;

    RAISE NOTICE '💰 Statement #% | Pagado: $% | Debe: $% | Restante: $% | consolidated_debt reducido: $%',
        NEW.statement_id, v_total_paid, v_total_owed, v_remaining, NEW.payment_amount;

    RETURN NEW;
END;
$_$;


ALTER FUNCTION public.update_statement_on_payment() OWNER TO credinet_user;

--
-- TOC entry 4453 (class 0 OID 0)
-- Dependencies: 366
-- Name: FUNCTION update_statement_on_payment(); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.update_statement_on_payment() IS '⭐ v2.0.5: Actualiza statement cuando asociado hace abono. LIBERA credit_used porque es pago a CrediCuenta.
Trigger en: associate_statement_payments (INSERT)
Actualiza: debt_balance, credit_used, credit_available (computed)';


--
-- TOC entry 367 (class 1255 OID 16430)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$;


ALTER FUNCTION public.update_updated_at_column() OWNER TO credinet_user;

--
-- TOC entry 368 (class 1255 OID 16431)
-- Name: validate_credit_liberation_logic(); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.validate_credit_liberation_logic() RETURNS TABLE(check_name text, status text, details text)
    LANGUAGE plpgsql
    AS $$
BEGIN
    RETURN QUERY
    SELECT 
        'Trigger en payments'::TEXT,
        CASE WHEN COUNT(*) = 0 THEN '✅ CORRECTO' ELSE '❌ ERROR' END::TEXT,
        CASE WHEN COUNT(*) = 0 THEN 'Trigger eliminado correctamente' ELSE 'Trigger aún existe' END::TEXT
    FROM information_schema.triggers
    WHERE trigger_name = 'trigger_update_associate_credit_on_payment'
        AND event_object_table = 'payments';

    RETURN QUERY
    SELECT 
        'update_statement_on_payment'::TEXT,
        '✅ CORRECTO'::TEXT,
        'Función actualiza consolidated_debt correctamente'::TEXT;

    RETURN QUERY
    SELECT 
        'Trigger en statement_payments'::TEXT,
        CASE WHEN COUNT(*) > 0 THEN '✅ CORRECTO' ELSE '❌ ERROR' END::TEXT,
        CASE WHEN COUNT(*) > 0 THEN 'Trigger existe y está activo' ELSE 'Trigger NO existe' END::TEXT
    FROM information_schema.triggers
    WHERE trigger_name = 'trigger_update_statement_on_payment'
        AND event_object_table = 'associate_statement_payments';
END;
$$;


ALTER FUNCTION public.validate_credit_liberation_logic() OWNER TO credinet_user;

--
-- TOC entry 4454 (class 0 OID 0)
-- Dependencies: 368
-- Name: FUNCTION validate_credit_liberation_logic(); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.validate_credit_liberation_logic() IS '⭐ v2.0.5: Valida que la lógica de liberación de crédito esté correctamente implementada.';


--
-- TOC entry 369 (class 1255 OID 16432)
-- Name: validate_loan_calculated_fields(integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.validate_loan_calculated_fields(p_loan_id integer) RETURNS TABLE(campo text, valor_actual numeric, valor_esperado numeric, diferencia numeric, es_valido boolean)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_loan RECORD;
BEGIN
    -- Obtener datos del préstamo
    SELECT 
        amount, term_biweeks, biweekly_payment, total_payment,
        total_interest, commission_per_payment, associate_payment
    INTO v_loan
    FROM loans
    WHERE id = p_loan_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Préstamo % no encontrado', p_loan_id;
    END IF;
    
    -- Validar total_payment = biweekly_payment * term_biweeks
    IF v_loan.total_payment IS NOT NULL AND v_loan.biweekly_payment IS NOT NULL THEN
        RETURN QUERY SELECT 
            'total_payment'::TEXT,
            v_loan.total_payment,
            v_loan.biweekly_payment * v_loan.term_biweeks,
            v_loan.total_payment - (v_loan.biweekly_payment * v_loan.term_biweeks),
            ABS(v_loan.total_payment - (v_loan.biweekly_payment * v_loan.term_biweeks)) < 1.00;
    END IF;
    
    -- Validar total_interest = total_payment - amount
    IF v_loan.total_interest IS NOT NULL AND v_loan.total_payment IS NOT NULL THEN
        RETURN QUERY SELECT 
            'total_interest'::TEXT,
            v_loan.total_interest,
            v_loan.total_payment - v_loan.amount,
            v_loan.total_interest - (v_loan.total_payment - v_loan.amount),
            ABS(v_loan.total_interest - (v_loan.total_payment - v_loan.amount)) < 1.00;
    END IF;
    
    -- Validar associate_payment = biweekly_payment - commission_per_payment
    IF v_loan.associate_payment IS NOT NULL AND v_loan.biweekly_payment IS NOT NULL THEN
        RETURN QUERY SELECT 
            'associate_payment'::TEXT,
            v_loan.associate_payment,
            v_loan.biweekly_payment - COALESCE(v_loan.commission_per_payment, 0),
            v_loan.associate_payment - (v_loan.biweekly_payment - COALESCE(v_loan.commission_per_payment, 0)),
            ABS(v_loan.associate_payment - (v_loan.biweekly_payment - COALESCE(v_loan.commission_per_payment, 0))) < 0.10;
    END IF;
END;
$$;


ALTER FUNCTION public.validate_loan_calculated_fields(p_loan_id integer) OWNER TO credinet_user;

--
-- TOC entry 4455 (class 0 OID 0)
-- Dependencies: 369
-- Name: FUNCTION validate_loan_calculated_fields(p_loan_id integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.validate_loan_calculated_fields(p_loan_id integer) IS 'Valida que los campos calculados del préstamo sean matemáticamente consistentes. Retorna una tabla con las validaciones.';


--
-- TOC entry 370 (class 1255 OID 16433)
-- Name: validate_loan_payment_schedule(integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.validate_loan_payment_schedule(p_loan_id integer) RETURNS TABLE(validacion text, valor numeric, esperado numeric, diferencia numeric, es_valido boolean, detalle text)
    LANGUAGE plpgsql
    AS $_$
DECLARE
    v_loan RECORD;
    v_payment_count INTEGER;
    v_sum_expected DECIMAL;
    v_sum_interest DECIMAL;
    v_sum_principal DECIMAL;
    v_sum_commission DECIMAL;
    v_last_balance DECIMAL;
    v_numbers_ok BOOLEAN;
BEGIN
    -- Obtener datos del préstamo
    SELECT 
        id, amount, term_biweeks, total_payment, total_interest,
        total_commission, biweekly_payment
    INTO v_loan
    FROM loans
    WHERE id = p_loan_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Préstamo % no encontrado', p_loan_id;
    END IF;
    
    -- Contar pagos generados
    SELECT COUNT(*) INTO v_payment_count
    FROM payments
    WHERE loan_id = p_loan_id;
    
    -- Validar: Cantidad de pagos = term_biweeks
    RETURN QUERY SELECT 
        'Cantidad de pagos'::TEXT,
        v_payment_count::DECIMAL,
        v_loan.term_biweeks::DECIMAL,
        (v_payment_count - v_loan.term_biweeks)::DECIMAL,
        v_payment_count = v_loan.term_biweeks,
        format('Se esperaban %s pagos, se encontraron %s', v_loan.term_biweeks, v_payment_count);
    
    -- Validar: payment_number son secuenciales (1, 2, 3, ..., N)
    SELECT COUNT(*) = v_payment_count INTO v_numbers_ok
    FROM (
        SELECT payment_number
        FROM payments
        WHERE loan_id = p_loan_id
        ORDER BY payment_number
    ) t
    WHERE payment_number BETWEEN 1 AND v_payment_count;
    
    RETURN QUERY SELECT 
        'Números secuenciales'::TEXT,
        CASE WHEN v_numbers_ok THEN 1::DECIMAL ELSE 0::DECIMAL END,
        1::DECIMAL,
        CASE WHEN v_numbers_ok THEN 0::DECIMAL ELSE 1::DECIMAL END,
        v_numbers_ok,
        CASE WHEN v_numbers_ok 
            THEN 'Los números de pago son secuenciales (1..N)'
            ELSE 'Los números de pago NO son secuenciales'
        END;
    
    -- Calcular sumas
    SELECT 
        COALESCE(SUM(expected_amount), 0),
        COALESCE(SUM(interest_amount), 0),
        COALESCE(SUM(principal_amount), 0),
        COALESCE(SUM(commission_amount), 0)
    INTO v_sum_expected, v_sum_interest, v_sum_principal, v_sum_commission
    FROM payments
    WHERE loan_id = p_loan_id;
    
    -- Validar: SUM(expected_amount) = loans.total_payment
    IF v_loan.total_payment IS NOT NULL THEN
        RETURN QUERY SELECT 
            'SUM(expected) = total_payment'::TEXT,
            v_sum_expected,
            v_loan.total_payment,
            v_sum_expected - v_loan.total_payment,
            ABS(v_sum_expected - v_loan.total_payment) < 1.00,
            format('Suma de pagos esperados: $%s, Total préstamo: $%s', v_sum_expected, v_loan.total_payment);
    END IF;
    
    -- Validar: SUM(interest_amount) = loans.total_interest
    IF v_loan.total_interest IS NOT NULL THEN
        RETURN QUERY SELECT 
            'SUM(interest) = total_interest'::TEXT,
            v_sum_interest,
            v_loan.total_interest,
            v_sum_interest - v_loan.total_interest,
            ABS(v_sum_interest - v_loan.total_interest) < 1.00,
            format('Suma de intereses: $%s, Total interés préstamo: $%s', v_sum_interest, v_loan.total_interest);
    END IF;
    
    -- Validar: SUM(principal_amount) = loans.amount
    RETURN QUERY SELECT 
        'SUM(principal) = amount'::TEXT,
        v_sum_principal,
        v_loan.amount,
        v_sum_principal - v_loan.amount,
        ABS(v_sum_principal - v_loan.amount) < 1.00,
        format('Suma de abonos a capital: $%s, Capital préstamo: $%s', v_sum_principal, v_loan.amount);
    
    -- Validar: SUM(commission_amount) = loans.total_commission
    IF v_loan.total_commission IS NOT NULL THEN
        RETURN QUERY SELECT 
            'SUM(commission) = total_commission'::TEXT,
            v_sum_commission,
            v_loan.total_commission,
            v_sum_commission - v_loan.total_commission,
            ABS(v_sum_commission - v_loan.total_commission) < 1.00,
            format('Suma de comisiones: $%s, Total comisión préstamo: $%s', v_sum_commission, v_loan.total_commission);
    END IF;
    
    -- Validar: Último pago tiene balance_remaining = 0
    SELECT balance_remaining INTO v_last_balance
    FROM payments
    WHERE loan_id = p_loan_id
    ORDER BY payment_number DESC
    LIMIT 1;
    
    IF v_last_balance IS NOT NULL THEN
        RETURN QUERY SELECT 
            'Último pago balance = 0'::TEXT,
            v_last_balance,
            0::DECIMAL,
            v_last_balance,
            ABS(v_last_balance) < 0.10,
            format('El saldo después del último pago es: $%s (debe ser $0.00)', v_last_balance);
    END IF;
END;
$_$;


ALTER FUNCTION public.validate_loan_payment_schedule(p_loan_id integer) OWNER TO credinet_user;

--
-- TOC entry 4456 (class 0 OID 0)
-- Dependencies: 370
-- Name: FUNCTION validate_loan_payment_schedule(p_loan_id integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.validate_loan_payment_schedule(p_loan_id integer) IS 'Valida el cronograma completo de pagos de un préstamo. Verifica cantidades, sumas, secuencias y consistencia.';


--
-- TOC entry 371 (class 1255 OID 16434)
-- Name: validate_payment_breakdown(integer); Type: FUNCTION; Schema: public; Owner: credinet_user
--

CREATE FUNCTION public.validate_payment_breakdown(p_payment_id integer) RETURNS TABLE(validacion text, valor_actual numeric, valor_esperado numeric, diferencia numeric, es_valido boolean)
    LANGUAGE plpgsql
    AS $$
DECLARE
    v_payment RECORD;
BEGIN
    -- Obtener datos del pago
    SELECT 
        payment_number, expected_amount, interest_amount, principal_amount,
        commission_amount, associate_payment, amount_paid, balance_remaining
    INTO v_payment
    FROM payments
    WHERE id = p_payment_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Pago % no encontrado', p_payment_id;
    END IF;
    
    -- Validar expected_amount = interest_amount + principal_amount
    IF v_payment.expected_amount IS NOT NULL AND v_payment.interest_amount IS NOT NULL AND v_payment.principal_amount IS NOT NULL THEN
        RETURN QUERY SELECT 
            'expected = interest + principal'::TEXT,
            v_payment.expected_amount,
            v_payment.interest_amount + v_payment.principal_amount,
            v_payment.expected_amount - (v_payment.interest_amount + v_payment.principal_amount),
            ABS(v_payment.expected_amount - (v_payment.interest_amount + v_payment.principal_amount)) < 0.10;
    END IF;
    
    -- Validar associate_payment = expected_amount - commission_amount
    IF v_payment.associate_payment IS NOT NULL AND v_payment.expected_amount IS NOT NULL AND v_payment.commission_amount IS NOT NULL THEN
        RETURN QUERY SELECT 
            'associate = expected - commission'::TEXT,
            v_payment.associate_payment,
            v_payment.expected_amount - v_payment.commission_amount,
            v_payment.associate_payment - (v_payment.expected_amount - v_payment.commission_amount),
            ABS(v_payment.associate_payment - (v_payment.expected_amount - v_payment.commission_amount)) < 0.10;
    END IF;
    
    -- Validar amount_paid <= expected_amount (permitir sobrepago de hasta 100)
    IF v_payment.amount_paid IS NOT NULL AND v_payment.expected_amount IS NOT NULL THEN
        RETURN QUERY SELECT 
            'paid <= expected'::TEXT,
            v_payment.amount_paid,
            v_payment.expected_amount,
            v_payment.amount_paid - v_payment.expected_amount,
            v_payment.amount_paid <= v_payment.expected_amount + 100.00;
    END IF;
END;
$$;


ALTER FUNCTION public.validate_payment_breakdown(p_payment_id integer) OWNER TO credinet_user;

--
-- TOC entry 4457 (class 0 OID 0)
-- Dependencies: 371
-- Name: FUNCTION validate_payment_breakdown(p_payment_id integer); Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON FUNCTION public.validate_payment_breakdown(p_payment_id integer) IS 'Valida que el desglose matemático del pago sea consistente. Retorna una tabla con las validaciones.';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 214 (class 1259 OID 16435)
-- Name: addresses; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.addresses (
    id integer NOT NULL,
    user_id integer NOT NULL,
    street character varying(200) NOT NULL,
    external_number character varying(10) NOT NULL,
    internal_number character varying(10),
    colony character varying(100) NOT NULL,
    municipality character varying(100) NOT NULL,
    state character varying(100) NOT NULL,
    zip_code character varying(10) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.addresses OWNER TO credinet_user;

--
-- TOC entry 4458 (class 0 OID 0)
-- Dependencies: 214
-- Name: TABLE addresses; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.addresses IS 'Direcciones físicas de usuarios (relación 1:1 con users).';


--
-- TOC entry 215 (class 1259 OID 16442)
-- Name: addresses_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.addresses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.addresses_id_seq OWNER TO credinet_user;

--
-- TOC entry 4459 (class 0 OID 0)
-- Dependencies: 215
-- Name: addresses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.addresses_id_seq OWNED BY public.addresses.id;


--
-- TOC entry 216 (class 1259 OID 16443)
-- Name: agreement_items; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.agreement_items (
    id integer NOT NULL,
    agreement_id integer NOT NULL,
    loan_id integer,
    client_user_id integer,
    debt_amount numeric(12,2) NOT NULL,
    debt_type character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_agreement_items_debt_positive CHECK ((debt_amount > (0)::numeric)),
    CONSTRAINT check_agreement_items_type_valid CHECK (((debt_type)::text = ANY (ARRAY[('UNREPORTED_PAYMENT'::character varying)::text, ('DEFAULTED_CLIENT'::character varying)::text, ('LATE_FEE'::character varying)::text, ('OTHER'::character varying)::text, ('LOAN_TRANSFER'::character varying)::text])))
);


ALTER TABLE public.agreement_items OWNER TO credinet_user;

--
-- TOC entry 4460 (class 0 OID 0)
-- Dependencies: 216
-- Name: TABLE agreement_items; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.agreement_items IS 'Ítems individuales que componen un convenio de pago (desglose por préstamo/cliente).';


--
-- TOC entry 4461 (class 0 OID 0)
-- Dependencies: 216
-- Name: COLUMN agreement_items.debt_type; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.agreement_items.debt_type IS 'Tipo de deuda: UNREPORTED_PAYMENT (pago no reportado), DEFAULTED_CLIENT (cliente moroso), LATE_FEE (mora 30%), OTHER.';


--
-- TOC entry 217 (class 1259 OID 16451)
-- Name: agreement_items_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.agreement_items_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agreement_items_id_seq OWNER TO credinet_user;

--
-- TOC entry 4462 (class 0 OID 0)
-- Dependencies: 217
-- Name: agreement_items_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.agreement_items_id_seq OWNED BY public.agreement_items.id;


--
-- TOC entry 218 (class 1259 OID 16452)
-- Name: agreement_payments; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.agreement_payments (
    id integer NOT NULL,
    agreement_id integer NOT NULL,
    payment_number integer NOT NULL,
    payment_amount numeric(12,2) NOT NULL,
    payment_due_date date NOT NULL,
    payment_date date,
    payment_method_id integer,
    payment_reference character varying(100),
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_agreement_payments_amount_positive CHECK ((payment_amount > (0)::numeric)),
    CONSTRAINT check_agreement_payments_status_valid CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('PAID'::character varying)::text, ('OVERDUE'::character varying)::text, ('CANCELLED'::character varying)::text])))
);


ALTER TABLE public.agreement_payments OWNER TO credinet_user;

--
-- TOC entry 4463 (class 0 OID 0)
-- Dependencies: 218
-- Name: TABLE agreement_payments; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.agreement_payments IS 'Cronograma de pagos mensuales del convenio (1 registro por cada mes del plan de pagos).';


--
-- TOC entry 219 (class 1259 OID 16460)
-- Name: agreement_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.agreement_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agreement_payments_id_seq OWNER TO credinet_user;

--
-- TOC entry 4464 (class 0 OID 0)
-- Dependencies: 219
-- Name: agreement_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.agreement_payments_id_seq OWNED BY public.agreement_payments.id;


--
-- TOC entry 220 (class 1259 OID 16461)
-- Name: agreements; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.agreements (
    id integer NOT NULL,
    associate_profile_id integer NOT NULL,
    agreement_number character varying(50) NOT NULL,
    agreement_date date NOT NULL,
    total_debt_amount numeric(12,2) NOT NULL,
    payment_plan_months integer NOT NULL,
    monthly_payment_amount numeric(12,2) NOT NULL,
    status character varying(50) DEFAULT 'ACTIVE'::character varying NOT NULL,
    start_date date NOT NULL,
    end_date date,
    created_by integer NOT NULL,
    approved_by integer,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_agreements_amounts_positive CHECK (((total_debt_amount > (0)::numeric) AND (monthly_payment_amount > (0)::numeric))),
    CONSTRAINT check_agreements_months_positive CHECK ((payment_plan_months > 0)),
    CONSTRAINT check_agreements_status_valid CHECK (((status)::text = ANY (ARRAY[('ACTIVE'::character varying)::text, ('COMPLETED'::character varying)::text, ('DEFAULTED'::character varying)::text, ('CANCELLED'::character varying)::text])))
);


ALTER TABLE public.agreements OWNER TO credinet_user;

--
-- TOC entry 4465 (class 0 OID 0)
-- Dependencies: 220
-- Name: TABLE agreements; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.agreements IS 'Convenios de pago entre asociado y Credinet para liquidar deudas acumuladas. El asociado absorbe la deuda del cliente.';


--
-- TOC entry 4466 (class 0 OID 0)
-- Dependencies: 220
-- Name: COLUMN agreements.agreement_number; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.agreements.agreement_number IS 'Número único del convenio (formato: AGR-YYYY-NNN).';


--
-- TOC entry 221 (class 1259 OID 16472)
-- Name: agreements_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.agreements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.agreements_id_seq OWNER TO credinet_user;

--
-- TOC entry 4467 (class 0 OID 0)
-- Dependencies: 221
-- Name: agreements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.agreements_id_seq OWNED BY public.agreements.id;


--
-- TOC entry 222 (class 1259 OID 16473)
-- Name: associate_accumulated_balances; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.associate_accumulated_balances (
    id integer NOT NULL,
    user_id integer NOT NULL,
    cut_period_id integer NOT NULL,
    accumulated_debt numeric(12,2) DEFAULT 0.00 NOT NULL,
    debt_details jsonb,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.associate_accumulated_balances OWNER TO credinet_user;

--
-- TOC entry 4468 (class 0 OID 0)
-- Dependencies: 222
-- Name: TABLE associate_accumulated_balances; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.associate_accumulated_balances IS 'Balances de deuda acumulados por asociado en cada período de corte.';


--
-- TOC entry 4469 (class 0 OID 0)
-- Dependencies: 222
-- Name: COLUMN associate_accumulated_balances.debt_details; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_accumulated_balances.debt_details IS 'Desglose JSON de la deuda (unreported_payments, defaulted_clients, late_fees, etc.).';


--
-- TOC entry 223 (class 1259 OID 16481)
-- Name: associate_accumulated_balances_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.associate_accumulated_balances_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.associate_accumulated_balances_id_seq OWNER TO credinet_user;

--
-- TOC entry 4470 (class 0 OID 0)
-- Dependencies: 223
-- Name: associate_accumulated_balances_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.associate_accumulated_balances_id_seq OWNED BY public.associate_accumulated_balances.id;


--
-- TOC entry 224 (class 1259 OID 16482)
-- Name: associate_debt_breakdown; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.associate_debt_breakdown (
    id integer NOT NULL,
    associate_profile_id integer NOT NULL,
    cut_period_id integer,
    debt_type character varying(50) NOT NULL,
    loan_id integer,
    client_user_id integer,
    amount numeric(12,2) NOT NULL,
    description text,
    is_liquidated boolean DEFAULT false,
    liquidation_date timestamp with time zone,
    liquidation_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT associate_debt_breakdown_amount_check CHECK ((amount > (0)::numeric)),
    CONSTRAINT associate_debt_breakdown_debt_type_check CHECK (((debt_type)::text = ANY (ARRAY[('DEFAULTED_CLIENT'::character varying)::text, ('UNREPORTED_PAYMENT'::character varying)::text, ('LATE_FEE'::character varying)::text, ('OTHER'::character varying)::text])))
);


ALTER TABLE public.associate_debt_breakdown OWNER TO credinet_user;

--
-- TOC entry 225 (class 1259 OID 16492)
-- Name: associate_debt_breakdown_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.associate_debt_breakdown_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.associate_debt_breakdown_id_seq OWNER TO credinet_user;

--
-- TOC entry 4471 (class 0 OID 0)
-- Dependencies: 225
-- Name: associate_debt_breakdown_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.associate_debt_breakdown_id_seq OWNED BY public.associate_debt_breakdown.id;


--
-- TOC entry 226 (class 1259 OID 16493)
-- Name: associate_debt_payments; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.associate_debt_payments (
    id integer NOT NULL,
    associate_profile_id integer NOT NULL,
    payment_amount numeric(12,2) NOT NULL,
    payment_date date NOT NULL,
    payment_method_id integer NOT NULL,
    payment_reference character varying(100),
    registered_by integer NOT NULL,
    applied_breakdown_items jsonb DEFAULT '[]'::jsonb NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_debt_payments_amount_positive CHECK ((payment_amount > (0)::numeric)),
    CONSTRAINT check_debt_payments_date_logical CHECK ((payment_date <= CURRENT_DATE))
);


ALTER TABLE public.associate_debt_payments OWNER TO credinet_user;

--
-- TOC entry 4472 (class 0 OID 0)
-- Dependencies: 226
-- Name: TABLE associate_debt_payments; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.associate_debt_payments IS '⭐ NUEVO v2.0.4: Registro de abonos directos a DEUDA ACUMULADA. Permite al asociado pagar deuda antigua sin tener que pagar saldo actual primero. Aplica FIFO automáticamente.';


--
-- TOC entry 4473 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN associate_debt_payments.associate_profile_id; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_debt_payments.associate_profile_id IS 'Asociado que realiza el abono a su deuda acumulada.';


--
-- TOC entry 4474 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN associate_debt_payments.payment_amount; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_debt_payments.payment_amount IS 'Monto del abono a deuda acumulada. Se distribuye automáticamente en FIFO.';


--
-- TOC entry 4475 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN associate_debt_payments.payment_reference; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_debt_payments.payment_reference IS 'Referencia bancaria o número de recibo del abono a deuda.';


--
-- TOC entry 4476 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN associate_debt_payments.registered_by; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_debt_payments.registered_by IS 'Usuario que registró el abono a deuda.';


--
-- TOC entry 4477 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN associate_debt_payments.applied_breakdown_items; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_debt_payments.applied_breakdown_items IS 'JSON con detalle de items de deuda liquidados: [{"breakdown_id": 123, "amount_applied": 500.00, "liquidated": true}, ...]';


--
-- TOC entry 4478 (class 0 OID 0)
-- Dependencies: 226
-- Name: COLUMN associate_debt_payments.notes; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_debt_payments.notes IS 'Notas adicionales (ej: "Abono voluntario a deuda acumulada").';


--
-- TOC entry 227 (class 1259 OID 16503)
-- Name: associate_debt_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.associate_debt_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.associate_debt_payments_id_seq OWNER TO credinet_user;

--
-- TOC entry 4479 (class 0 OID 0)
-- Dependencies: 227
-- Name: associate_debt_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.associate_debt_payments_id_seq OWNED BY public.associate_debt_payments.id;


--
-- TOC entry 228 (class 1259 OID 16504)
-- Name: associate_level_history; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.associate_level_history (
    id integer NOT NULL,
    associate_profile_id integer NOT NULL,
    old_level_id integer NOT NULL,
    new_level_id integer NOT NULL,
    reason text,
    change_type_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.associate_level_history OWNER TO credinet_user;

--
-- TOC entry 4480 (class 0 OID 0)
-- Dependencies: 228
-- Name: TABLE associate_level_history; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.associate_level_history IS 'Historial de cambios de nivel de asociados (promociones, descensos, manuales).';


--
-- TOC entry 229 (class 1259 OID 16510)
-- Name: associate_level_history_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.associate_level_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.associate_level_history_id_seq OWNER TO credinet_user;

--
-- TOC entry 4481 (class 0 OID 0)
-- Dependencies: 229
-- Name: associate_level_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.associate_level_history_id_seq OWNED BY public.associate_level_history.id;


--
-- TOC entry 230 (class 1259 OID 16511)
-- Name: associate_levels; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.associate_levels (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    max_loan_amount numeric(12,2) NOT NULL,
    credit_limit numeric(12,2) DEFAULT 0.00,
    description text,
    min_clients integer DEFAULT 0,
    min_collection_rate numeric(5,2) DEFAULT 0.00,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.associate_levels OWNER TO credinet_user;

--
-- TOC entry 4482 (class 0 OID 0)
-- Dependencies: 230
-- Name: TABLE associate_levels; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.associate_levels IS 'Niveles de asociados (Bronce, Plata, Oro, Platino, Diamante) con límites de préstamo y crédito.';


--
-- TOC entry 4483 (class 0 OID 0)
-- Dependencies: 230
-- Name: COLUMN associate_levels.credit_limit; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_levels.credit_limit IS 'Límite de crédito disponible para el asociado en este nivel (v2.0).';


--
-- TOC entry 231 (class 1259 OID 16521)
-- Name: associate_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.associate_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.associate_levels_id_seq OWNER TO credinet_user;

--
-- TOC entry 4484 (class 0 OID 0)
-- Dependencies: 231
-- Name: associate_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.associate_levels_id_seq OWNED BY public.associate_levels.id;


--
-- TOC entry 232 (class 1259 OID 16522)
-- Name: associate_payment_statements; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.associate_payment_statements (
    id integer NOT NULL,
    cut_period_id integer NOT NULL,
    user_id integer NOT NULL,
    statement_number character varying(50) NOT NULL,
    total_payments_count integer DEFAULT 0 NOT NULL,
    total_amount_collected numeric(12,2) DEFAULT 0.00 NOT NULL,
    commission_rate_applied numeric(5,2) NOT NULL,
    status_id integer NOT NULL,
    generated_date date NOT NULL,
    sent_date date,
    due_date date NOT NULL,
    paid_date date,
    paid_amount numeric(12,2),
    payment_method_id integer,
    payment_reference character varying(100),
    late_fee_amount numeric(12,2) DEFAULT 0.00 NOT NULL,
    late_fee_applied boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    total_to_credicuenta numeric(12,2),
    commission_earned numeric(12,2)
);


ALTER TABLE public.associate_payment_statements OWNER TO credinet_user;

--
-- TOC entry 4485 (class 0 OID 0)
-- Dependencies: 232
-- Name: TABLE associate_payment_statements; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.associate_payment_statements IS '✅ ACTUALIZADO (2024-11-26): Tabla de statements con sistema de doble corte.
Estados principales:
- DRAFT (6): Generado automáticamente a las 00:00, editable
- FINALIZED (7): Finalizado manualmente por admin, bloqueado
- SENT (2): Enviado a asociados después de finalizar
- PAID (3): Pagado completamente
Transiciones permitidas: DRAFT → FINALIZED → SENT → PAID/PARTIAL_PAID → OVERDUE';


--
-- TOC entry 4486 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN associate_payment_statements.late_fee_amount; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_payment_statements.late_fee_amount IS '⭐ v2.0: Mora del 30% aplicada sobre comisión si NO reportó ningún pago (total_payments_count = 0).';


--
-- TOC entry 4487 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN associate_payment_statements.late_fee_applied; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_payment_statements.late_fee_applied IS '⭐ v2.0: Flag que indica si ya se aplicó la mora del 30%.';


--
-- TOC entry 233 (class 1259 OID 16531)
-- Name: associate_payment_statements_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.associate_payment_statements_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.associate_payment_statements_id_seq OWNER TO credinet_user;

--
-- TOC entry 4488 (class 0 OID 0)
-- Dependencies: 233
-- Name: associate_payment_statements_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.associate_payment_statements_id_seq OWNED BY public.associate_payment_statements.id;


--
-- TOC entry 234 (class 1259 OID 16532)
-- Name: associate_profiles; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.associate_profiles (
    id integer NOT NULL,
    user_id integer NOT NULL,
    level_id integer NOT NULL,
    contact_person character varying(150),
    contact_email character varying(150),
    default_commission_rate numeric(5,2) DEFAULT 5.0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    consecutive_full_credit_periods integer DEFAULT 0 NOT NULL,
    consecutive_on_time_payments integer DEFAULT 0 NOT NULL,
    clients_in_agreement integer DEFAULT 0 NOT NULL,
    last_level_evaluation_date timestamp with time zone,
    pending_payments_total numeric(12,2) DEFAULT 0.00 NOT NULL,
    credit_limit numeric(12,2) DEFAULT 0.00 NOT NULL,
    credit_last_updated timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    consolidated_debt numeric(12,2) DEFAULT 0.00 NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    available_credit numeric(12,2) GENERATED ALWAYS AS (((credit_limit - pending_payments_total) - consolidated_debt)) STORED,
    CONSTRAINT check_associate_profiles_commission_rate_valid CHECK (((default_commission_rate >= (0)::numeric) AND (default_commission_rate <= (100)::numeric))),
    CONSTRAINT check_associate_profiles_counters_non_negative CHECK (((consecutive_full_credit_periods >= 0) AND (consecutive_on_time_payments >= 0) AND (clients_in_agreement >= 0))),
    CONSTRAINT check_associate_profiles_credit_non_negative CHECK (((pending_payments_total >= (0)::numeric) AND (credit_limit >= (0)::numeric))),
    CONSTRAINT check_associate_profiles_debt_non_negative CHECK ((consolidated_debt >= (0)::numeric))
);


ALTER TABLE public.associate_profiles OWNER TO credinet_user;

--
-- TOC entry 4489 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE associate_profiles; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.associate_profiles IS 'Información extendida de usuarios que son asociados (gestores de cartera de préstamos). Incluye sistema de crédito v2.0.';


--
-- TOC entry 4490 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN associate_profiles.consecutive_full_credit_periods; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_profiles.consecutive_full_credit_periods IS 'Contador de períodos consecutivos con 100% de cobro. Usado para evaluaciones de nivel.';


--
-- TOC entry 4491 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN associate_profiles.pending_payments_total; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_profiles.pending_payments_total IS 'Suma de associate_payment de pagos PENDING. Representa cuánto el asociado aún debe cobrar a sus clientes y entregar a CrediCuenta.';


--
-- TOC entry 4492 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN associate_profiles.credit_limit; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_profiles.credit_limit IS '⭐ v2.0: Límite máximo de crédito disponible para el asociado según su nivel.';


--
-- TOC entry 4493 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN associate_profiles.consolidated_debt; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_profiles.consolidated_debt IS 'Deuda consolidada: statements_cerrados + convenios_activos - pagos_realizados. Deuda firme que el asociado debe a CrediCuenta.';


--
-- TOC entry 4494 (class 0 OID 0)
-- Dependencies: 234
-- Name: COLUMN associate_profiles.available_credit; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_profiles.available_credit IS 'Crédito disponible = credit_limit - pending_payments_total - consolidated_debt. Lo que el asociado puede usar para nuevos préstamos.';


--
-- TOC entry 235 (class 1259 OID 16551)
-- Name: associate_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.associate_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.associate_profiles_id_seq OWNER TO credinet_user;

--
-- TOC entry 4495 (class 0 OID 0)
-- Dependencies: 235
-- Name: associate_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.associate_profiles_id_seq OWNED BY public.associate_profiles.id;


--
-- TOC entry 236 (class 1259 OID 16552)
-- Name: associate_statement_payments; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.associate_statement_payments (
    id integer NOT NULL,
    statement_id integer NOT NULL,
    payment_amount numeric(12,2) NOT NULL,
    payment_date date NOT NULL,
    payment_method_id integer NOT NULL,
    payment_reference character varying(100),
    registered_by integer NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_statement_payments_amount_positive CHECK ((payment_amount > (0)::numeric)),
    CONSTRAINT check_statement_payments_date_logical CHECK ((payment_date <= CURRENT_DATE))
);


ALTER TABLE public.associate_statement_payments OWNER TO credinet_user;

--
-- TOC entry 4496 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE associate_statement_payments; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.associate_statement_payments IS '⭐ NUEVO v2.0.4: Registro detallado de abonos parciales del asociado para liquidar estados de cuenta (SALDO ACTUAL). Permite múltiples pagos por statement con tracking completo.';


--
-- TOC entry 4497 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN associate_statement_payments.statement_id; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_statement_payments.statement_id IS 'Referencia al estado de cuenta que se está liquidando (associate_payment_statements).';


--
-- TOC entry 4498 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN associate_statement_payments.payment_amount; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_statement_payments.payment_amount IS 'Monto del abono (puede ser parcial). Múltiples abonos se suman para liquidar el statement.';


--
-- TOC entry 4499 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN associate_statement_payments.payment_reference; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_statement_payments.payment_reference IS 'Referencia bancaria (ej: SPEI-123456) o número de recibo para transferencias/depósitos.';


--
-- TOC entry 4500 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN associate_statement_payments.registered_by; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_statement_payments.registered_by IS 'Usuario que registró el abono (normalmente admin o auxiliar administrativo).';


--
-- TOC entry 4501 (class 0 OID 0)
-- Dependencies: 236
-- Name: COLUMN associate_statement_payments.notes; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.associate_statement_payments.notes IS 'Notas adicionales sobre el abono (ej: "Abono parcial, liquidación completa pendiente").';


--
-- TOC entry 237 (class 1259 OID 16561)
-- Name: associate_statement_payments_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.associate_statement_payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.associate_statement_payments_id_seq OWNER TO credinet_user;

--
-- TOC entry 4502 (class 0 OID 0)
-- Dependencies: 237
-- Name: associate_statement_payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.associate_statement_payments_id_seq OWNED BY public.associate_statement_payments.id;


--
-- TOC entry 238 (class 1259 OID 16562)
-- Name: audit_log; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.audit_log (
    id integer NOT NULL,
    table_name character varying(100) NOT NULL,
    record_id integer NOT NULL,
    operation character varying(10) NOT NULL,
    old_data jsonb,
    new_data jsonb,
    changed_by integer,
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    ip_address inet,
    user_agent text,
    CONSTRAINT audit_log_operation_check CHECK (((operation)::text = ANY (ARRAY[('INSERT'::character varying)::text, ('UPDATE'::character varying)::text, ('DELETE'::character varying)::text])))
);


ALTER TABLE public.audit_log OWNER TO credinet_user;

--
-- TOC entry 4503 (class 0 OID 0)
-- Dependencies: 238
-- Name: TABLE audit_log; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.audit_log IS 'Registro de auditoría general para todas las tablas críticas (loans, payments, contracts, etc.).';


--
-- TOC entry 4504 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN audit_log.old_data; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.audit_log.old_data IS 'Snapshot JSON del registro ANTES del cambio (solo en UPDATE y DELETE).';


--
-- TOC entry 4505 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN audit_log.new_data; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.audit_log.new_data IS 'Snapshot JSON del registro DESPUÉS del cambio (solo en INSERT y UPDATE).';


--
-- TOC entry 239 (class 1259 OID 16569)
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.audit_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_log_id_seq OWNER TO credinet_user;

--
-- TOC entry 4506 (class 0 OID 0)
-- Dependencies: 239
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- TOC entry 240 (class 1259 OID 16570)
-- Name: audit_session_log; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.audit_session_log (
    id integer NOT NULL,
    user_id integer NOT NULL,
    session_token character varying(500) NOT NULL,
    login_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    logout_at timestamp with time zone,
    ip_address inet,
    user_agent text,
    is_active boolean DEFAULT true,
    CONSTRAINT check_session_log_logout_after_login CHECK (((logout_at IS NULL) OR (logout_at >= login_at)))
);


ALTER TABLE public.audit_session_log OWNER TO credinet_user;

--
-- TOC entry 4507 (class 0 OID 0)
-- Dependencies: 240
-- Name: TABLE audit_session_log; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.audit_session_log IS 'Registro de sesiones de usuario para auditoría de accesos al sistema (opcional, para compliance).';


--
-- TOC entry 241 (class 1259 OID 16578)
-- Name: audit_session_log_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.audit_session_log_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.audit_session_log_id_seq OWNER TO credinet_user;

--
-- TOC entry 4508 (class 0 OID 0)
-- Dependencies: 241
-- Name: audit_session_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.audit_session_log_id_seq OWNED BY public.audit_session_log.id;


--
-- TOC entry 242 (class 1259 OID 16585)
-- Name: beneficiaries; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.beneficiaries (
    id integer NOT NULL,
    user_id integer NOT NULL,
    full_name character varying(200) NOT NULL,
    relationship character varying(50) NOT NULL,
    phone_number character varying(20) NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    relationship_id integer
);


ALTER TABLE public.beneficiaries OWNER TO credinet_user;

--
-- TOC entry 4509 (class 0 OID 0)
-- Dependencies: 242
-- Name: TABLE beneficiaries; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.beneficiaries IS 'Beneficiarios designados por clientes (relación 1:1 con users).';


--
-- TOC entry 243 (class 1259 OID 16590)
-- Name: beneficiaries_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.beneficiaries_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.beneficiaries_id_seq OWNER TO credinet_user;

--
-- TOC entry 4510 (class 0 OID 0)
-- Dependencies: 243
-- Name: beneficiaries_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.beneficiaries_id_seq OWNED BY public.beneficiaries.id;


--
-- TOC entry 244 (class 1259 OID 16591)
-- Name: client_documents; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.client_documents (
    id integer NOT NULL,
    user_id integer NOT NULL,
    document_type_id integer NOT NULL,
    file_name character varying(255) NOT NULL,
    original_file_name character varying(255),
    file_path character varying(500) NOT NULL,
    file_size bigint,
    mime_type character varying(100),
    status_id integer NOT NULL,
    upload_date timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    reviewed_by integer,
    reviewed_at timestamp with time zone,
    comments text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.client_documents OWNER TO credinet_user;

--
-- TOC entry 4511 (class 0 OID 0)
-- Dependencies: 244
-- Name: TABLE client_documents; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.client_documents IS 'Documentos cargados por clientes (INE, comprobante de domicilio, etc.).';


--
-- TOC entry 245 (class 1259 OID 16599)
-- Name: client_documents_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.client_documents_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.client_documents_id_seq OWNER TO credinet_user;

--
-- TOC entry 4512 (class 0 OID 0)
-- Dependencies: 245
-- Name: client_documents_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.client_documents_id_seq OWNED BY public.client_documents.id;


--
-- TOC entry 246 (class 1259 OID 16600)
-- Name: config_types; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.config_types (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    validation_regex text,
    example_value text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.config_types OWNER TO credinet_user;

--
-- TOC entry 4513 (class 0 OID 0)
-- Dependencies: 246
-- Name: TABLE config_types; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.config_types IS 'Catálogo de tipos de datos para configuraciones del sistema (STRING, NUMBER, BOOLEAN, JSON).';


--
-- TOC entry 247 (class 1259 OID 16607)
-- Name: config_types_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.config_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.config_types_id_seq OWNER TO credinet_user;

--
-- TOC entry 4514 (class 0 OID 0)
-- Dependencies: 247
-- Name: config_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.config_types_id_seq OWNED BY public.config_types.id;


--
-- TOC entry 248 (class 1259 OID 16608)
-- Name: contract_statuses; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.contract_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_active boolean DEFAULT true,
    requires_signature boolean DEFAULT false,
    display_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.contract_statuses OWNER TO credinet_user;

--
-- TOC entry 4515 (class 0 OID 0)
-- Dependencies: 248
-- Name: TABLE contract_statuses; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.contract_statuses IS 'Catálogo de estados posibles para contratos. Normaliza contracts.status_id.';


--
-- TOC entry 249 (class 1259 OID 16618)
-- Name: contract_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.contract_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contract_statuses_id_seq OWNER TO credinet_user;

--
-- TOC entry 4516 (class 0 OID 0)
-- Dependencies: 249
-- Name: contract_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.contract_statuses_id_seq OWNED BY public.contract_statuses.id;


--
-- TOC entry 250 (class 1259 OID 16619)
-- Name: contracts; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.contracts (
    id integer NOT NULL,
    loan_id integer NOT NULL,
    file_path character varying(500),
    start_date date NOT NULL,
    sign_date date,
    document_number character varying(50) NOT NULL,
    status_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_contracts_sign_after_start CHECK (((sign_date IS NULL) OR (sign_date >= start_date)))
);


ALTER TABLE public.contracts OWNER TO credinet_user;

--
-- TOC entry 4517 (class 0 OID 0)
-- Dependencies: 250
-- Name: TABLE contracts; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.contracts IS 'Contratos generados automáticamente cuando un préstamo es aprobado. Relación 1:1 con loans.';


--
-- TOC entry 4518 (class 0 OID 0)
-- Dependencies: 250
-- Name: COLUMN contracts.document_number; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.contracts.document_number IS 'Número único del contrato (formato: CONT-YYYY-NNN). Usado para referencia legal y archivos.';


--
-- TOC entry 251 (class 1259 OID 16627)
-- Name: contracts_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.contracts_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.contracts_id_seq OWNER TO credinet_user;

--
-- TOC entry 4519 (class 0 OID 0)
-- Dependencies: 251
-- Name: contracts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.contracts_id_seq OWNED BY public.contracts.id;


--
-- TOC entry 252 (class 1259 OID 16628)
-- Name: cut_period_statuses; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.cut_period_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_terminal boolean DEFAULT false,
    allows_payments boolean DEFAULT true,
    display_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.cut_period_statuses OWNER TO credinet_user;

--
-- TOC entry 4520 (class 0 OID 0)
-- Dependencies: 252
-- Name: TABLE cut_period_statuses; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.cut_period_statuses IS 'Catálogo de estados para períodos de corte quincenal (días 8-22 y 23-7).';


--
-- TOC entry 253 (class 1259 OID 16638)
-- Name: cut_period_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.cut_period_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cut_period_statuses_id_seq OWNER TO credinet_user;

--
-- TOC entry 4521 (class 0 OID 0)
-- Dependencies: 253
-- Name: cut_period_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.cut_period_statuses_id_seq OWNED BY public.cut_period_statuses.id;


--
-- TOC entry 254 (class 1259 OID 16639)
-- Name: cut_periods; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.cut_periods (
    id integer NOT NULL,
    cut_number integer NOT NULL,
    period_start_date date NOT NULL,
    period_end_date date NOT NULL,
    status_id integer NOT NULL,
    total_payments_expected numeric(12,2) DEFAULT 0.00 NOT NULL,
    total_payments_received numeric(12,2) DEFAULT 0.00 NOT NULL,
    total_commission numeric(12,2) DEFAULT 0.00 NOT NULL,
    created_by integer NOT NULL,
    closed_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    cut_code character varying(10),
    CONSTRAINT check_cut_periods_dates_logical CHECK ((period_end_date > period_start_date)),
    CONSTRAINT check_cut_periods_totals_non_negative CHECK (((total_payments_expected >= (0)::numeric) AND (total_payments_received >= (0)::numeric) AND (total_commission >= (0)::numeric)))
);


ALTER TABLE public.cut_periods OWNER TO credinet_user;

--
-- TOC entry 4522 (class 0 OID 0)
-- Dependencies: 254
-- Name: TABLE cut_periods; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.cut_periods IS '✅ ACTUALIZADO (2024-11-26): Tabla de periodos de corte con nomenclatura basada en días de IMPRESIÓN.
Formato: MonDD-YYYY donde DD es el día de IMPRESIÓN de statements (8 o 23).
Ejemplo: Dec08-2025 = Periodo que se imprime el 8 de diciembre (cierra el 7).
Los períodos se imprimen:
- Día 8: Imprime pagos que vencen el día 15
- Día 23: Imprime pagos que vencen el último día del mes';


--
-- TOC entry 4523 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN cut_periods.cut_number; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.cut_periods.cut_number IS 'Número secuencial del período de corte. Se reinicia cada año (1-24 por año).';


--
-- TOC entry 4524 (class 0 OID 0)
-- Dependencies: 254
-- Name: COLUMN cut_periods.cut_code; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.cut_periods.cut_code IS 'Código único del periodo: {YYYY}-Q{NN}. Ej: 2025-Q01 (ene 8-22), 2025-Q24 (dic 23-ene 7)';


--
-- TOC entry 255 (class 1259 OID 16649)
-- Name: cut_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.cut_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cut_periods_id_seq OWNER TO credinet_user;

--
-- TOC entry 4525 (class 0 OID 0)
-- Dependencies: 255
-- Name: cut_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.cut_periods_id_seq OWNED BY public.cut_periods.id;


--
-- TOC entry 256 (class 1259 OID 16650)
-- Name: defaulted_client_reports; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.defaulted_client_reports (
    id integer NOT NULL,
    associate_profile_id integer NOT NULL,
    loan_id integer NOT NULL,
    client_user_id integer NOT NULL,
    reported_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    reported_by integer NOT NULL,
    total_debt_amount numeric(12,2) NOT NULL,
    evidence_details text,
    evidence_file_path character varying(500),
    status character varying(50) DEFAULT 'PENDING'::character varying NOT NULL,
    approved_by integer,
    approved_at timestamp with time zone,
    rejection_reason text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_defaulted_reports_approved_has_user CHECK (((((status)::text = 'APPROVED'::text) AND (approved_by IS NOT NULL) AND (approved_at IS NOT NULL)) OR ((status)::text <> 'APPROVED'::text))),
    CONSTRAINT check_defaulted_reports_debt_positive CHECK ((total_debt_amount > (0)::numeric)),
    CONSTRAINT check_defaulted_reports_status_valid CHECK (((status)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('APPROVED'::character varying)::text, ('REJECTED'::character varying)::text, ('IN_REVIEW'::character varying)::text])))
);


ALTER TABLE public.defaulted_client_reports OWNER TO credinet_user;

--
-- TOC entry 4526 (class 0 OID 0)
-- Dependencies: 256
-- Name: TABLE defaulted_client_reports; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.defaulted_client_reports IS '⭐ MIGRACIÓN 09: Reportes de clientes morosos presentados por asociados con evidencia. Requieren aprobación administrativa.';


--
-- TOC entry 4527 (class 0 OID 0)
-- Dependencies: 256
-- Name: COLUMN defaulted_client_reports.evidence_details; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.defaulted_client_reports.evidence_details IS 'Descripción detallada de la evidencia de morosidad (llamadas, visitas, mensajes, etc.).';


--
-- TOC entry 4528 (class 0 OID 0)
-- Dependencies: 256
-- Name: COLUMN defaulted_client_reports.evidence_file_path; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.defaulted_client_reports.evidence_file_path IS 'Path a archivo de evidencia (screenshots, grabaciones, etc.).';


--
-- TOC entry 257 (class 1259 OID 16662)
-- Name: defaulted_client_reports_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.defaulted_client_reports_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.defaulted_client_reports_id_seq OWNER TO credinet_user;

--
-- TOC entry 4529 (class 0 OID 0)
-- Dependencies: 257
-- Name: defaulted_client_reports_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.defaulted_client_reports_id_seq OWNED BY public.defaulted_client_reports.id;


--
-- TOC entry 258 (class 1259 OID 16663)
-- Name: document_statuses; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.document_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    display_order integer DEFAULT 0,
    color_code character varying(7),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.document_statuses OWNER TO credinet_user;

--
-- TOC entry 4530 (class 0 OID 0)
-- Dependencies: 258
-- Name: TABLE document_statuses; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.document_statuses IS 'Catálogo de estados para documentos de clientes (PENDING, APPROVED, REJECTED).';


--
-- TOC entry 259 (class 1259 OID 16671)
-- Name: document_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.document_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_statuses_id_seq OWNER TO credinet_user;

--
-- TOC entry 4531 (class 0 OID 0)
-- Dependencies: 259
-- Name: document_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.document_statuses_id_seq OWNED BY public.document_statuses.id;


--
-- TOC entry 260 (class 1259 OID 16672)
-- Name: document_types; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.document_types (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_required boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.document_types OWNER TO credinet_user;

--
-- TOC entry 4532 (class 0 OID 0)
-- Dependencies: 260
-- Name: TABLE document_types; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.document_types IS 'Tipos de documentos requeridos para clientes (INE, comprobante de domicilio, etc.).';


--
-- TOC entry 261 (class 1259 OID 16680)
-- Name: document_types_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.document_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.document_types_id_seq OWNER TO credinet_user;

--
-- TOC entry 4533 (class 0 OID 0)
-- Dependencies: 261
-- Name: document_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.document_types_id_seq OWNED BY public.document_types.id;


--
-- TOC entry 262 (class 1259 OID 16681)
-- Name: guarantors; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.guarantors (
    id integer NOT NULL,
    user_id integer NOT NULL,
    full_name character varying(200) NOT NULL,
    first_name character varying(100),
    paternal_last_name character varying(100),
    maternal_last_name character varying(100),
    relationship character varying(50) NOT NULL,
    phone_number character varying(20) NOT NULL,
    curp character varying(18),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    relationship_id integer,
    CONSTRAINT check_guarantors_curp_length CHECK (((curp IS NULL) OR (length((curp)::text) = 18))),
    CONSTRAINT check_guarantors_phone_format CHECK (((phone_number)::text ~ '^[0-9]{10}$'::text))
);


ALTER TABLE public.guarantors OWNER TO credinet_user;

--
-- TOC entry 4534 (class 0 OID 0)
-- Dependencies: 262
-- Name: TABLE guarantors; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.guarantors IS 'Avales o garantes de clientes (relación 1:1 con users).';


--
-- TOC entry 263 (class 1259 OID 16690)
-- Name: guarantors_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.guarantors_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.guarantors_id_seq OWNER TO credinet_user;

--
-- TOC entry 4535 (class 0 OID 0)
-- Dependencies: 263
-- Name: guarantors_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.guarantors_id_seq OWNED BY public.guarantors.id;


--
-- TOC entry 264 (class 1259 OID 16691)
-- Name: legacy_payment_table; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.legacy_payment_table (
    id integer NOT NULL,
    amount numeric(12,2) NOT NULL,
    biweekly_payment numeric(10,2) NOT NULL,
    term_biweeks integer DEFAULT 12 NOT NULL,
    total_payment numeric(12,2) GENERATED ALWAYS AS ((biweekly_payment * (term_biweeks)::numeric)) STORED,
    total_interest numeric(12,2) GENERATED ALWAYS AS (((biweekly_payment * (term_biweeks)::numeric) - amount)) STORED,
    effective_rate_percent numeric(5,2) GENERATED ALWAYS AS (round(((((biweekly_payment * (term_biweeks)::numeric) - amount) / amount) * (100)::numeric), 2)) STORED,
    biweekly_rate_percent numeric(5,3) GENERATED ALWAYS AS (round((((((biweekly_payment * (term_biweeks)::numeric) - amount) / amount) / (term_biweeks)::numeric) * (100)::numeric), 3)) STORED,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    associate_biweekly_payment numeric(10,2),
    commission_per_payment numeric(10,2) GENERATED ALWAYS AS ((biweekly_payment - COALESCE(associate_biweekly_payment, (0)::numeric))) STORED,
    associate_total_payment numeric(12,2) GENERATED ALWAYS AS ((COALESCE(associate_biweekly_payment, (0)::numeric) * (term_biweeks)::numeric)) STORED,
    total_commission numeric(12,2) GENERATED ALWAYS AS (((biweekly_payment - COALESCE(associate_biweekly_payment, (0)::numeric)) * (term_biweeks)::numeric)) STORED,
    CONSTRAINT check_legacy_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT check_legacy_payment_positive CHECK ((biweekly_payment > (0)::numeric)),
    CONSTRAINT check_legacy_term_valid CHECK (((term_biweeks >= 1) AND (term_biweeks <= 52)))
);


ALTER TABLE public.legacy_payment_table OWNER TO credinet_user;

--
-- TOC entry 4536 (class 0 OID 0)
-- Dependencies: 264
-- Name: TABLE legacy_payment_table; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.legacy_payment_table IS 'Tabla histórica de pagos quincenales. TOTALMENTE EDITABLE por admin. Permite agregar montos como $7,500, $12,350, etc.';


--
-- TOC entry 4537 (class 0 OID 0)
-- Dependencies: 264
-- Name: COLUMN legacy_payment_table.amount; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.legacy_payment_table.amount IS 'Monto del préstamo (capital). Debe ser único para cada plazo.';


--
-- TOC entry 4538 (class 0 OID 0)
-- Dependencies: 264
-- Name: COLUMN legacy_payment_table.biweekly_payment; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.legacy_payment_table.biweekly_payment IS 'Pago quincenal fijo para este monto. Admin puede editarlo.';


--
-- TOC entry 4539 (class 0 OID 0)
-- Dependencies: 264
-- Name: COLUMN legacy_payment_table.effective_rate_percent; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.legacy_payment_table.effective_rate_percent IS 'Tasa efectiva total calculada automáticamente.';


--
-- TOC entry 4540 (class 0 OID 0)
-- Dependencies: 264
-- Name: COLUMN legacy_payment_table.biweekly_rate_percent; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.legacy_payment_table.biweekly_rate_percent IS 'Tasa quincenal promedio calculada automáticamente.';


--
-- TOC entry 265 (class 1259 OID 16707)
-- Name: legacy_payment_table_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.legacy_payment_table_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.legacy_payment_table_id_seq OWNER TO credinet_user;

--
-- TOC entry 4541 (class 0 OID 0)
-- Dependencies: 265
-- Name: legacy_payment_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.legacy_payment_table_id_seq OWNED BY public.legacy_payment_table.id;


--
-- TOC entry 266 (class 1259 OID 16708)
-- Name: level_change_types; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.level_change_types (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_automatic boolean DEFAULT false,
    display_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.level_change_types OWNER TO credinet_user;

--
-- TOC entry 4542 (class 0 OID 0)
-- Dependencies: 266
-- Name: TABLE level_change_types; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.level_change_types IS 'Catálogo de tipos de cambio de nivel de asociados (PROMOTION, DEMOTION, MANUAL).';


--
-- TOC entry 267 (class 1259 OID 16717)
-- Name: level_change_types_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.level_change_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.level_change_types_id_seq OWNER TO credinet_user;

--
-- TOC entry 4543 (class 0 OID 0)
-- Dependencies: 267
-- Name: level_change_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.level_change_types_id_seq OWNED BY public.level_change_types.id;


--
-- TOC entry 268 (class 1259 OID 16718)
-- Name: loan_renewals; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.loan_renewals (
    id integer NOT NULL,
    original_loan_id integer NOT NULL,
    renewed_loan_id integer NOT NULL,
    renewal_date date NOT NULL,
    pending_balance numeric(12,2) NOT NULL,
    new_amount numeric(12,2) NOT NULL,
    reason text,
    created_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_loan_renewals_amounts_positive CHECK (((pending_balance >= (0)::numeric) AND (new_amount > (0)::numeric)))
);


ALTER TABLE public.loan_renewals OWNER TO credinet_user;

--
-- TOC entry 4544 (class 0 OID 0)
-- Dependencies: 268
-- Name: TABLE loan_renewals; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.loan_renewals IS 'Registro de renovaciones de préstamos (préstamo original → préstamo renovado).';


--
-- TOC entry 4545 (class 0 OID 0)
-- Dependencies: 268
-- Name: COLUMN loan_renewals.pending_balance; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loan_renewals.pending_balance IS 'Saldo pendiente del préstamo original al momento de la renovación.';


--
-- TOC entry 4546 (class 0 OID 0)
-- Dependencies: 268
-- Name: COLUMN loan_renewals.new_amount; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loan_renewals.new_amount IS 'Monto del nuevo préstamo (puede incluir o no el saldo pendiente).';


--
-- TOC entry 269 (class 1259 OID 16725)
-- Name: loan_renewals_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.loan_renewals_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loan_renewals_id_seq OWNER TO credinet_user;

--
-- TOC entry 4547 (class 0 OID 0)
-- Dependencies: 269
-- Name: loan_renewals_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.loan_renewals_id_seq OWNED BY public.loan_renewals.id;


--
-- TOC entry 270 (class 1259 OID 16726)
-- Name: loan_statuses; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.loan_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_active boolean DEFAULT true,
    display_order integer DEFAULT 0,
    color_code character varying(7),
    icon_name character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.loan_statuses OWNER TO credinet_user;

--
-- TOC entry 4548 (class 0 OID 0)
-- Dependencies: 270
-- Name: TABLE loan_statuses; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.loan_statuses IS 'Catálogo de estados posibles para préstamos. Normaliza loans.status_id.';


--
-- TOC entry 271 (class 1259 OID 16735)
-- Name: loan_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.loan_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loan_statuses_id_seq OWNER TO credinet_user;

--
-- TOC entry 4549 (class 0 OID 0)
-- Dependencies: 271
-- Name: loan_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.loan_statuses_id_seq OWNED BY public.loan_statuses.id;


--
-- TOC entry 272 (class 1259 OID 16736)
-- Name: loans; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.loans (
    id integer NOT NULL,
    user_id integer NOT NULL,
    associate_user_id integer,
    amount numeric(12,2) NOT NULL,
    interest_rate numeric(5,2) NOT NULL,
    commission_rate numeric(5,2) DEFAULT 0.0 NOT NULL,
    term_biweeks integer NOT NULL,
    status_id integer NOT NULL,
    contract_id integer,
    approved_at timestamp with time zone,
    approved_by integer,
    rejected_at timestamp with time zone,
    rejected_by integer,
    rejection_reason text,
    notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    profile_code character varying(50),
    biweekly_payment numeric(12,2),
    total_payment numeric(12,2),
    total_interest numeric(12,2),
    total_commission numeric(12,2),
    commission_per_payment numeric(10,2),
    associate_payment numeric(10,2),
    CONSTRAINT check_loans_amount_positive CHECK ((amount > (0)::numeric)),
    CONSTRAINT check_loans_approved_after_created CHECK (((approved_at IS NULL) OR (approved_at >= created_at))),
    CONSTRAINT check_loans_commission_rate_valid CHECK (((commission_rate >= (0)::numeric) AND (commission_rate <= (100)::numeric))),
    CONSTRAINT check_loans_interest_rate_valid CHECK (((interest_rate >= (0)::numeric) AND (interest_rate <= (100)::numeric))),
    CONSTRAINT check_loans_rejected_after_created CHECK (((rejected_at IS NULL) OR (rejected_at >= created_at))),
    CONSTRAINT check_loans_term_biweeks_valid CHECK ((term_biweeks = ANY (ARRAY[3, 6, 9, 12, 15, 18, 21, 24, 30, 36]))),
    CONSTRAINT chk_loans_associate_payment_consistent CHECK (((associate_payment IS NULL) OR (biweekly_payment IS NULL) OR (commission_per_payment IS NULL) OR (abs((associate_payment - (biweekly_payment - commission_per_payment))) < 0.10))),
    CONSTRAINT chk_loans_associate_payment_lte_biweekly CHECK (((associate_payment IS NULL) OR (biweekly_payment IS NULL) OR (associate_payment <= biweekly_payment))),
    CONSTRAINT chk_loans_biweekly_payment_positive CHECK (((biweekly_payment IS NULL) OR (biweekly_payment > (0)::numeric))),
    CONSTRAINT chk_loans_commission_per_payment_non_negative CHECK (((commission_per_payment IS NULL) OR (commission_per_payment >= (0)::numeric))),
    CONSTRAINT chk_loans_total_interest_consistent CHECK (((total_interest IS NULL) OR (total_payment IS NULL) OR (amount IS NULL) OR (abs((total_interest - (total_payment - amount))) < 1.00))),
    CONSTRAINT chk_loans_total_interest_non_negative CHECK (((total_interest IS NULL) OR (total_interest >= (0)::numeric))),
    CONSTRAINT chk_loans_total_payment_consistent CHECK (((total_payment IS NULL) OR (biweekly_payment IS NULL) OR (term_biweeks IS NULL) OR (abs((total_payment - (biweekly_payment * (term_biweeks)::numeric))) < 1.00))),
    CONSTRAINT chk_loans_total_payment_gte_amount CHECK (((total_payment IS NULL) OR (total_payment >= amount)))
);


ALTER TABLE public.loans OWNER TO credinet_user;

--
-- TOC entry 4550 (class 0 OID 0)
-- Dependencies: 272
-- Name: TABLE loans; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.loans IS 'Tabla central del sistema. Registra todos los préstamos solicitados, aprobados, rechazados o completados.';


--
-- TOC entry 4551 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN loans.commission_rate; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loans.commission_rate IS 'Tasa de comisión del asociado en porcentaje. Ejemplo: 2.5 = 2.5%. Rango válido: 0-100.';


--
-- TOC entry 4552 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN loans.term_biweeks; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loans.term_biweeks IS '⭐ V2.0: Plazo del préstamo en quincenas. Valores permitidos: 6, 12, 18 o 24 quincenas (3, 6, 9 o 12 meses). Validado por check_loans_term_biweeks_valid.';


--
-- TOC entry 4553 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN loans.profile_code; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loans.profile_code IS 'Código del perfil de tasa usado para este préstamo. NULL si se usaron tasas manuales.';


--
-- TOC entry 4554 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN loans.biweekly_payment; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loans.biweekly_payment IS 'Pago quincenal calculado que debe realizar el cliente (capital + interés). Calculado por calculate_loan_payment().';


--
-- TOC entry 4555 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN loans.total_payment; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loans.total_payment IS 'Monto total que pagará el cliente (biweekly_payment * term_biweeks). Incluye capital + interés total.';


--
-- TOC entry 4556 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN loans.total_interest; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loans.total_interest IS 'Interés total que pagará el cliente durante todo el préstamo (total_payment - amount).';


--
-- TOC entry 4557 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN loans.total_commission; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loans.total_commission IS 'Comisión total acumulada que se descontará en todos los pagos (commission_per_payment * term_biweeks).';


--
-- TOC entry 4558 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN loans.commission_per_payment; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loans.commission_per_payment IS 'Comisión que se descuenta del asociado en cada pago quincenal. Calculado por calculate_loan_payment().';


--
-- TOC entry 4559 (class 0 OID 0)
-- Dependencies: 272
-- Name: COLUMN loans.associate_payment; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.loans.associate_payment IS 'Pago neto que recibirá el asociado en cada periodo (biweekly_payment - commission_per_payment).';


--
-- TOC entry 273 (class 1259 OID 16758)
-- Name: loans_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.loans_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.loans_id_seq OWNER TO credinet_user;

--
-- TOC entry 4560 (class 0 OID 0)
-- Dependencies: 273
-- Name: loans_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.loans_id_seq OWNED BY public.loans.id;


--
-- TOC entry 274 (class 1259 OID 16759)
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.payment_methods (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    requires_reference boolean DEFAULT false,
    display_order integer DEFAULT 0,
    icon_name character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.payment_methods OWNER TO credinet_user;

--
-- TOC entry 4561 (class 0 OID 0)
-- Dependencies: 274
-- Name: TABLE payment_methods; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.payment_methods IS 'Catálogo de métodos de pago aceptados (efectivo, transferencia, OXXO, etc.).';


--
-- TOC entry 275 (class 1259 OID 16769)
-- Name: payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.payment_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_methods_id_seq OWNER TO credinet_user;

--
-- TOC entry 4562 (class 0 OID 0)
-- Dependencies: 275
-- Name: payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.payment_methods_id_seq OWNED BY public.payment_methods.id;


--
-- TOC entry 276 (class 1259 OID 16770)
-- Name: payment_status_history; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.payment_status_history (
    id integer NOT NULL,
    payment_id integer NOT NULL,
    old_status_id integer,
    new_status_id integer NOT NULL,
    change_type character varying(50) NOT NULL,
    changed_by integer,
    change_reason text,
    ip_address inet,
    user_agent text,
    changed_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT check_payment_status_history_change_type_valid CHECK (((change_type)::text = ANY (ARRAY[('AUTOMATIC'::character varying)::text, ('MANUAL_ADMIN'::character varying)::text, ('SYSTEM_CLOSURE'::character varying)::text, ('CORRECTION'::character varying)::text, ('TRIGGER'::character varying)::text]))),
    CONSTRAINT check_payment_status_history_manual_has_user CHECK (((((change_type)::text = ANY (ARRAY[('MANUAL_ADMIN'::character varying)::text, ('CORRECTION'::character varying)::text])) AND (changed_by IS NOT NULL)) OR ((change_type)::text <> ALL (ARRAY[('MANUAL_ADMIN'::character varying)::text, ('CORRECTION'::character varying)::text]))))
);


ALTER TABLE public.payment_status_history OWNER TO credinet_user;

--
-- TOC entry 4563 (class 0 OID 0)
-- Dependencies: 276
-- Name: TABLE payment_status_history; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.payment_status_history IS '⭐ MIGRACIÓN 12: Registro completo de todos los cambios de estado de pagos para auditoría y compliance.';


--
-- TOC entry 4564 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN payment_status_history.change_type; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payment_status_history.change_type IS 'Tipo de cambio: AUTOMATIC (trigger), MANUAL_ADMIN (admin marcó), SYSTEM_CLOSURE (cierre de período), CORRECTION (corrección manual).';


--
-- TOC entry 4565 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN payment_status_history.changed_by; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payment_status_history.changed_by IS 'Usuario que realizó el cambio. NULL si fue automático (trigger o cierre de sistema).';


--
-- TOC entry 4566 (class 0 OID 0)
-- Dependencies: 276
-- Name: COLUMN payment_status_history.change_reason; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payment_status_history.change_reason IS 'Razón del cambio (obligatorio en cambios manuales). Ej: "Cliente pagó en efectivo pero no se había registrado".';


--
-- TOC entry 277 (class 1259 OID 16778)
-- Name: payment_status_history_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.payment_status_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_status_history_id_seq OWNER TO credinet_user;

--
-- TOC entry 4567 (class 0 OID 0)
-- Dependencies: 277
-- Name: payment_status_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.payment_status_history_id_seq OWNED BY public.payment_status_history.id;


--
-- TOC entry 278 (class 1259 OID 16779)
-- Name: payment_statuses; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.payment_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_active boolean DEFAULT true,
    display_order integer DEFAULT 0,
    color_code character varying(7),
    icon_name character varying(50),
    is_real_payment boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.payment_statuses OWNER TO credinet_user;

--
-- TOC entry 4568 (class 0 OID 0)
-- Dependencies: 278
-- Name: TABLE payment_statuses; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.payment_statuses IS 'Catálogo de estados posibles para pagos. 12 estados consolidados (6 pendientes, 2 reales, 4 ficticios).';


--
-- TOC entry 4569 (class 0 OID 0)
-- Dependencies: 278
-- Name: COLUMN payment_statuses.is_real_payment; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payment_statuses.is_real_payment IS 'TRUE si el pago es dinero real cobrado, FALSE si es ficticio (absorbido, cancelado, perdonado).';


--
-- TOC entry 279 (class 1259 OID 16789)
-- Name: payment_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.payment_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payment_statuses_id_seq OWNER TO credinet_user;

--
-- TOC entry 4570 (class 0 OID 0)
-- Dependencies: 279
-- Name: payment_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.payment_statuses_id_seq OWNED BY public.payment_statuses.id;


--
-- TOC entry 280 (class 1259 OID 16790)
-- Name: payments; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.payments (
    id integer NOT NULL,
    loan_id integer NOT NULL,
    amount_paid numeric(12,2) DEFAULT 0,
    payment_date date,
    payment_due_date date NOT NULL,
    is_late boolean DEFAULT false NOT NULL,
    status_id integer,
    cut_period_id integer,
    marked_by integer,
    marked_at timestamp with time zone,
    marking_notes text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    payment_number integer,
    expected_amount numeric(12,2),
    interest_amount numeric(10,2),
    principal_amount numeric(10,2),
    commission_amount numeric(10,2),
    associate_payment numeric(10,2),
    balance_remaining numeric(12,2),
    associate_balance_remaining numeric(12,2),
    cumulative_associate_paid numeric(12,2) DEFAULT 0,
    total_associate_payment numeric(12,2) DEFAULT 0,
    notes text,
    CONSTRAINT check_payments_amount_paid_non_negative CHECK ((amount_paid >= (0)::numeric)),
    CONSTRAINT check_payments_dates_logical CHECK ((payment_date <= payment_due_date)),
    CONSTRAINT chk_payments_associate_equals_expected_minus_commission CHECK (((associate_payment IS NULL) OR (expected_amount IS NULL) OR (commission_amount IS NULL) OR (abs((associate_payment - (expected_amount - commission_amount))) < 0.10))),
    CONSTRAINT chk_payments_associate_lte_expected CHECK (((associate_payment IS NULL) OR (expected_amount IS NULL) OR (associate_payment <= expected_amount))),
    CONSTRAINT chk_payments_associate_payment_non_negative CHECK (((associate_payment IS NULL) OR (associate_payment >= (0)::numeric))),
    CONSTRAINT chk_payments_balance_non_negative CHECK (((balance_remaining IS NULL) OR (balance_remaining >= (0)::numeric))),
    CONSTRAINT chk_payments_commission_non_negative CHECK (((commission_amount IS NULL) OR (commission_amount >= (0)::numeric))),
    CONSTRAINT chk_payments_expected_amount_positive CHECK (((expected_amount IS NULL) OR (expected_amount > (0)::numeric))),
    CONSTRAINT chk_payments_expected_equals_interest_plus_principal CHECK (((expected_amount IS NULL) OR (interest_amount IS NULL) OR (principal_amount IS NULL) OR (abs((expected_amount - (interest_amount + principal_amount))) < 0.10))),
    CONSTRAINT chk_payments_interest_non_negative CHECK (((interest_amount IS NULL) OR (interest_amount >= (0)::numeric))),
    CONSTRAINT chk_payments_paid_lte_expected CHECK (((expected_amount IS NULL) OR (amount_paid <= (expected_amount + 100.00)))),
    CONSTRAINT chk_payments_payment_number_positive CHECK (((payment_number IS NULL) OR (payment_number > 0))),
    CONSTRAINT chk_payments_principal_non_negative CHECK (((principal_amount IS NULL) OR (principal_amount >= (0)::numeric)))
);


ALTER TABLE public.payments OWNER TO credinet_user;

--
-- TOC entry 4571 (class 0 OID 0)
-- Dependencies: 280
-- Name: TABLE payments; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.payments IS 'Schedule de pagos generado automáticamente cuando un préstamo es aprobado. Un registro por cada quincena del plazo.';


--
-- TOC entry 4572 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN payments.payment_due_date; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payments.payment_due_date IS 'Fecha de vencimiento del pago según reglas de negocio: día 15 o último día del mes. Generado por calculate_first_payment_date().';


--
-- TOC entry 4573 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN payments.is_late; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payments.is_late IS 'Indica si el pago está atrasado (TRUE si payment_due_date < CURRENT_DATE y no está pagado).';


--
-- TOC entry 4574 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN payments.marked_by; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payments.marked_by IS '⭐ v2.0: Usuario que marcó manualmente el estado del pago (admin puede remarcar).';


--
-- TOC entry 4575 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN payments.payment_number; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payments.payment_number IS 'Número secuencial del pago dentro del préstamo (1, 2, 3, ..., term_biweeks). Facilita ordenamiento y referencias.';


--
-- TOC entry 4576 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN payments.expected_amount; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payments.expected_amount IS 'Monto esperado que debe pagar el cliente en este periodo (incluye capital + interés). Valor de referencia para validar pagos.';


--
-- TOC entry 4577 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN payments.interest_amount; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payments.interest_amount IS 'Monto de interés correspondiente a este periodo. Parte del expected_amount que representa el costo del préstamo.';


--
-- TOC entry 4578 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN payments.principal_amount; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payments.principal_amount IS 'Monto de capital (abono al principal) correspondiente a este periodo. Reduce el saldo pendiente del préstamo.';


--
-- TOC entry 4579 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN payments.commission_amount; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payments.commission_amount IS 'Monto de comisión que se descuenta al asociado en este pago. Se calcula sobre el expected_amount.';


--
-- TOC entry 4580 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN payments.associate_payment; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payments.associate_payment IS 'Monto neto que recibe el asociado en este periodo (expected_amount - commission_amount).';


--
-- TOC entry 4581 (class 0 OID 0)
-- Dependencies: 280
-- Name: COLUMN payments.balance_remaining; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.payments.balance_remaining IS 'Saldo pendiente del préstamo después de aplicar el abono a capital de este pago. El último pago debe dejar balance=0.';


--
-- TOC entry 281 (class 1259 OID 16814)
-- Name: payments_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.payments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.payments_id_seq OWNER TO credinet_user;

--
-- TOC entry 4582 (class 0 OID 0)
-- Dependencies: 281
-- Name: payments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.payments_id_seq OWNED BY public.payments.id;


--
-- TOC entry 282 (class 1259 OID 16815)
-- Name: rate_profile_reference_table; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.rate_profile_reference_table (
    id integer NOT NULL,
    profile_code character varying(50) NOT NULL,
    amount numeric(12,2) NOT NULL,
    term_biweeks integer NOT NULL,
    biweekly_payment numeric(10,2) NOT NULL,
    total_payment numeric(12,2) NOT NULL,
    commission_per_payment numeric(10,2) NOT NULL,
    total_commission numeric(12,2) NOT NULL,
    associate_payment numeric(10,2) NOT NULL,
    associate_total numeric(12,2) NOT NULL,
    interest_rate_percent numeric(5,3),
    commission_rate_percent numeric(5,3),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.rate_profile_reference_table OWNER TO credinet_user;

--
-- TOC entry 4583 (class 0 OID 0)
-- Dependencies: 282
-- Name: TABLE rate_profile_reference_table; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.rate_profile_reference_table IS 'Tabla de referencia rápida con valores precalculados para consulta de administradores. Muestra pagos del cliente, asociado y comisiones para diferentes montos y plazos.';


--
-- TOC entry 283 (class 1259 OID 16819)
-- Name: rate_profile_reference_table_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.rate_profile_reference_table_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rate_profile_reference_table_id_seq OWNER TO credinet_user;

--
-- TOC entry 4584 (class 0 OID 0)
-- Dependencies: 283
-- Name: rate_profile_reference_table_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.rate_profile_reference_table_id_seq OWNED BY public.rate_profile_reference_table.id;


--
-- TOC entry 284 (class 1259 OID 16820)
-- Name: rate_profiles; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.rate_profiles (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    calculation_type character varying(20) NOT NULL,
    interest_rate_percent numeric(5,3),
    enabled boolean DEFAULT true,
    is_recommended boolean DEFAULT false,
    display_order integer DEFAULT 0,
    min_amount numeric(12,2),
    max_amount numeric(12,2),
    valid_terms integer[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    commission_rate_percent numeric(5,3),
    CONSTRAINT rate_profiles_calculation_type_check CHECK (((calculation_type)::text = ANY (ARRAY[('table_lookup'::character varying)::text, ('formula'::character varying)::text])))
);


ALTER TABLE public.rate_profiles OWNER TO credinet_user;

--
-- TOC entry 4585 (class 0 OID 0)
-- Dependencies: 284
-- Name: TABLE rate_profiles; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.rate_profiles IS 'Perfiles de tasa configurables con DOS TASAS independientes. Admin puede crear, editar, habilitar/deshabilitar perfiles.';


--
-- TOC entry 4586 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN rate_profiles.code; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.rate_profiles.code IS 'Código único interno. Ejemplos: legacy, standard, premium, custom_vip.';


--
-- TOC entry 4587 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN rate_profiles.calculation_type; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.rate_profiles.calculation_type IS 'Método de cálculo: table_lookup (busca en legacy_payment_table) o formula (usa las dos tasas fijas).';


--
-- TOC entry 4588 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN rate_profiles.interest_rate_percent; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.rate_profiles.interest_rate_percent IS 'Tasa de INTERÉS quincenal que paga el CLIENTE sobre el capital. Ejemplo: 4.250 = 4.25%. NULL para perfil legacy (usa tabla).';


--
-- TOC entry 4589 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN rate_profiles.is_recommended; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.rate_profiles.is_recommended IS 'Si TRUE, este perfil aparece destacado como "Recomendado" en UI.';


--
-- TOC entry 4590 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN rate_profiles.valid_terms; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.rate_profiles.valid_terms IS 'Array de plazos permitidos en quincenas. NULL = permite cualquier plazo.';


--
-- TOC entry 4591 (class 0 OID 0)
-- Dependencies: 284
-- Name: COLUMN rate_profiles.commission_rate_percent; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.rate_profiles.commission_rate_percent IS 'Tasa de COMISIÓN que cobra la empresa al ASOCIADO sobre cada pago del cliente. Ejemplo: 2.500 = 2.5%. NULL para perfil legacy o usa default 2.5%.';


--
-- TOC entry 285 (class 1259 OID 16831)
-- Name: rate_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.rate_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.rate_profiles_id_seq OWNER TO credinet_user;

--
-- TOC entry 4592 (class 0 OID 0)
-- Dependencies: 285
-- Name: rate_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.rate_profiles_id_seq OWNED BY public.rate_profiles.id;


--
-- TOC entry 286 (class 1259 OID 16832)
-- Name: relationships; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.relationships (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.relationships OWNER TO credinet_user;

--
-- TOC entry 287 (class 1259 OID 16840)
-- Name: relationships_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.relationships_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.relationships_id_seq OWNER TO credinet_user;

--
-- TOC entry 4593 (class 0 OID 0)
-- Dependencies: 287
-- Name: relationships_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.relationships_id_seq OWNED BY public.relationships.id;


--
-- TOC entry 288 (class 1259 OID 16841)
-- Name: roles; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.roles OWNER TO credinet_user;

--
-- TOC entry 4594 (class 0 OID 0)
-- Dependencies: 288
-- Name: TABLE roles; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.roles IS 'Roles de usuario en el sistema (desarrollador, admin, asociado, cliente).';


--
-- TOC entry 289 (class 1259 OID 16847)
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.roles_id_seq OWNER TO credinet_user;

--
-- TOC entry 4595 (class 0 OID 0)
-- Dependencies: 289
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- TOC entry 290 (class 1259 OID 16848)
-- Name: statement_statuses; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.statement_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_paid boolean DEFAULT false,
    display_order integer DEFAULT 0,
    color_code character varying(7),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.statement_statuses OWNER TO credinet_user;

--
-- TOC entry 4596 (class 0 OID 0)
-- Dependencies: 290
-- Name: TABLE statement_statuses; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.statement_statuses IS 'Catálogo de estados para cuentas de pago de asociados (GENERATED, PAID, OVERDUE).';


--
-- TOC entry 291 (class 1259 OID 16857)
-- Name: statement_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.statement_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.statement_statuses_id_seq OWNER TO credinet_user;

--
-- TOC entry 4597 (class 0 OID 0)
-- Dependencies: 291
-- Name: statement_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.statement_statuses_id_seq OWNED BY public.statement_statuses.id;


--
-- TOC entry 292 (class 1259 OID 16858)
-- Name: system_configurations; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.system_configurations (
    id integer NOT NULL,
    config_key character varying(100) NOT NULL,
    config_value text NOT NULL,
    description text,
    config_type_id integer NOT NULL,
    updated_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.system_configurations OWNER TO credinet_user;

--
-- TOC entry 4598 (class 0 OID 0)
-- Dependencies: 292
-- Name: TABLE system_configurations; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.system_configurations IS 'Configuraciones globales del sistema (tasas, montos, flags de funcionalidad).';


--
-- TOC entry 293 (class 1259 OID 16865)
-- Name: system_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.system_configurations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.system_configurations_id_seq OWNER TO credinet_user;

--
-- TOC entry 4599 (class 0 OID 0)
-- Dependencies: 293
-- Name: system_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.system_configurations_id_seq OWNED BY public.system_configurations.id;


--
-- TOC entry 294 (class 1259 OID 16866)
-- Name: user_roles; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.user_roles (
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_roles OWNER TO credinet_user;

--
-- TOC entry 4600 (class 0 OID 0)
-- Dependencies: 294
-- Name: TABLE user_roles; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.user_roles IS 'Relación N:M entre usuarios y roles. Un usuario puede tener múltiples roles.';


--
-- TOC entry 295 (class 1259 OID 16870)
-- Name: users; Type: TABLE; Schema: public; Owner: credinet_user
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    email character varying(150),
    phone_number character varying(20) NOT NULL,
    birth_date date,
    curp character varying(18),
    profile_picture_url character varying(500),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true NOT NULL,
    CONSTRAINT check_users_curp_length CHECK (((curp IS NULL) OR (length((curp)::text) = 18))),
    CONSTRAINT check_users_phone_format CHECK (((phone_number)::text ~ '^[0-9]{10}$'::text))
);


ALTER TABLE public.users OWNER TO credinet_user;

--
-- TOC entry 4601 (class 0 OID 0)
-- Dependencies: 295
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TABLE public.users IS 'Usuarios del sistema (clientes, asociados, administradores).';


--
-- TOC entry 4602 (class 0 OID 0)
-- Dependencies: 295
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.users.password_hash IS 'Hash bcrypt de la contraseña del usuario. NUNCA almacenar contraseñas en texto plano.';


--
-- TOC entry 4603 (class 0 OID 0)
-- Dependencies: 295
-- Name: COLUMN users.email; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.users.email IS 'Email del usuario (OPCIONAL - algunos usuarios mayores pueden no tener correo electrónico).';


--
-- TOC entry 4604 (class 0 OID 0)
-- Dependencies: 295
-- Name: COLUMN users.curp; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.users.curp IS 'Clave Única de Registro de Población (CURP) de México. Formato: 18 caracteres alfanuméricos.';


--
-- TOC entry 4605 (class 0 OID 0)
-- Dependencies: 295
-- Name: COLUMN users.active; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON COLUMN public.users.active IS 'Indica si el usuario está activo en el sistema. Los usuarios inactivos no pueden iniciar sesión.';


--
-- TOC entry 296 (class 1259 OID 16880)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: credinet_user
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO credinet_user;

--
-- TOC entry 4606 (class 0 OID 0)
-- Dependencies: 296
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: credinet_user
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- TOC entry 297 (class 1259 OID 16881)
-- Name: v_associate_all_payments; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_associate_all_payments AS
 SELECT asp.id,
    'SALDO_ACTUAL'::text AS payment_type,
    ap.id AS associate_profile_id,
    concat(u.first_name, ' ', u.last_name) AS associate_name,
    asp.payment_amount,
    asp.payment_date,
    pm.name AS payment_method,
    asp.payment_reference,
    aps.cut_period_id,
    cp.period_start_date AS period_start,
    cp.period_end_date AS period_end,
    asp.notes,
    asp.created_at
   FROM (((((public.associate_statement_payments asp
     JOIN public.associate_payment_statements aps ON ((aps.id = asp.statement_id)))
     JOIN public.users u ON ((u.id = aps.user_id)))
     JOIN public.associate_profiles ap ON ((ap.user_id = u.id)))
     JOIN public.payment_methods pm ON ((pm.id = asp.payment_method_id)))
     LEFT JOIN public.cut_periods cp ON ((cp.id = aps.cut_period_id)))
UNION ALL
 SELECT adp.id,
    'DEUDA_ACUMULADA'::text AS payment_type,
    adp.associate_profile_id,
    concat(u.first_name, ' ', u.last_name) AS associate_name,
    adp.payment_amount,
    adp.payment_date,
    pm.name AS payment_method,
    adp.payment_reference,
    NULL::integer AS cut_period_id,
    NULL::date AS period_start,
    NULL::date AS period_end,
    adp.notes,
    adp.created_at
   FROM (((public.associate_debt_payments adp
     JOIN public.associate_profiles ap ON ((ap.id = adp.associate_profile_id)))
     JOIN public.users u ON ((u.id = ap.user_id)))
     JOIN public.payment_methods pm ON ((pm.id = adp.payment_method_id)))
UNION ALL
 SELECT ap_conv.id,
    'PAGO_CONVENIO'::text AS payment_type,
    agr.associate_profile_id,
    concat(u.first_name, ' ', u.last_name) AS associate_name,
    ap_conv.payment_amount,
    ap_conv.payment_date,
    (COALESCE(pm.name, 'N/A'::character varying))::character varying(50) AS payment_method,
    ap_conv.payment_reference,
    NULL::integer AS cut_period_id,
    NULL::date AS period_start,
    NULL::date AS period_end,
    concat('Pago #', ap_conv.payment_number, ' - ', agr.agreement_number) AS notes,
    ap_conv.created_at
   FROM ((((public.agreement_payments ap_conv
     JOIN public.agreements agr ON ((agr.id = ap_conv.agreement_id)))
     JOIN public.associate_profiles aprof ON ((aprof.id = agr.associate_profile_id)))
     JOIN public.users u ON ((u.id = aprof.user_id)))
     LEFT JOIN public.payment_methods pm ON ((pm.id = ap_conv.payment_method_id)))
  WHERE ((ap_conv.status)::text = 'PAID'::text)
  ORDER BY 6 DESC, 13 DESC;


ALTER TABLE public.v_associate_all_payments OWNER TO credinet_user;

--
-- TOC entry 298 (class 1259 OID 16886)
-- Name: v_associate_credit_complete; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_associate_credit_complete AS
 SELECT ap.id AS associate_profile_id,
    u.id AS user_id,
    concat(u.first_name, ' ', u.last_name) AS associate_name,
    u.email,
    u.phone_number,
    al.name AS level,
    ap.credit_limit,
    ap.pending_payments_total,
    ap.available_credit,
    ap.consolidated_debt,
    ap.available_credit AS real_available_credit,
    round((((ap.pending_payments_total)::numeric / NULLIF(ap.credit_limit, (0)::numeric)) * (100)::numeric), 2) AS usage_percentage,
    round((((ap.consolidated_debt)::numeric / NULLIF(ap.credit_limit, (0)::numeric)) * (100)::numeric), 2) AS debt_percentage,
    round(((ap.available_credit / NULLIF(ap.credit_limit, (0)::numeric)) * (100)::numeric), 2) AS real_available_percentage,
        CASE
            WHEN (ap.available_credit <= (0)::numeric) THEN 'SIN_CREDITO'::text
            WHEN (ap.available_credit < (ap.credit_limit * 0.25)) THEN 'CRITICO'::text
            WHEN (ap.available_credit < (ap.credit_limit * 0.50)) THEN 'MEDIO'::text
            ELSE 'ALTO'::text
        END AS credit_health_status,
        CASE
            WHEN (ap.consolidated_debt = (0)::numeric) THEN 'SIN_DEUDA'::text
            WHEN (ap.consolidated_debt < (ap.credit_limit * 0.10)) THEN 'DEUDA_BAJA'::text
            WHEN (ap.consolidated_debt < (ap.credit_limit * 0.25)) THEN 'DEUDA_MEDIA'::text
            ELSE 'DEUDA_ALTA'::text
        END AS debt_status,
    ap.consecutive_full_credit_periods,
    ap.consecutive_on_time_payments,
    ap.clients_in_agreement,
    ap.active,
    ap.credit_last_updated,
    ap.last_level_evaluation_date
   FROM ((public.associate_profiles ap
     JOIN public.users u ON ((ap.user_id = u.id)))
     JOIN public.associate_levels al ON ((ap.level_id = al.id)))
  ORDER BY ap.available_credit DESC;


ALTER TABLE public.v_associate_credit_complete OWNER TO credinet_user;

--
-- TOC entry 299 (class 1259 OID 16891)
-- Name: v_associate_credit_summary; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_associate_credit_summary AS
 SELECT ap.id AS associate_profile_id,
    u.id AS user_id,
    concat(u.first_name, ' ', u.last_name) AS associate_name,
    u.email,
    al.name AS associate_level,
    ap.credit_limit,
    ap.pending_payments_total,
    ap.consolidated_debt,
    ap.available_credit,
    ap.credit_last_updated,
        CASE
            WHEN (ap.available_credit <= (0)::numeric) THEN 'SIN_CREDITO'::text
            WHEN (ap.available_credit < (ap.credit_limit * 0.25)) THEN 'CRITICO'::text
            WHEN (ap.available_credit < (ap.credit_limit * 0.50)) THEN 'MEDIO'::text
            ELSE 'ALTO'::text
        END AS credit_status,
    round((((ap.pending_payments_total)::numeric / NULLIF(ap.credit_limit, (0)::numeric)) * (100)::numeric), 2) AS credit_usage_percentage,
    ap.active AS is_active
   FROM ((public.associate_profiles ap
     JOIN public.users u ON ((ap.user_id = u.id)))
     JOIN public.associate_levels al ON ((ap.level_id = al.id)))
  ORDER BY ap.available_credit DESC;


ALTER TABLE public.v_associate_credit_summary OWNER TO credinet_user;

--
-- TOC entry 300 (class 1259 OID 16896)
-- Name: v_associate_late_fees; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_associate_late_fees AS
 SELECT aps.id AS statement_id,
    aps.statement_number,
    concat(u.first_name, ' ', u.last_name) AS associate_name,
    cp.cut_number,
    cp.period_start_date,
    cp.period_end_date,
    aps.total_payments_count,
    aps.total_amount_collected,
    aps.total_to_credicuenta,
    aps.commission_earned,
    aps.late_fee_amount,
    aps.late_fee_applied,
    ss.name AS statement_status,
        CASE
            WHEN aps.late_fee_applied THEN 'MORA APLICADA'::text
            WHEN ((aps.total_payments_count = 0) AND (aps.total_to_credicuenta > (0)::numeric)) THEN 'SUJETO A MORA'::text
            ELSE 'SIN MORA'::text
        END AS late_fee_status,
    round(((aps.late_fee_amount / NULLIF(aps.total_to_credicuenta, (0)::numeric)) * (100)::numeric), 2) AS late_fee_percentage,
    aps.generated_date,
    aps.due_date,
    aps.paid_date
   FROM (((public.associate_payment_statements aps
     JOIN public.users u ON ((aps.user_id = u.id)))
     JOIN public.cut_periods cp ON ((aps.cut_period_id = cp.id)))
     JOIN public.statement_statuses ss ON ((aps.status_id = ss.id)))
  WHERE ((aps.late_fee_amount > (0)::numeric) OR ((aps.total_payments_count = 0) AND (aps.total_to_credicuenta > (0)::numeric)))
  ORDER BY aps.generated_date DESC, aps.late_fee_amount DESC;


ALTER TABLE public.v_associate_late_fees OWNER TO credinet_user;

--
-- TOC entry 301 (class 1259 OID 16901)
-- Name: v_associate_real_debt_summary; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_associate_real_debt_summary AS
 SELECT ap.id AS associate_profile_id,
    ap.user_id,
    concat(u.first_name, ' ', u.last_name) AS associate_name,
    COALESCE(debt_agg.total_accumulated_debt, (0)::numeric) AS total_debt,
    COALESCE(debt_agg.periods_with_debt, (0)::bigint) AS periods_with_debt,
    debt_agg.oldest_debt_date,
    debt_agg.newest_debt_date,
    ap.consolidated_debt AS profile_consolidated_debt,
    ap.credit_limit,
    ap.available_credit,
    ap.pending_payments_total,
    COALESCE(payments_agg.total_paid_to_debt, (0)::numeric) AS total_paid_to_debt,
    COALESCE(payments_agg.total_payments_count, (0)::bigint) AS total_payments_count,
    payments_agg.last_payment_date
   FROM (((public.associate_profiles ap
     JOIN public.users u ON ((u.id = ap.user_id)))
     LEFT JOIN ( SELECT associate_accumulated_balances.user_id,
            sum(associate_accumulated_balances.accumulated_debt) AS total_accumulated_debt,
            count(*) AS periods_with_debt,
            min(associate_accumulated_balances.created_at) AS oldest_debt_date,
            max(associate_accumulated_balances.created_at) AS newest_debt_date
           FROM public.associate_accumulated_balances
          WHERE (associate_accumulated_balances.accumulated_debt > (0)::numeric)
          GROUP BY associate_accumulated_balances.user_id) debt_agg ON ((debt_agg.user_id = ap.user_id)))
     LEFT JOIN ( SELECT associate_debt_payments.associate_profile_id,
            sum(associate_debt_payments.payment_amount) AS total_paid_to_debt,
            count(*) AS total_payments_count,
            max(associate_debt_payments.payment_date) AS last_payment_date
           FROM public.associate_debt_payments
          GROUP BY associate_debt_payments.associate_profile_id) payments_agg ON ((payments_agg.associate_profile_id = ap.id)));


ALTER TABLE public.v_associate_real_debt_summary OWNER TO credinet_user;

--
-- TOC entry 302 (class 1259 OID 16906)
-- Name: v_cut_periods_readable; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_cut_periods_readable AS
 SELECT cut_periods.id,
    cut_periods.cut_code,
    cut_periods.period_start_date,
    cut_periods.period_end_date,
    ((cut_periods.period_end_date - cut_periods.period_start_date) + 1) AS days_in_period,
    to_char((cut_periods.period_start_date)::timestamp with time zone, 'DD-Mon-YYYY'::text) AS start_formatted,
    to_char((cut_periods.period_end_date)::timestamp with time zone, 'DD-Mon-YYYY'::text) AS end_formatted,
        CASE
            WHEN (EXTRACT(day FROM cut_periods.period_start_date) = (8)::numeric) THEN 'Primera Quincena'::text
            WHEN (EXTRACT(day FROM cut_periods.period_start_date) = (23)::numeric) THEN 'Segunda Quincena'::text
            ELSE 'Irregular'::text
        END AS period_type,
    cut_periods.status_id,
    cut_periods.total_payments_expected,
    cut_periods.total_payments_received,
    cut_periods.total_commission
   FROM public.cut_periods;


ALTER TABLE public.v_cut_periods_readable OWNER TO credinet_user;

--
-- TOC entry 4607 (class 0 OID 0)
-- Dependencies: 302
-- Name: VIEW v_cut_periods_readable; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON VIEW public.v_cut_periods_readable IS 'Vista con códigos de períodos en formato legible (Ene01-2025) y fechas formateadas para español';


--
-- TOC entry 303 (class 1259 OID 16911)
-- Name: v_loans_summary; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_loans_summary AS
 SELECT l.id,
    l.user_id,
    u.username,
    l.amount AS capital,
    l.term_biweeks AS plazo_quincenas,
    l.profile_code,
    rp.name AS profile_name,
    l.biweekly_payment AS pago_quincenal,
    l.total_payment AS pago_total,
    l.total_interest AS interes_total,
    l.commission_per_payment AS comision_por_pago,
    l.associate_payment AS pago_al_asociado,
    l.total_commission AS comision_total,
    ls.name AS estado,
    l.created_at AS fecha_creacion,
    l.approved_at AS fecha_aprobacion,
        CASE
            WHEN (l.amount > (0)::numeric) THEN round(((l.total_interest / l.amount) * (100)::numeric), 2)
            ELSE NULL::numeric
        END AS tasa_interes_efectiva_pct,
        CASE
            WHEN (l.biweekly_payment > (0)::numeric) THEN round(((l.commission_per_payment / l.biweekly_payment) * (100)::numeric), 2)
            ELSE NULL::numeric
        END AS comision_pct
   FROM (((public.loans l
     LEFT JOIN public.users u ON ((l.user_id = u.id)))
     LEFT JOIN public.rate_profiles rp ON (((l.profile_code)::text = (rp.code)::text)))
     LEFT JOIN public.loan_statuses ls ON ((l.status_id = ls.id)))
  WHERE (l.biweekly_payment IS NOT NULL);


ALTER TABLE public.v_loans_summary OWNER TO credinet_user;

--
-- TOC entry 4608 (class 0 OID 0)
-- Dependencies: 303
-- Name: VIEW v_loans_summary; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON VIEW public.v_loans_summary IS 'Vista de resumen de préstamos con campos calculados y métricas derivadas.';


--
-- TOC entry 304 (class 1259 OID 16916)
-- Name: v_payment_changes_summary; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_payment_changes_summary AS
 SELECT date(psh.changed_at) AS change_date,
    psh.change_type,
    count(*) AS total_changes,
    count(DISTINCT psh.payment_id) AS unique_payments,
    count(DISTINCT psh.changed_by) AS unique_users,
    string_agg(DISTINCT (ps_new.name)::text, ', '::text) AS status_changes_to,
    min(psh.changed_at) AS first_change,
    max(psh.changed_at) AS last_change
   FROM (public.payment_status_history psh
     JOIN public.payment_statuses ps_new ON ((psh.new_status_id = ps_new.id)))
  GROUP BY (date(psh.changed_at)), psh.change_type
  ORDER BY (date(psh.changed_at)) DESC, (count(*)) DESC;


ALTER TABLE public.v_payment_changes_summary OWNER TO credinet_user;

--
-- TOC entry 4609 (class 0 OID 0)
-- Dependencies: 304
-- Name: VIEW v_payment_changes_summary; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON VIEW public.v_payment_changes_summary IS '⭐ MIGRACIÓN 12: Resumen estadístico diario de cambios de estado de pagos agrupados por tipo (AUTOMATIC, MANUAL_ADMIN, etc.).';


--
-- TOC entry 305 (class 1259 OID 16921)
-- Name: v_payments_absorbed_by_associate; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_payments_absorbed_by_associate AS
 SELECT concat(ua.first_name, ' ', ua.last_name) AS associate_name,
    ap.id AS associate_profile_id,
    count(p.id) AS total_payments_absorbed,
    sum(p.amount_paid) AS total_amount_absorbed,
    ps.name AS payment_status,
    cp.cut_number,
    cp.period_start_date,
    cp.period_end_date,
    string_agg(DISTINCT concat(uc.first_name, ' ', uc.last_name), ', '::text) AS affected_clients
   FROM ((((((public.payments p
     JOIN public.payment_statuses ps ON ((p.status_id = ps.id)))
     JOIN public.loans l ON ((p.loan_id = l.id)))
     JOIN public.users uc ON ((l.user_id = uc.id)))
     JOIN public.users ua ON ((l.associate_user_id = ua.id)))
     JOIN public.associate_profiles ap ON ((ua.id = ap.user_id)))
     LEFT JOIN public.cut_periods cp ON ((p.cut_period_id = cp.id)))
  WHERE ((ps.is_real_payment = false) AND ((ps.name)::text = ANY (ARRAY[('PAID_BY_ASSOCIATE'::character varying)::text, ('PAID_NOT_REPORTED'::character varying)::text])))
  GROUP BY ua.first_name, ua.last_name, ap.id, ps.name, cp.cut_number, cp.period_start_date, cp.period_end_date
  ORDER BY (sum(p.amount_paid)) DESC;


ALTER TABLE public.v_payments_absorbed_by_associate OWNER TO credinet_user;

--
-- TOC entry 4610 (class 0 OID 0)
-- Dependencies: 305
-- Name: VIEW v_payments_absorbed_by_associate; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON VIEW public.v_payments_absorbed_by_associate IS '⭐ MIGRACIÓN 11: Resumen de pagos absorbidos por cada asociado (PAID_BY_ASSOCIATE, PAID_NOT_REPORTED) con totales y clientes afectados.';


--
-- TOC entry 306 (class 1259 OID 16926)
-- Name: v_payments_by_status_detailed; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_payments_by_status_detailed AS
 SELECT p.id AS payment_id,
    p.loan_id,
    concat(u.first_name, ' ', u.last_name) AS client_name,
    l.amount AS loan_amount,
    p.amount_paid,
    p.payment_date,
    p.payment_due_date,
    p.is_late,
    ps.name AS payment_status,
    ps.is_real_payment,
        CASE
            WHEN ps.is_real_payment THEN 'REAL 💵'::text
            ELSE 'FICTICIO ⚠️'::text
        END AS payment_type,
    concat(um.first_name, ' ', um.last_name) AS marked_by_name,
    p.marked_at,
    p.marking_notes,
    cp.cut_number,
    cp.period_start_date,
    cp.period_end_date,
    concat(ua.first_name, ' ', ua.last_name) AS associate_name,
    p.created_at,
    p.updated_at
   FROM ((((((public.payments p
     JOIN public.loans l ON ((p.loan_id = l.id)))
     JOIN public.users u ON ((l.user_id = u.id)))
     JOIN public.payment_statuses ps ON ((p.status_id = ps.id)))
     LEFT JOIN public.users um ON ((p.marked_by = um.id)))
     LEFT JOIN public.cut_periods cp ON ((p.cut_period_id = cp.id)))
     LEFT JOIN public.users ua ON ((l.associate_user_id = ua.id)))
  ORDER BY p.payment_due_date DESC, p.id DESC;


ALTER TABLE public.v_payments_by_status_detailed OWNER TO credinet_user;

--
-- TOC entry 4611 (class 0 OID 0)
-- Dependencies: 306
-- Name: VIEW v_payments_by_status_detailed; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON VIEW public.v_payments_by_status_detailed IS '⭐ MIGRACIÓN 11: Vista detallada de todos los pagos con su estado, tipo (real/ficticio) y tracking de marcado manual.';


--
-- TOC entry 307 (class 1259 OID 16931)
-- Name: v_payments_multiple_changes; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_payments_multiple_changes AS
 SELECT p.id AS payment_id,
    p.loan_id,
    concat(u.first_name, ' ', u.last_name) AS client_name,
    count(psh.id) AS total_changes,
    string_agg(concat(ps.name, ' (', to_char(psh.changed_at, 'YYYY-MM-DD HH24:MI'::text), ')'), ' → '::text ORDER BY psh.changed_at) AS status_timeline,
    min(psh.changed_at) AS first_change,
    max(psh.changed_at) AS last_change,
    (EXTRACT(epoch FROM (max(psh.changed_at) - min(psh.changed_at))) / (3600)::numeric) AS hours_between_first_last,
    count(
        CASE
            WHEN ((psh.change_type)::text = 'MANUAL_ADMIN'::text) THEN 1
            ELSE NULL::integer
        END) AS manual_changes_count,
        CASE
            WHEN (count(psh.id) >= 5) THEN 'CRÍTICO'::text
            WHEN (count(psh.id) >= 3) THEN 'ALERTA'::text
            ELSE 'NORMAL'::text
        END AS review_priority
   FROM ((((public.payments p
     JOIN public.payment_status_history psh ON ((p.id = psh.payment_id)))
     JOIN public.payment_statuses ps ON ((psh.new_status_id = ps.id)))
     JOIN public.loans l ON ((p.loan_id = l.id)))
     JOIN public.users u ON ((l.user_id = u.id)))
  GROUP BY p.id, p.loan_id, u.first_name, u.last_name
 HAVING (count(psh.id) >= 3)
  ORDER BY (count(psh.id)) DESC, (max(psh.changed_at)) DESC;


ALTER TABLE public.v_payments_multiple_changes OWNER TO credinet_user;

--
-- TOC entry 4612 (class 0 OID 0)
-- Dependencies: 307
-- Name: VIEW v_payments_multiple_changes; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON VIEW public.v_payments_multiple_changes IS '⭐ MIGRACIÓN 12: Pagos con 3 o más cambios de estado (posibles errores, fraude o correcciones múltiples). Prioridad CRÍTICA para revisión forense.';


--
-- TOC entry 308 (class 1259 OID 16936)
-- Name: v_payments_summary; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_payments_summary AS
 SELECT p.id,
    p.loan_id,
    l.user_id,
    u.username,
    p.payment_number,
    p.payment_due_date AS fecha_vencimiento,
    p.expected_amount AS monto_esperado,
    p.amount_paid AS monto_pagado,
    p.interest_amount AS interes,
    p.principal_amount AS capital,
    p.commission_amount AS comision,
    p.associate_payment AS pago_asociado,
    p.balance_remaining AS saldo_pendiente,
    ps.name AS estado_pago,
    cp.period_start_date AS periodo_inicio,
    cp.period_end_date AS periodo_fin,
    p.is_late AS esta_atrasado,
        CASE
            WHEN (p.expected_amount > (0)::numeric) THEN round(((p.amount_paid / p.expected_amount) * (100)::numeric), 2)
            ELSE (0)::numeric
        END AS porcentaje_pagado,
        CASE
            WHEN (p.amount_paid >= p.expected_amount) THEN 'PAGADO COMPLETO'::text
            WHEN (p.amount_paid > (0)::numeric) THEN 'PAGO PARCIAL'::text
            ELSE 'SIN PAGAR'::text
        END AS estado_pago_detalle,
    (p.expected_amount - p.amount_paid) AS saldo_pago
   FROM ((((public.payments p
     JOIN public.loans l ON ((p.loan_id = l.id)))
     LEFT JOIN public.users u ON ((l.user_id = u.id)))
     LEFT JOIN public.payment_statuses ps ON ((p.status_id = ps.id)))
     LEFT JOIN public.cut_periods cp ON ((p.cut_period_id = cp.id)))
  WHERE (p.expected_amount IS NOT NULL)
  ORDER BY l.id, p.payment_number;


ALTER TABLE public.v_payments_summary OWNER TO credinet_user;

--
-- TOC entry 4613 (class 0 OID 0)
-- Dependencies: 308
-- Name: VIEW v_payments_summary; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON VIEW public.v_payments_summary IS 'Vista de resumen de pagos con desglose completo y métricas derivadas.';


--
-- TOC entry 309 (class 1259 OID 16941)
-- Name: v_period_closure_summary; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_period_closure_summary AS
 SELECT cp.id AS cut_period_id,
    cp.cut_number,
    cp.period_start_date,
    cp.period_end_date,
    cps.name AS period_status,
    count(p.id) AS total_payments,
    count(
        CASE
            WHEN ((ps.name)::text = 'PAID'::text) THEN 1
            ELSE NULL::integer
        END) AS payments_paid,
    count(
        CASE
            WHEN ((ps.name)::text = 'PAID_NOT_REPORTED'::text) THEN 1
            ELSE NULL::integer
        END) AS payments_not_reported,
    count(
        CASE
            WHEN ((ps.name)::text = 'PAID_BY_ASSOCIATE'::text) THEN 1
            ELSE NULL::integer
        END) AS payments_by_associate,
    count(
        CASE
            WHEN ((ps.name)::text = ANY (ARRAY[('PENDING'::character varying)::text, ('DUE_TODAY'::character varying)::text, ('OVERDUE'::character varying)::text])) THEN 1
            ELSE NULL::integer
        END) AS payments_pending,
    COALESCE(sum(
        CASE
            WHEN ((ps.name)::text = 'PAID'::text) THEN p.amount_paid
            ELSE (0)::numeric
        END), (0)::numeric) AS total_collected,
    cp.total_payments_expected,
    cp.total_commission,
    concat(u.first_name, ' ', u.last_name) AS closed_by_name,
    cp.updated_at AS last_updated
   FROM ((((public.cut_periods cp
     JOIN public.cut_period_statuses cps ON ((cp.status_id = cps.id)))
     LEFT JOIN public.payments p ON ((cp.id = p.cut_period_id)))
     LEFT JOIN public.payment_statuses ps ON ((p.status_id = ps.id)))
     LEFT JOIN public.users u ON ((cp.closed_by = u.id)))
  GROUP BY cp.id, cp.cut_number, cp.period_start_date, cp.period_end_date, cps.name, cp.total_payments_expected, cp.total_commission, u.first_name, u.last_name, cp.updated_at
  ORDER BY cp.period_start_date DESC;


ALTER TABLE public.v_period_closure_summary OWNER TO credinet_user;

--
-- TOC entry 4614 (class 0 OID 0)
-- Dependencies: 309
-- Name: VIEW v_period_closure_summary; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON VIEW public.v_period_closure_summary IS '⭐ MIGRACIÓN 08: Resumen de cierre de cada período de corte con estadísticas de pagos por estado (PAID, PAID_NOT_REPORTED, PAID_BY_ASSOCIATE).';


--
-- TOC entry 310 (class 1259 OID 16946)
-- Name: v_rate_reference_12q; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_rate_reference_12q AS
 SELECT rate_profile_reference_table.profile_code AS "Perfil",
    rate_profile_reference_table.amount AS "Importe",
    rate_profile_reference_table.biweekly_payment AS "Pago Cliente",
    rate_profile_reference_table.total_payment AS "Total Cliente",
    rate_profile_reference_table.commission_per_payment AS "Comisión",
    rate_profile_reference_table.total_commission AS "Comisión Total",
    rate_profile_reference_table.associate_payment AS "Pago Asociado",
    rate_profile_reference_table.associate_total AS "Total Asociado"
   FROM public.rate_profile_reference_table
  WHERE (rate_profile_reference_table.term_biweeks = 12)
  ORDER BY rate_profile_reference_table.profile_code, rate_profile_reference_table.amount;


ALTER TABLE public.v_rate_reference_12q OWNER TO credinet_user;

--
-- TOC entry 4615 (class 0 OID 0)
-- Dependencies: 310
-- Name: VIEW v_rate_reference_12q; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON VIEW public.v_rate_reference_12q IS 'Vista de referencia rápida a 12 quincenas para comparar con legacy.';


--
-- TOC entry 311 (class 1259 OID 16950)
-- Name: v_recent_payment_changes; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_recent_payment_changes AS
 SELECT psh.id AS change_id,
    psh.payment_id,
    p.loan_id,
    concat(u.first_name, ' ', u.last_name) AS client_name,
    ps_old.name AS old_status,
    ps_new.name AS new_status,
    psh.change_type,
    concat(uc.first_name, ' ', uc.last_name) AS changed_by_name,
    psh.change_reason,
    psh.changed_at,
    (EXTRACT(epoch FROM (CURRENT_TIMESTAMP - psh.changed_at)) / (3600)::numeric) AS hours_ago
   FROM ((((((public.payment_status_history psh
     JOIN public.payments p ON ((psh.payment_id = p.id)))
     JOIN public.loans l ON ((p.loan_id = l.id)))
     JOIN public.users u ON ((l.user_id = u.id)))
     LEFT JOIN public.payment_statuses ps_old ON ((psh.old_status_id = ps_old.id)))
     JOIN public.payment_statuses ps_new ON ((psh.new_status_id = ps_new.id)))
     LEFT JOIN public.users uc ON ((psh.changed_by = uc.id)))
  WHERE (psh.changed_at >= (CURRENT_TIMESTAMP - '24:00:00'::interval))
  ORDER BY psh.changed_at DESC;


ALTER TABLE public.v_recent_payment_changes OWNER TO credinet_user;

--
-- TOC entry 4616 (class 0 OID 0)
-- Dependencies: 311
-- Name: VIEW v_recent_payment_changes; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON VIEW public.v_recent_payment_changes IS '⭐ MIGRACIÓN 12: Cambios de estado de pagos en las últimas 24 horas (útil para monitoreo en tiempo real y detección temprana de anomalías).';


--
-- TOC entry 312 (class 1259 OID 16955)
-- Name: v_statement_payment_history; Type: VIEW; Schema: public; Owner: credinet_user
--

CREATE VIEW public.v_statement_payment_history AS
 SELECT asp.id AS payment_id,
    asp.statement_id,
    aps.statement_number,
    concat(u_assoc.first_name, ' ', u_assoc.last_name) AS associate_name,
    cp.cut_number,
    cp.period_start_date,
    cp.period_end_date,
    asp.payment_amount,
    asp.payment_date,
    pm.name AS payment_method,
    asp.payment_reference,
    asp.notes,
    aps.total_to_credicuenta,
    aps.commission_earned,
    aps.late_fee_amount,
    (aps.total_to_credicuenta + aps.late_fee_amount) AS total_owed,
    aps.paid_amount AS total_paid_to_date,
    ((aps.total_to_credicuenta + aps.late_fee_amount) - aps.paid_amount) AS remaining_balance,
    ss.name AS statement_status,
    concat(u_reg.first_name, ' ', u_reg.last_name) AS registered_by_name,
    asp.created_at AS payment_registered_at
   FROM ((((((public.associate_statement_payments asp
     JOIN public.associate_payment_statements aps ON ((asp.statement_id = aps.id)))
     JOIN public.users u_assoc ON ((aps.user_id = u_assoc.id)))
     JOIN public.cut_periods cp ON ((aps.cut_period_id = cp.id)))
     JOIN public.payment_methods pm ON ((asp.payment_method_id = pm.id)))
     JOIN public.statement_statuses ss ON ((aps.status_id = ss.id)))
     JOIN public.users u_reg ON ((asp.registered_by = u_reg.id)))
  ORDER BY asp.payment_date DESC, asp.id DESC;


ALTER TABLE public.v_statement_payment_history OWNER TO credinet_user;

--
-- TOC entry 3576 (class 2604 OID 16960)
-- Name: addresses id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.addresses ALTER COLUMN id SET DEFAULT nextval('public.addresses_id_seq'::regclass);


--
-- TOC entry 3579 (class 2604 OID 16961)
-- Name: agreement_items id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreement_items ALTER COLUMN id SET DEFAULT nextval('public.agreement_items_id_seq'::regclass);


--
-- TOC entry 3581 (class 2604 OID 16962)
-- Name: agreement_payments id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreement_payments ALTER COLUMN id SET DEFAULT nextval('public.agreement_payments_id_seq'::regclass);


--
-- TOC entry 3585 (class 2604 OID 16963)
-- Name: agreements id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreements ALTER COLUMN id SET DEFAULT nextval('public.agreements_id_seq'::regclass);


--
-- TOC entry 3589 (class 2604 OID 16964)
-- Name: associate_accumulated_balances id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_accumulated_balances ALTER COLUMN id SET DEFAULT nextval('public.associate_accumulated_balances_id_seq'::regclass);


--
-- TOC entry 3593 (class 2604 OID 16965)
-- Name: associate_debt_breakdown id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_breakdown ALTER COLUMN id SET DEFAULT nextval('public.associate_debt_breakdown_id_seq'::regclass);


--
-- TOC entry 3597 (class 2604 OID 16966)
-- Name: associate_debt_payments id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_payments ALTER COLUMN id SET DEFAULT nextval('public.associate_debt_payments_id_seq'::regclass);


--
-- TOC entry 3601 (class 2604 OID 16967)
-- Name: associate_level_history id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_level_history ALTER COLUMN id SET DEFAULT nextval('public.associate_level_history_id_seq'::regclass);


--
-- TOC entry 3603 (class 2604 OID 16968)
-- Name: associate_levels id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_levels ALTER COLUMN id SET DEFAULT nextval('public.associate_levels_id_seq'::regclass);


--
-- TOC entry 3609 (class 2604 OID 16969)
-- Name: associate_payment_statements id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_payment_statements ALTER COLUMN id SET DEFAULT nextval('public.associate_payment_statements_id_seq'::regclass);


--
-- TOC entry 3616 (class 2604 OID 16970)
-- Name: associate_profiles id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_profiles ALTER COLUMN id SET DEFAULT nextval('public.associate_profiles_id_seq'::regclass);


--
-- TOC entry 3629 (class 2604 OID 16971)
-- Name: associate_statement_payments id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_statement_payments ALTER COLUMN id SET DEFAULT nextval('public.associate_statement_payments_id_seq'::regclass);


--
-- TOC entry 3632 (class 2604 OID 16972)
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- TOC entry 3634 (class 2604 OID 16973)
-- Name: audit_session_log id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.audit_session_log ALTER COLUMN id SET DEFAULT nextval('public.audit_session_log_id_seq'::regclass);


--
-- TOC entry 3637 (class 2604 OID 16974)
-- Name: beneficiaries id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.beneficiaries ALTER COLUMN id SET DEFAULT nextval('public.beneficiaries_id_seq'::regclass);


--
-- TOC entry 3640 (class 2604 OID 16975)
-- Name: client_documents id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.client_documents ALTER COLUMN id SET DEFAULT nextval('public.client_documents_id_seq'::regclass);


--
-- TOC entry 3644 (class 2604 OID 16976)
-- Name: config_types id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.config_types ALTER COLUMN id SET DEFAULT nextval('public.config_types_id_seq'::regclass);


--
-- TOC entry 3647 (class 2604 OID 16977)
-- Name: contract_statuses id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.contract_statuses ALTER COLUMN id SET DEFAULT nextval('public.contract_statuses_id_seq'::regclass);


--
-- TOC entry 3653 (class 2604 OID 16978)
-- Name: contracts id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.contracts ALTER COLUMN id SET DEFAULT nextval('public.contracts_id_seq'::regclass);


--
-- TOC entry 3656 (class 2604 OID 16979)
-- Name: cut_period_statuses id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.cut_period_statuses ALTER COLUMN id SET DEFAULT nextval('public.cut_period_statuses_id_seq'::regclass);


--
-- TOC entry 3662 (class 2604 OID 16980)
-- Name: cut_periods id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.cut_periods ALTER COLUMN id SET DEFAULT nextval('public.cut_periods_id_seq'::regclass);


--
-- TOC entry 3668 (class 2604 OID 16981)
-- Name: defaulted_client_reports id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.defaulted_client_reports ALTER COLUMN id SET DEFAULT nextval('public.defaulted_client_reports_id_seq'::regclass);


--
-- TOC entry 3673 (class 2604 OID 16982)
-- Name: document_statuses id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.document_statuses ALTER COLUMN id SET DEFAULT nextval('public.document_statuses_id_seq'::regclass);


--
-- TOC entry 3677 (class 2604 OID 16983)
-- Name: document_types id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.document_types ALTER COLUMN id SET DEFAULT nextval('public.document_types_id_seq'::regclass);


--
-- TOC entry 3681 (class 2604 OID 16984)
-- Name: guarantors id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.guarantors ALTER COLUMN id SET DEFAULT nextval('public.guarantors_id_seq'::regclass);


--
-- TOC entry 3684 (class 2604 OID 16985)
-- Name: legacy_payment_table id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.legacy_payment_table ALTER COLUMN id SET DEFAULT nextval('public.legacy_payment_table_id_seq'::regclass);


--
-- TOC entry 3695 (class 2604 OID 16986)
-- Name: level_change_types id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.level_change_types ALTER COLUMN id SET DEFAULT nextval('public.level_change_types_id_seq'::regclass);


--
-- TOC entry 3700 (class 2604 OID 16987)
-- Name: loan_renewals id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loan_renewals ALTER COLUMN id SET DEFAULT nextval('public.loan_renewals_id_seq'::regclass);


--
-- TOC entry 3702 (class 2604 OID 16988)
-- Name: loan_statuses id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loan_statuses ALTER COLUMN id SET DEFAULT nextval('public.loan_statuses_id_seq'::regclass);


--
-- TOC entry 3707 (class 2604 OID 16989)
-- Name: loans id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loans ALTER COLUMN id SET DEFAULT nextval('public.loans_id_seq'::regclass);


--
-- TOC entry 3711 (class 2604 OID 16990)
-- Name: payment_methods id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_methods ALTER COLUMN id SET DEFAULT nextval('public.payment_methods_id_seq'::regclass);


--
-- TOC entry 3717 (class 2604 OID 16991)
-- Name: payment_status_history id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_status_history ALTER COLUMN id SET DEFAULT nextval('public.payment_status_history_id_seq'::regclass);


--
-- TOC entry 3719 (class 2604 OID 16992)
-- Name: payment_statuses id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_statuses ALTER COLUMN id SET DEFAULT nextval('public.payment_statuses_id_seq'::regclass);


--
-- TOC entry 3725 (class 2604 OID 16993)
-- Name: payments id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payments ALTER COLUMN id SET DEFAULT nextval('public.payments_id_seq'::regclass);


--
-- TOC entry 3732 (class 2604 OID 16994)
-- Name: rate_profile_reference_table id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.rate_profile_reference_table ALTER COLUMN id SET DEFAULT nextval('public.rate_profile_reference_table_id_seq'::regclass);


--
-- TOC entry 3734 (class 2604 OID 16995)
-- Name: rate_profiles id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.rate_profiles ALTER COLUMN id SET DEFAULT nextval('public.rate_profiles_id_seq'::regclass);


--
-- TOC entry 3740 (class 2604 OID 16996)
-- Name: relationships id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.relationships ALTER COLUMN id SET DEFAULT nextval('public.relationships_id_seq'::regclass);


--
-- TOC entry 3744 (class 2604 OID 16997)
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- TOC entry 3746 (class 2604 OID 16998)
-- Name: statement_statuses id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.statement_statuses ALTER COLUMN id SET DEFAULT nextval('public.statement_statuses_id_seq'::regclass);


--
-- TOC entry 3751 (class 2604 OID 16999)
-- Name: system_configurations id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.system_configurations ALTER COLUMN id SET DEFAULT nextval('public.system_configurations_id_seq'::regclass);


--
-- TOC entry 3755 (class 2604 OID 17000)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 4333 (class 0 OID 16435)
-- Dependencies: 214
-- Data for Name: addresses; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.addresses (id, user_id, street, external_number, internal_number, colony, municipality, state, zip_code, created_at, updated_at) FROM stdin;
2	3	Lopez Mateos	2403	\N	Villa Juárez	Chihuahua	Chihuahua	31064	2026-01-20 06:39:09.417188+00	2026-01-20 06:39:09.417188+00
3	4	Calle López Mateos	2403	\N	Villa Juárez	Chihuahua	Chihuahua	31064	2026-01-21 08:05:35.182747+00	2026-01-21 08:05:35.182747+00
\.


--
-- TOC entry 4335 (class 0 OID 16443)
-- Dependencies: 216
-- Data for Name: agreement_items; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.agreement_items (id, agreement_id, loan_id, client_user_id, debt_amount, debt_type, description, created_at) FROM stdin;
\.


--
-- TOC entry 4337 (class 0 OID 16452)
-- Dependencies: 218
-- Data for Name: agreement_payments; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.agreement_payments (id, agreement_id, payment_number, payment_amount, payment_due_date, payment_date, payment_method_id, payment_reference, status, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4339 (class 0 OID 16461)
-- Dependencies: 220
-- Data for Name: agreements; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.agreements (id, associate_profile_id, agreement_number, agreement_date, total_debt_amount, payment_plan_months, monthly_payment_amount, status, start_date, end_date, created_by, approved_by, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4341 (class 0 OID 16473)
-- Dependencies: 222
-- Data for Name: associate_accumulated_balances; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.associate_accumulated_balances (id, user_id, cut_period_id, accumulated_debt, debt_details, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4343 (class 0 OID 16482)
-- Dependencies: 224
-- Data for Name: associate_debt_breakdown; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.associate_debt_breakdown (id, associate_profile_id, cut_period_id, debt_type, loan_id, client_user_id, amount, description, is_liquidated, liquidation_date, liquidation_notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4345 (class 0 OID 16493)
-- Dependencies: 226
-- Data for Name: associate_debt_payments; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.associate_debt_payments (id, associate_profile_id, payment_amount, payment_date, payment_method_id, payment_reference, registered_by, applied_breakdown_items, notes, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4347 (class 0 OID 16504)
-- Dependencies: 228
-- Data for Name: associate_level_history; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.associate_level_history (id, associate_profile_id, old_level_id, new_level_id, reason, change_type_id, created_at) FROM stdin;
\.


--
-- TOC entry 4349 (class 0 OID 16511)
-- Dependencies: 230
-- Data for Name: associate_levels; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.associate_levels (id, name, max_loan_amount, credit_limit, description, min_clients, min_collection_rate, created_at, updated_at) FROM stdin;
1	Bronce	25000.00	25000.00	\N	0	0.00	2025-10-31 01:12:22.074569+00	2025-10-31 01:12:22.074569+00
2	Plata	300000.00	300000.00	\N	0	0.00	2025-10-31 01:12:22.074569+00	2025-10-31 01:12:22.074569+00
3	Oro	600000.00	600000.00	\N	0	0.00	2025-10-31 01:12:22.074569+00	2025-10-31 01:12:22.074569+00
4	Platino	900000.00	900000.00	\N	0	0.00	2025-10-31 01:12:22.074569+00	2025-10-31 01:12:22.074569+00
5	Diamante	5000000.00	5000000.00	\N	0	0.00	2025-10-31 01:12:22.074569+00	2025-10-31 01:12:22.074569+00
\.


--
-- TOC entry 4351 (class 0 OID 16522)
-- Dependencies: 232
-- Data for Name: associate_payment_statements; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.associate_payment_statements (id, cut_period_id, user_id, statement_number, total_payments_count, total_amount_collected, commission_rate_applied, status_id, generated_date, sent_date, due_date, paid_date, paid_amount, payment_method_id, payment_reference, late_fee_amount, late_fee_applied, created_at, updated_at, total_to_credicuenta, commission_earned) FROM stdin;
2	49	4	ST-Jan23-2026-0004	1	1255.00	12.75	7	2026-01-23	\N	2026-01-22	\N	95.00	\N	\N	0.00	f	2026-01-23 06:02:45.669652+00	2026-01-23 06:06:26.869962+00	1095.00	160.00
\.


--
-- TOC entry 4353 (class 0 OID 16532)
-- Dependencies: 234
-- Data for Name: associate_profiles; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.associate_profiles (id, user_id, level_id, contact_person, contact_email, default_commission_rate, active, consecutive_full_credit_periods, consecutive_on_time_payments, clients_in_agreement, last_level_evaluation_date, pending_payments_total, credit_limit, credit_last_updated, consolidated_debt, created_at, updated_at) FROM stdin;
2	4	2	\N	\N	5.00	t	0	0	0	\N	40062.48	300000.00	2026-01-23 06:20:21.516237+00	0.00	2026-01-21 08:05:34.979937+00	2026-01-23 06:20:21.516237+00
\.


--
-- TOC entry 4355 (class 0 OID 16552)
-- Dependencies: 236
-- Data for Name: associate_statement_payments; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.associate_statement_payments (id, statement_id, payment_amount, payment_date, payment_method_id, payment_reference, registered_by, notes, created_at, updated_at) FROM stdin;
1	2	95.00	2026-01-23	1	\N	2	\N	2026-01-23 06:06:26.869962+00	2026-01-23 06:06:26.869962+00
\.


--
-- TOC entry 4357 (class 0 OID 16562)
-- Dependencies: 238
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.audit_log (id, table_name, record_id, operation, old_data, new_data, changed_by, changed_at, ip_address, user_agent) FROM stdin;
1	users	3	INSERT	\N	{"id": 3, "curp": "FACJ950525HCHRRR04", "email": "francojair81@gmail.com", "active": true, "username": "jairnoel.franco", "last_name": "Franco Cruz", "birth_date": "1995-05-25", "created_at": "2026-01-20T06:39:09.119045+00:00", "first_name": "Jair Noel", "updated_at": "2026-01-20T06:39:09.119045+00:00", "phone_number": "6143618298", "password_hash": "$2b$12$tE8axGk0UCn8QgdZiRKR0ueHhURSuUOLNJv3zkjhjBk1zfTvxAsmW", "profile_picture_url": null}	\N	2026-01-20 06:39:09.119045+00	\N	\N
2	users	4	INSERT	\N	{"id": 4, "curp": "CUEM640815MCHRSR02", "email": "maria.c@credinet.temp", "active": true, "username": "maria.cruz", "last_name": "Cruz Escobedo", "birth_date": "1964-08-15", "created_at": "2026-01-21T08:05:34.979937+00:00", "first_name": "Maria", "updated_at": "2026-01-21T08:05:34.979937+00:00", "phone_number": "6142772794", "password_hash": "$2b$12$KsBaPRvGl4PrCFo4PQUfzOPhfvKTjUUPmYb0Oyoo/Z5E9gUmR/G.q", "profile_picture_url": null}	\N	2026-01-21 08:05:34.979937+00	\N	\N
3	loans	1	INSERT	\N	{"id": 1, "notes": "prestamo de prueba 1, producción", "amount": 10000.00, "user_id": 3, "status_id": 1, "created_at": "2026-01-22T22:03:28.860485+00:00", "updated_at": "2026-01-22T22:03:28.860485+00:00", "approved_at": null, "approved_by": null, "contract_id": null, "rejected_at": null, "rejected_by": null, "profile_code": "legacy", "term_biweeks": 12, "interest_rate": 4.22, "total_payment": 15060.00, "total_interest": 5060.00, "commission_rate": 12.75, "biweekly_payment": 1255.00, "rejection_reason": null, "total_commission": 1920.00, "associate_payment": 1095.00, "associate_user_id": 4, "commission_per_payment": 160.00}	\N	2026-01-22 22:03:28.860485+00	\N	\N
4	loans	1	UPDATE	{"id": 1, "notes": "prestamo de prueba 1, producción", "amount": 10000.00, "user_id": 3, "status_id": 1, "created_at": "2026-01-22T22:03:28.860485+00:00", "updated_at": "2026-01-22T22:03:28.860485+00:00", "approved_at": null, "approved_by": null, "contract_id": null, "rejected_at": null, "rejected_by": null, "profile_code": "legacy", "term_biweeks": 12, "interest_rate": 4.22, "total_payment": 15060.00, "total_interest": 5060.00, "commission_rate": 12.75, "biweekly_payment": 1255.00, "rejection_reason": null, "total_commission": 1920.00, "associate_payment": 1095.00, "associate_user_id": 4, "commission_per_payment": 160.00}	{"id": 1, "notes": "prestamo de prueba 1, producción\\n[APROBACIÓN] Prueba, Ficticio", "amount": 10000.00, "user_id": 3, "status_id": 2, "created_at": "2026-01-22T22:03:28.860485+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "approved_at": "2026-01-22T22:04:36.524118+00:00", "approved_by": 2, "contract_id": null, "rejected_at": null, "rejected_by": null, "profile_code": "legacy", "term_biweeks": 12, "interest_rate": 4.22, "total_payment": 15060.00, "total_interest": 5060.00, "commission_rate": 12.75, "biweekly_payment": 1255.00, "rejection_reason": null, "total_commission": 1920.00, "associate_payment": 1095.00, "associate_user_id": 4, "commission_per_payment": 160.00}	\N	2026-01-22 22:04:36.517843+00	\N	\N
5	payments	1	INSERT	\N	{"id": 1, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 49, "marking_notes": null, "payment_number": 1, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-01-31", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 1095.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
6	payments	2	INSERT	\N	{"id": 2, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 50, "marking_notes": null, "payment_number": 2, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-02-15", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 2190.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
7	payments	3	INSERT	\N	{"id": 3, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 51, "marking_notes": null, "payment_number": 3, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-02-28", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 3285.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
8	payments	4	INSERT	\N	{"id": 4, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 52, "marking_notes": null, "payment_number": 4, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-03-15", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 4380.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
9	payments	5	INSERT	\N	{"id": 5, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 53, "marking_notes": null, "payment_number": 5, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-03-31", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 5475.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
10	payments	6	INSERT	\N	{"id": 6, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 54, "marking_notes": null, "payment_number": 6, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-04-15", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 6570.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
11	payments	7	INSERT	\N	{"id": 7, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 55, "marking_notes": null, "payment_number": 7, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-04-30", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 7665.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
12	payments	8	INSERT	\N	{"id": 8, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 56, "marking_notes": null, "payment_number": 8, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-05-15", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 8760.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
13	payments	9	INSERT	\N	{"id": 9, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 57, "marking_notes": null, "payment_number": 9, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-05-31", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 9855.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
14	payments	10	INSERT	\N	{"id": 10, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 58, "marking_notes": null, "payment_number": 10, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-06-15", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 10950.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
15	payments	11	INSERT	\N	{"id": 11, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 59, "marking_notes": null, "payment_number": 11, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-06-30", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 12045.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
16	payments	12	INSERT	\N	{"id": 12, "notes": "Generado automáticamente - Perfil: legacy", "is_late": false, "loan_id": 1, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-22T22:04:36.517843+00:00", "updated_at": "2026-01-22T22:04:36.517843+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 60, "marking_notes": null, "payment_number": 12, "expected_amount": 1255.00, "interest_amount": 421.67, "payment_due_date": "2026-07-15", "principal_amount": 833.33, "associate_payment": 1095.00, "balance_remaining": null, "commission_amount": 160.00, "total_associate_payment": 13140.00, "cumulative_associate_paid": 13140.00, "associate_balance_remaining": null}	\N	2026-01-22 22:04:36.517843+00	\N	\N
17	cut_periods	48	UPDATE	{"id": 48, "cut_code": "Jan08-2026", "closed_by": null, "status_id": 4, "created_at": "2025-11-06T08:12:35.284442+00:00", "created_by": 1, "cut_number": 48, "updated_at": "2026-01-11T15:53:45.080887+00:00", "period_end_date": "2026-01-07", "total_commission": 0.00, "period_start_date": "2025-12-23", "total_payments_expected": 0.00, "total_payments_received": 0.00}	{"id": 48, "cut_code": "Jan08-2026", "closed_by": null, "status_id": 6, "created_at": "2025-11-06T08:12:35.284442+00:00", "created_by": 1, "cut_number": 48, "updated_at": "2026-01-23T00:05:00.008706+00:00", "period_end_date": "2026-01-07", "total_commission": 0.00, "period_start_date": "2025-12-23", "total_payments_expected": 0.00, "total_payments_received": 0.00}	\N	2026-01-23 00:05:00.008706+00	\N	\N
18	cut_periods	49	UPDATE	{"id": 49, "cut_code": "Jan23-2026", "closed_by": null, "status_id": 1, "created_at": "2025-11-06T08:12:35.285443+00:00", "created_by": 1, "cut_number": 49, "updated_at": "2026-01-11T15:53:45.080887+00:00", "period_end_date": "2026-01-22", "total_commission": 0.00, "period_start_date": "2026-01-08", "total_payments_expected": 0.00, "total_payments_received": 0.00}	{"id": 49, "cut_code": "Jan23-2026", "closed_by": null, "status_id": 3, "created_at": "2025-11-06T08:12:35.285443+00:00", "created_by": 1, "cut_number": 49, "updated_at": "2026-01-23T00:05:00.008706+00:00", "period_end_date": "2026-01-22", "total_commission": 0.00, "period_start_date": "2026-01-08", "total_payments_expected": 0.00, "total_payments_received": 0.00}	\N	2026-01-23 00:05:00.008706+00	\N	\N
19	cut_periods	49	UPDATE	{"id": 49, "cut_code": "Jan23-2026", "closed_by": null, "status_id": 3, "created_at": "2025-11-06T08:12:35.285443+00:00", "created_by": 1, "cut_number": 49, "updated_at": "2026-01-23T00:05:00.008706+00:00", "period_end_date": "2026-01-22", "total_commission": 0.00, "period_start_date": "2026-01-08", "total_payments_expected": 0.00, "total_payments_received": 0.00}	{"id": 49, "cut_code": "Jan23-2026", "closed_by": null, "status_id": 4, "created_at": "2025-11-06T08:12:35.285443+00:00", "created_by": 1, "cut_number": 49, "updated_at": "2026-01-23T00:05:00.008706+00:00", "period_end_date": "2026-01-22", "total_commission": 0.00, "period_start_date": "2026-01-08", "total_payments_expected": 0.00, "total_payments_received": 0.00}	\N	2026-01-23 00:05:00.008706+00	\N	\N
20	cut_periods	48	UPDATE	{"id": 48, "cut_code": "Jan08-2026", "closed_by": null, "status_id": 6, "created_at": "2025-11-06T08:12:35.284442+00:00", "created_by": 1, "cut_number": 48, "updated_at": "2026-01-23T00:05:00.008706+00:00", "period_end_date": "2026-01-07", "total_commission": 0.00, "period_start_date": "2025-12-23", "total_payments_expected": 0.00, "total_payments_received": 0.00}	{"id": 48, "cut_code": "Jan08-2026", "closed_by": null, "status_id": 4, "created_at": "2025-11-06T08:12:35.284442+00:00", "created_by": 1, "cut_number": 48, "updated_at": "2026-01-23T05:56:15.484752+00:00", "period_end_date": "2026-01-07", "total_commission": 0.00, "period_start_date": "2025-12-23", "total_payments_expected": 0.00, "total_payments_received": 0.00}	\N	2026-01-23 05:56:15.484752+00	\N	\N
21	cut_periods	49	UPDATE	{"id": 49, "cut_code": "Jan23-2026", "closed_by": null, "status_id": 4, "created_at": "2025-11-06T08:12:35.285443+00:00", "created_by": 1, "cut_number": 49, "updated_at": "2026-01-23T00:05:00.008706+00:00", "period_end_date": "2026-01-22", "total_commission": 0.00, "period_start_date": "2026-01-08", "total_payments_expected": 0.00, "total_payments_received": 0.00}	{"id": 49, "cut_code": "Jan23-2026", "closed_by": null, "status_id": 1, "created_at": "2025-11-06T08:12:35.285443+00:00", "created_by": 1, "cut_number": 49, "updated_at": "2026-01-23T05:56:15.484752+00:00", "period_end_date": "2026-01-22", "total_commission": 0.00, "period_start_date": "2026-01-08", "total_payments_expected": 0.00, "total_payments_received": 0.00}	\N	2026-01-23 05:56:15.484752+00	\N	\N
22	cut_periods	48	UPDATE	{"id": 48, "cut_code": "Jan08-2026", "closed_by": null, "status_id": 4, "created_at": "2025-11-06T08:12:35.284442+00:00", "created_by": 1, "cut_number": 48, "updated_at": "2026-01-23T05:56:15.484752+00:00", "period_end_date": "2026-01-07", "total_commission": 0.00, "period_start_date": "2025-12-23", "total_payments_expected": 0.00, "total_payments_received": 0.00}	{"id": 48, "cut_code": "Jan08-2026", "closed_by": null, "status_id": 6, "created_at": "2025-11-06T08:12:35.284442+00:00", "created_by": 1, "cut_number": 48, "updated_at": "2026-01-23T06:02:45.669652+00:00", "period_end_date": "2026-01-07", "total_commission": 0.00, "period_start_date": "2025-12-23", "total_payments_expected": 0.00, "total_payments_received": 0.00}	\N	2026-01-23 06:02:45.669652+00	\N	\N
23	cut_periods	49	UPDATE	{"id": 49, "cut_code": "Jan23-2026", "closed_by": null, "status_id": 1, "created_at": "2025-11-06T08:12:35.285443+00:00", "created_by": 1, "cut_number": 49, "updated_at": "2026-01-23T05:56:15.484752+00:00", "period_end_date": "2026-01-22", "total_commission": 0.00, "period_start_date": "2026-01-08", "total_payments_expected": 0.00, "total_payments_received": 0.00}	{"id": 49, "cut_code": "Jan23-2026", "closed_by": null, "status_id": 3, "created_at": "2025-11-06T08:12:35.285443+00:00", "created_by": 1, "cut_number": 49, "updated_at": "2026-01-23T06:02:45.669652+00:00", "period_end_date": "2026-01-22", "total_commission": 0.00, "period_start_date": "2026-01-08", "total_payments_expected": 0.00, "total_payments_received": 0.00}	\N	2026-01-23 06:02:45.669652+00	\N	\N
24	cut_periods	49	UPDATE	{"id": 49, "cut_code": "Jan23-2026", "closed_by": null, "status_id": 3, "created_at": "2025-11-06T08:12:35.285443+00:00", "created_by": 1, "cut_number": 49, "updated_at": "2026-01-23T06:02:45.669652+00:00", "period_end_date": "2026-01-22", "total_commission": 0.00, "period_start_date": "2026-01-08", "total_payments_expected": 0.00, "total_payments_received": 0.00}	{"id": 49, "cut_code": "Jan23-2026", "closed_by": null, "status_id": 4, "created_at": "2025-11-06T08:12:35.285443+00:00", "created_by": 1, "cut_number": 49, "updated_at": "2026-01-23T06:02:45.669652+00:00", "period_end_date": "2026-01-22", "total_commission": 0.00, "period_start_date": "2026-01-08", "total_payments_expected": 0.00, "total_payments_received": 0.00}	\N	2026-01-23 06:02:45.669652+00	\N	\N
25	cut_periods	48	UPDATE	{"id": 48, "cut_code": "Jan08-2026", "closed_by": null, "status_id": 6, "created_at": "2025-11-06T08:12:35.284442+00:00", "created_by": 1, "cut_number": 48, "updated_at": "2026-01-23T06:02:45.669652+00:00", "period_end_date": "2026-01-07", "total_commission": 0.00, "period_start_date": "2025-12-23", "total_payments_expected": 0.00, "total_payments_received": 0.00}	{"id": 48, "cut_code": "Jan08-2026", "closed_by": null, "status_id": 5, "created_at": "2025-11-06T08:12:35.284442+00:00", "created_by": 1, "cut_number": 48, "updated_at": "2026-01-23T06:13:57.570603+00:00", "period_end_date": "2026-01-07", "total_commission": 0.00, "period_start_date": "2025-12-23", "total_payments_expected": 0.00, "total_payments_received": 0.00}	\N	2026-01-23 06:13:57.570603+00	\N	\N
26	loans	2	INSERT	\N	{"id": 2, "notes": "prestamo de prueba 2 con perfil recomendado", "amount": 15000.00, "user_id": 3, "status_id": 1, "created_at": "2026-01-23T06:15:47.472576+00:00", "updated_at": "2026-01-23T06:15:47.472576+00:00", "approved_at": null, "approved_by": null, "contract_id": null, "rejected_at": null, "rejected_by": null, "profile_code": "standard", "term_biweeks": 15, "interest_rate": 4.25, "total_payment": 24562.50, "total_interest": 9562.50, "commission_rate": 1.60, "biweekly_payment": 1637.50, "rejection_reason": null, "total_commission": 3600.00, "associate_payment": 1397.50, "associate_user_id": 4, "commission_per_payment": 240.00}	\N	2026-01-23 06:15:47.472576+00	\N	\N
27	loans	2	UPDATE	{"id": 2, "notes": "prestamo de prueba 2 con perfil recomendado", "amount": 15000.00, "user_id": 3, "status_id": 1, "created_at": "2026-01-23T06:15:47.472576+00:00", "updated_at": "2026-01-23T06:15:47.472576+00:00", "approved_at": null, "approved_by": null, "contract_id": null, "rejected_at": null, "rejected_by": null, "profile_code": "standard", "term_biweeks": 15, "interest_rate": 4.25, "total_payment": 24562.50, "total_interest": 9562.50, "commission_rate": 1.60, "biweekly_payment": 1637.50, "rejection_reason": null, "total_commission": 3600.00, "associate_payment": 1397.50, "associate_user_id": 4, "commission_per_payment": 240.00}	{"id": 2, "notes": "prestamo de prueba 2 con perfil recomendado", "amount": 15000.00, "user_id": 3, "status_id": 2, "created_at": "2026-01-23T06:15:47.472576+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "approved_at": "2026-01-23T06:16:42.73649+00:00", "approved_by": 2, "contract_id": null, "rejected_at": null, "rejected_by": null, "profile_code": "standard", "term_biweeks": 15, "interest_rate": 4.25, "total_payment": 24562.50, "total_interest": 9562.50, "commission_rate": 1.60, "biweekly_payment": 1637.50, "rejection_reason": null, "total_commission": 3600.00, "associate_payment": 1397.50, "associate_user_id": 4, "commission_per_payment": 240.00}	\N	2026-01-23 06:16:42.730008+00	\N	\N
28	payments	13	INSERT	\N	{"id": 13, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 50, "marking_notes": null, "payment_number": 1, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-02-15", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 1397.50, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
29	payments	14	INSERT	\N	{"id": 14, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 51, "marking_notes": null, "payment_number": 2, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-02-28", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 2795.00, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
30	payments	15	INSERT	\N	{"id": 15, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 52, "marking_notes": null, "payment_number": 3, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-03-15", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 4192.50, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
31	payments	16	INSERT	\N	{"id": 16, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 53, "marking_notes": null, "payment_number": 4, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-03-31", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 5590.00, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
32	payments	17	INSERT	\N	{"id": 17, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 54, "marking_notes": null, "payment_number": 5, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-04-15", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 6987.50, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
33	payments	18	INSERT	\N	{"id": 18, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 55, "marking_notes": null, "payment_number": 6, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-04-30", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 8385.00, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
34	payments	19	INSERT	\N	{"id": 19, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 56, "marking_notes": null, "payment_number": 7, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-05-15", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 9782.50, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
35	payments	20	INSERT	\N	{"id": 20, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 57, "marking_notes": null, "payment_number": 8, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-05-31", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 11180.00, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
36	payments	21	INSERT	\N	{"id": 21, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 58, "marking_notes": null, "payment_number": 9, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-06-15", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 12577.50, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
37	payments	22	INSERT	\N	{"id": 22, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 59, "marking_notes": null, "payment_number": 10, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-06-30", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 13975.00, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
38	payments	23	INSERT	\N	{"id": 23, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 60, "marking_notes": null, "payment_number": 11, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-07-15", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 15372.50, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
39	payments	24	INSERT	\N	{"id": 24, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 61, "marking_notes": null, "payment_number": 12, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-07-31", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 16770.00, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
40	payments	25	INSERT	\N	{"id": 25, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 62, "marking_notes": null, "payment_number": 13, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-08-15", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 18167.50, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
41	payments	26	INSERT	\N	{"id": 26, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 63, "marking_notes": null, "payment_number": 14, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-08-31", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 19565.00, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
42	payments	27	INSERT	\N	{"id": 27, "notes": "Generado automáticamente - Perfil: standard", "is_late": false, "loan_id": 2, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:16:42.730008+00:00", "updated_at": "2026-01-23T06:16:42.730008+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 64, "marking_notes": null, "payment_number": 15, "expected_amount": 1637.50, "interest_amount": 637.50, "payment_due_date": "2026-09-15", "principal_amount": 1000.00, "associate_payment": 1397.50, "balance_remaining": null, "commission_amount": 240.00, "total_associate_payment": 20962.50, "cumulative_associate_paid": 20962.50, "associate_balance_remaining": null}	\N	2026-01-23 06:16:42.730008+00	\N	\N
43	loans	3	INSERT	\N	{"id": 3, "notes": "prestamo 3 de prueba con perfil personalizado, tasas personalizadas, 5% iinteres quincenal, 1.8 comisión para el asociado, generoso a 6 quincenas", "amount": 5000.00, "user_id": 3, "status_id": 1, "created_at": "2026-01-23T06:20:00.297814+00:00", "updated_at": "2026-01-23T06:20:00.297814+00:00", "approved_at": null, "approved_by": null, "contract_id": null, "rejected_at": null, "rejected_by": null, "profile_code": "custom", "term_biweeks": 6, "interest_rate": 5.00, "total_payment": 6500.00, "total_interest": 1500.00, "commission_rate": 1.80, "biweekly_payment": 1083.33, "rejection_reason": null, "total_commission": 540.00, "associate_payment": 993.33, "associate_user_id": 4, "commission_per_payment": 90.00}	\N	2026-01-23 06:20:00.297814+00	\N	\N
44	loans	3	UPDATE	{"id": 3, "notes": "prestamo 3 de prueba con perfil personalizado, tasas personalizadas, 5% iinteres quincenal, 1.8 comisión para el asociado, generoso a 6 quincenas", "amount": 5000.00, "user_id": 3, "status_id": 1, "created_at": "2026-01-23T06:20:00.297814+00:00", "updated_at": "2026-01-23T06:20:00.297814+00:00", "approved_at": null, "approved_by": null, "contract_id": null, "rejected_at": null, "rejected_by": null, "profile_code": "custom", "term_biweeks": 6, "interest_rate": 5.00, "total_payment": 6500.00, "total_interest": 1500.00, "commission_rate": 1.80, "biweekly_payment": 1083.33, "rejection_reason": null, "total_commission": 540.00, "associate_payment": 993.33, "associate_user_id": 4, "commission_per_payment": 90.00}	{"id": 3, "notes": "prestamo 3 de prueba con perfil personalizado, tasas personalizadas, 5% iinteres quincenal, 1.8 comisión para el asociado, generoso a 6 quincenas", "amount": 5000.00, "user_id": 3, "status_id": 2, "created_at": "2026-01-23T06:20:00.297814+00:00", "updated_at": "2026-01-23T06:20:21.516237+00:00", "approved_at": "2026-01-23T06:20:21.520289+00:00", "approved_by": 2, "contract_id": null, "rejected_at": null, "rejected_by": null, "profile_code": "custom", "term_biweeks": 6, "interest_rate": 5.00, "total_payment": 6500.00, "total_interest": 1500.00, "commission_rate": 1.80, "biweekly_payment": 1083.33, "rejection_reason": null, "total_commission": 540.00, "associate_payment": 993.33, "associate_user_id": 4, "commission_per_payment": 90.00}	\N	2026-01-23 06:20:21.516237+00	\N	\N
45	payments	28	INSERT	\N	{"id": 28, "notes": "Generado automáticamente - Perfil: custom", "is_late": false, "loan_id": 3, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:20:21.516237+00:00", "updated_at": "2026-01-23T06:20:21.516237+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 50, "marking_notes": null, "payment_number": 1, "expected_amount": 1083.33, "interest_amount": 250.00, "payment_due_date": "2026-02-15", "principal_amount": 833.33, "associate_payment": 993.33, "balance_remaining": null, "commission_amount": 90.00, "total_associate_payment": 5959.98, "cumulative_associate_paid": 993.33, "associate_balance_remaining": null}	\N	2026-01-23 06:20:21.516237+00	\N	\N
46	payments	29	INSERT	\N	{"id": 29, "notes": "Generado automáticamente - Perfil: custom", "is_late": false, "loan_id": 3, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:20:21.516237+00:00", "updated_at": "2026-01-23T06:20:21.516237+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 51, "marking_notes": null, "payment_number": 2, "expected_amount": 1083.33, "interest_amount": 250.00, "payment_due_date": "2026-02-28", "principal_amount": 833.33, "associate_payment": 993.33, "balance_remaining": null, "commission_amount": 90.00, "total_associate_payment": 5959.98, "cumulative_associate_paid": 1986.66, "associate_balance_remaining": null}	\N	2026-01-23 06:20:21.516237+00	\N	\N
47	payments	30	INSERT	\N	{"id": 30, "notes": "Generado automáticamente - Perfil: custom", "is_late": false, "loan_id": 3, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:20:21.516237+00:00", "updated_at": "2026-01-23T06:20:21.516237+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 52, "marking_notes": null, "payment_number": 3, "expected_amount": 1083.33, "interest_amount": 250.00, "payment_due_date": "2026-03-15", "principal_amount": 833.33, "associate_payment": 993.33, "balance_remaining": null, "commission_amount": 90.00, "total_associate_payment": 5959.98, "cumulative_associate_paid": 2979.99, "associate_balance_remaining": null}	\N	2026-01-23 06:20:21.516237+00	\N	\N
48	payments	31	INSERT	\N	{"id": 31, "notes": "Generado automáticamente - Perfil: custom", "is_late": false, "loan_id": 3, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:20:21.516237+00:00", "updated_at": "2026-01-23T06:20:21.516237+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 53, "marking_notes": null, "payment_number": 4, "expected_amount": 1083.33, "interest_amount": 250.00, "payment_due_date": "2026-03-31", "principal_amount": 833.33, "associate_payment": 993.33, "balance_remaining": null, "commission_amount": 90.00, "total_associate_payment": 5959.98, "cumulative_associate_paid": 3973.32, "associate_balance_remaining": null}	\N	2026-01-23 06:20:21.516237+00	\N	\N
49	payments	32	INSERT	\N	{"id": 32, "notes": "Generado automáticamente - Perfil: custom", "is_late": false, "loan_id": 3, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:20:21.516237+00:00", "updated_at": "2026-01-23T06:20:21.516237+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 54, "marking_notes": null, "payment_number": 5, "expected_amount": 1083.33, "interest_amount": 250.00, "payment_due_date": "2026-04-15", "principal_amount": 833.33, "associate_payment": 993.33, "balance_remaining": null, "commission_amount": 90.00, "total_associate_payment": 5959.98, "cumulative_associate_paid": 4966.65, "associate_balance_remaining": null}	\N	2026-01-23 06:20:21.516237+00	\N	\N
50	payments	33	INSERT	\N	{"id": 33, "notes": "Generado automáticamente - Perfil: custom", "is_late": false, "loan_id": 3, "marked_at": null, "marked_by": null, "status_id": 1, "created_at": "2026-01-23T06:20:21.516237+00:00", "updated_at": "2026-01-23T06:20:21.516237+00:00", "amount_paid": 0.00, "payment_date": null, "cut_period_id": 55, "marking_notes": null, "payment_number": 6, "expected_amount": 1083.33, "interest_amount": 250.00, "payment_due_date": "2026-04-30", "principal_amount": 833.33, "associate_payment": 993.33, "balance_remaining": null, "commission_amount": 90.00, "total_associate_payment": 5959.98, "cumulative_associate_paid": 5959.98, "associate_balance_remaining": null}	\N	2026-01-23 06:20:21.516237+00	\N	\N
\.


--
-- TOC entry 4359 (class 0 OID 16570)
-- Dependencies: 240
-- Data for Name: audit_session_log; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.audit_session_log (id, user_id, session_token, login_at, logout_at, ip_address, user_agent, is_active) FROM stdin;
\.


--
-- TOC entry 4361 (class 0 OID 16585)
-- Dependencies: 242
-- Data for Name: beneficiaries; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.beneficiaries (id, user_id, full_name, relationship, phone_number, created_at, updated_at, relationship_id) FROM stdin;
2	3	Maria Cruz Escobedo	Madre	6142772794	2026-01-20 06:39:09.445968+00	2026-01-20 06:39:09.445968+00	\N
3	4	Jair Noel Franco Cruz	Hijo/a	6414361829	2026-01-21 08:05:35.734945+00	2026-01-21 08:05:35.734945+00	\N
\.


--
-- TOC entry 4363 (class 0 OID 16591)
-- Dependencies: 244
-- Data for Name: client_documents; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.client_documents (id, user_id, document_type_id, file_name, original_file_name, file_path, file_size, mime_type, status_id, upload_date, reviewed_by, reviewed_at, comments, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4365 (class 0 OID 16600)
-- Dependencies: 246
-- Data for Name: config_types; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.config_types (id, name, description, validation_regex, example_value, created_at, updated_at) FROM stdin;
1	STRING	Cadena de texto.	\N	Hola Mundo	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
2	NUMBER	Número entero o decimal.	^-?\\d+(\\.\\d+)?$	123.45	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
3	BOOLEAN	Valor booleano.	^(true|false)$	true	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
4	JSON	Objeto JSON válido.	\N	{"key": "value"}	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
5	URL	URL válida.	^https?://[^\\s]+$	https://ejemplo.com	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
6	EMAIL	Correo electrónico.	^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$	user@example.com	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
7	DATE	Fecha ISO 8601.	^\\d{4}-\\d{2}-\\d{2}$	2025-10-30	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
8	PERCENTAGE	Porcentaje 0-100.	^(100(\\.0+)?|\\d{1,2}(\\.\\d+)?)$	15.5	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
\.


--
-- TOC entry 4367 (class 0 OID 16608)
-- Dependencies: 248
-- Data for Name: contract_statuses; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.contract_statuses (id, name, description, is_active, requires_signature, display_order, created_at, updated_at) FROM stdin;
1	draft	Contrato en borrador.	t	f	1	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
2	pending	Pendiente de firma del cliente.	t	t	2	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
3	signed	Firmado por el cliente.	t	f	3	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
4	active	Contrato activo y vigente.	t	f	4	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
5	completed	Contrato completado, préstamo liquidado.	t	f	5	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
6	cancelled	Contrato cancelado.	t	f	6	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
\.


--
-- TOC entry 4369 (class 0 OID 16619)
-- Dependencies: 250
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.contracts (id, loan_id, file_path, start_date, sign_date, document_number, status_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4371 (class 0 OID 16628)
-- Dependencies: 252
-- Data for Name: cut_period_statuses; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.cut_period_statuses (id, name, description, is_terminal, allows_payments, display_order, created_at, updated_at) FROM stdin;
1	PENDING	Período futuro con pagos pre-asignados de préstamos aprobados.	f	f	1	2025-10-31 01:12:22.080292+00	2025-12-04 08:29:41.841541+00
2	ACTIVE	DEPRECADO - No usar. Período actual del calendario.	f	f	99	2025-10-31 01:12:22.080292+00	2025-12-04 08:29:41.841541+00
3	CUTOFF	BORRADOR - Corte automático ejecutado. Statements en borrador para revisión del admin.	f	f	2	2025-10-31 01:12:22.080292+00	2025-12-04 08:29:41.841541+00
4	COLLECTING	EN COBRO - Cierre manual ejecutado. Statements finalizados, fase de cobro a asociados.	f	f	3	2025-10-31 01:12:22.080292+00	2025-12-04 08:29:41.841541+00
5	CLOSED	Período cerrado y archivado definitivamente. Solo lectura.	t	f	5	2025-10-31 01:12:22.080292+00	2025-12-04 08:29:41.841541+00
6	SETTLING	LIQUIDACIÓN - Período terminado, revisión de deuda pendiente antes del cierre definitivo.	f	f	4	2025-12-04 08:29:41.841541+00	2025-12-04 08:29:41.841541+00
\.


--
-- TOC entry 4373 (class 0 OID 16639)
-- Dependencies: 254
-- Data for Name: cut_periods; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.cut_periods (id, cut_number, period_start_date, period_end_date, status_id, total_payments_expected, total_payments_received, total_commission, created_by, closed_by, created_at, updated_at, cut_code) FROM stdin;
97	97	2028-01-08	2028-01-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jan23-2028
98	98	2028-01-23	2028-02-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Feb08-2028
193	193	2032-01-08	2032-01-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan23-2032
194	194	2032-01-23	2032-02-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb08-2032
195	195	2032-02-08	2032-02-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb23-2032
196	196	2032-02-23	2032-03-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar08-2032
197	197	2032-03-08	2032-03-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar23-2032
198	198	2032-03-23	2032-04-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr08-2032
199	199	2032-04-08	2032-04-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr23-2032
200	200	2032-04-23	2032-05-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May08-2032
201	201	2032-05-08	2032-05-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May23-2032
202	202	2032-05-23	2032-06-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun08-2032
203	203	2032-06-08	2032-06-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun23-2032
204	204	2032-06-23	2032-07-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul08-2032
205	205	2032-07-08	2032-07-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul23-2032
206	206	2032-07-23	2032-08-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug08-2032
207	207	2032-08-08	2032-08-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug23-2032
208	208	2032-08-23	2032-09-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep08-2032
209	209	2032-09-08	2032-09-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep23-2032
210	210	2032-09-23	2032-10-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct08-2032
211	211	2032-10-08	2032-10-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct23-2032
212	212	2032-10-23	2032-11-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov08-2032
213	213	2032-11-08	2032-11-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov23-2032
214	214	2032-11-23	2032-12-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec08-2032
215	215	2032-12-08	2032-12-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec23-2032
216	216	2032-12-23	2033-01-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan08-2033
217	217	2033-01-08	2033-01-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan23-2033
218	218	2033-01-23	2033-02-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb08-2033
219	219	2033-02-08	2033-02-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb23-2033
220	220	2033-02-23	2033-03-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar08-2033
221	221	2033-03-08	2033-03-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar23-2033
222	222	2033-03-23	2033-04-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr08-2033
223	223	2033-04-08	2033-04-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr23-2033
224	224	2033-04-23	2033-05-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May08-2033
225	225	2033-05-08	2033-05-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May23-2033
226	226	2033-05-23	2033-06-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun08-2033
227	227	2033-06-08	2033-06-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun23-2033
228	228	2033-06-23	2033-07-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul08-2033
229	229	2033-07-08	2033-07-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul23-2033
230	230	2033-07-23	2033-08-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug08-2033
231	231	2033-08-08	2033-08-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug23-2033
232	232	2033-08-23	2033-09-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep08-2033
233	233	2033-09-08	2033-09-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep23-2033
234	234	2033-09-23	2033-10-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct08-2033
235	235	2033-10-08	2033-10-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct23-2033
236	236	2033-10-23	2033-11-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov08-2033
237	237	2033-11-08	2033-11-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov23-2033
238	238	2033-11-23	2033-12-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec08-2033
239	239	2033-12-08	2033-12-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec23-2033
240	240	2033-12-23	2034-01-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan08-2034
241	241	2034-01-08	2034-01-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan23-2034
242	242	2034-01-23	2034-02-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb08-2034
243	243	2034-02-08	2034-02-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb23-2034
244	244	2034-02-23	2034-03-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar08-2034
245	245	2034-03-08	2034-03-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar23-2034
246	246	2034-03-23	2034-04-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr08-2034
247	247	2034-04-08	2034-04-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr23-2034
248	248	2034-04-23	2034-05-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May08-2034
249	249	2034-05-08	2034-05-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May23-2034
250	250	2034-05-23	2034-06-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun08-2034
1	1	2024-01-08	2024-01-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.232865+00	2026-01-11 15:53:45.080887+00	Jan23-2024
2	2	2024-01-23	2024-02-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.236375+00	2026-01-11 15:53:45.080887+00	Feb08-2024
3	3	2024-02-08	2024-02-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.237509+00	2026-01-11 15:53:45.080887+00	Feb23-2024
37	37	2025-07-08	2025-07-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.273257+00	2026-01-11 15:53:45.080887+00	Jul23-2025
38	38	2025-07-23	2025-08-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.274299+00	2026-01-11 15:53:45.080887+00	Aug08-2025
39	39	2025-08-08	2025-08-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.275323+00	2026-01-11 15:53:45.080887+00	Aug23-2025
40	40	2025-08-23	2025-09-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.276338+00	2026-01-11 15:53:45.080887+00	Sep08-2025
41	41	2025-09-08	2025-09-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.277349+00	2026-01-11 15:53:45.080887+00	Sep23-2025
42	42	2025-09-23	2025-10-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.278353+00	2026-01-11 15:53:45.080887+00	Oct08-2025
43	43	2025-10-08	2025-10-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.279354+00	2026-01-11 15:53:45.080887+00	Oct23-2025
44	44	2025-10-23	2025-11-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.280379+00	2026-01-11 15:53:45.080887+00	Nov08-2025
45	45	2025-11-08	2025-11-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.281436+00	2026-01-11 15:53:45.080887+00	Nov23-2025
4	4	2024-02-23	2024-03-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.238601+00	2026-01-11 15:53:45.080887+00	Mar08-2024
5	5	2024-03-08	2024-03-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.239673+00	2026-01-11 15:53:45.080887+00	Mar23-2024
6	6	2024-03-23	2024-04-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.240759+00	2026-01-11 15:53:45.080887+00	Apr08-2024
7	7	2024-04-08	2024-04-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.241855+00	2026-01-11 15:53:45.080887+00	Apr23-2024
8	8	2024-04-23	2024-05-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.242878+00	2026-01-11 15:53:45.080887+00	May08-2024
9	9	2024-05-08	2024-05-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.243887+00	2026-01-11 15:53:45.080887+00	May23-2024
46	46	2025-11-23	2025-12-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.282433+00	2026-01-11 15:53:45.080887+00	Dec08-2025
47	47	2025-12-08	2025-12-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.283429+00	2026-01-11 15:53:45.080887+00	Dec23-2025
50	50	2026-01-23	2026-02-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.286442+00	2026-01-11 15:53:45.080887+00	Feb08-2026
51	51	2026-02-08	2026-02-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.287441+00	2026-01-11 15:53:45.080887+00	Feb23-2026
52	52	2026-02-23	2026-03-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.288437+00	2026-01-11 15:53:45.080887+00	Mar08-2026
61	61	2026-07-08	2026-07-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.297433+00	2026-01-11 15:53:45.080887+00	Jul23-2026
62	62	2026-07-23	2026-08-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.298427+00	2026-01-11 15:53:45.080887+00	Aug08-2026
63	63	2026-08-08	2026-08-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.299425+00	2026-01-11 15:53:45.080887+00	Aug23-2026
64	64	2026-08-23	2026-09-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.300436+00	2026-01-11 15:53:45.080887+00	Sep08-2026
65	65	2026-09-08	2026-09-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.301429+00	2026-01-11 15:53:45.080887+00	Sep23-2026
66	66	2026-09-23	2026-10-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.302446+00	2026-01-11 15:53:45.080887+00	Oct08-2026
67	67	2026-10-08	2026-10-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.30345+00	2026-01-11 15:53:45.080887+00	Oct23-2026
68	68	2026-10-23	2026-11-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.304456+00	2026-01-11 15:53:45.080887+00	Nov08-2026
69	69	2026-11-08	2026-11-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.305447+00	2026-01-11 15:53:45.080887+00	Nov23-2026
70	70	2026-11-23	2026-12-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.306443+00	2026-01-11 15:53:45.080887+00	Dec08-2026
71	71	2026-12-08	2026-12-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.307448+00	2026-01-11 15:53:45.080887+00	Dec23-2026
72	72	2026-12-23	2027-01-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.308444+00	2026-01-11 15:53:45.080887+00	Jan08-2027
73	73	2027-01-08	2027-01-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jan23-2027
74	74	2027-01-23	2027-02-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Feb08-2027
75	75	2027-02-08	2027-02-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Feb23-2027
76	76	2027-02-23	2027-03-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Mar08-2027
77	77	2027-03-08	2027-03-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Mar23-2027
78	78	2027-03-23	2027-04-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Apr08-2027
79	79	2027-04-08	2027-04-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Apr23-2027
80	80	2027-04-23	2027-05-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	May08-2027
81	81	2027-05-08	2027-05-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	May23-2027
82	82	2027-05-23	2027-06-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jun08-2027
83	83	2027-06-08	2027-06-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jun23-2027
84	84	2027-06-23	2027-07-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jul08-2027
85	85	2027-07-08	2027-07-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jul23-2027
86	86	2027-07-23	2027-08-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Aug08-2027
87	87	2027-08-08	2027-08-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Aug23-2027
88	88	2027-08-23	2027-09-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Sep08-2027
89	89	2027-09-08	2027-09-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Sep23-2027
90	90	2027-09-23	2027-10-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Oct08-2027
91	91	2027-10-08	2027-10-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Oct23-2027
92	92	2027-10-23	2027-11-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Nov08-2027
93	93	2027-11-08	2027-11-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Nov23-2027
94	94	2027-11-23	2027-12-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Dec08-2027
95	95	2027-12-08	2027-12-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Dec23-2027
96	96	2027-12-23	2028-01-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jan08-2028
121	121	2029-01-08	2029-01-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan23-2029
122	122	2029-01-23	2029-02-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb08-2029
123	123	2029-02-08	2029-02-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb23-2029
124	124	2029-02-23	2029-03-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar08-2029
125	125	2029-03-08	2029-03-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar23-2029
126	126	2029-03-23	2029-04-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr08-2029
127	127	2029-04-08	2029-04-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr23-2029
128	128	2029-04-23	2029-05-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May08-2029
129	129	2029-05-08	2029-05-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May23-2029
130	130	2029-05-23	2029-06-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun08-2029
131	131	2029-06-08	2029-06-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun23-2029
132	132	2029-06-23	2029-07-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul08-2029
133	133	2029-07-08	2029-07-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul23-2029
134	134	2029-07-23	2029-08-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug08-2029
135	135	2029-08-08	2029-08-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug23-2029
136	136	2029-08-23	2029-09-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep08-2029
137	137	2029-09-08	2029-09-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep23-2029
138	138	2029-09-23	2029-10-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct08-2029
139	139	2029-10-08	2029-10-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct23-2029
140	140	2029-10-23	2029-11-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov08-2029
141	141	2029-11-08	2029-11-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov23-2029
142	142	2029-11-23	2029-12-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec08-2029
143	143	2029-12-08	2029-12-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec23-2029
144	144	2029-12-23	2030-01-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan08-2030
99	99	2028-02-08	2028-02-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Feb23-2028
100	100	2028-02-23	2028-03-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Mar08-2028
101	101	2028-03-08	2028-03-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Mar23-2028
102	102	2028-03-23	2028-04-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Apr08-2028
145	145	2030-01-08	2030-01-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan23-2030
146	146	2030-01-23	2030-02-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb08-2030
147	147	2030-02-08	2030-02-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb23-2030
148	148	2030-02-23	2030-03-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar08-2030
149	149	2030-03-08	2030-03-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar23-2030
150	150	2030-03-23	2030-04-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr08-2030
151	151	2030-04-08	2030-04-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr23-2030
152	152	2030-04-23	2030-05-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May08-2030
153	153	2030-05-08	2030-05-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May23-2030
154	154	2030-05-23	2030-06-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun08-2030
155	155	2030-06-08	2030-06-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun23-2030
156	156	2030-06-23	2030-07-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul08-2030
157	157	2030-07-08	2030-07-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul23-2030
158	158	2030-07-23	2030-08-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug08-2030
159	159	2030-08-08	2030-08-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug23-2030
160	160	2030-08-23	2030-09-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep08-2030
161	161	2030-09-08	2030-09-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep23-2030
162	162	2030-09-23	2030-10-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct08-2030
163	163	2030-10-08	2030-10-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct23-2030
10	10	2024-05-23	2024-06-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.244909+00	2026-01-11 15:53:45.080887+00	Jun08-2024
11	11	2024-06-08	2024-06-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.24612+00	2026-01-11 15:53:45.080887+00	Jun23-2024
12	12	2024-06-23	2024-07-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.247165+00	2026-01-11 15:53:45.080887+00	Jul08-2024
13	13	2024-07-08	2024-07-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.24812+00	2026-01-11 15:53:45.080887+00	Jul23-2024
14	14	2024-07-23	2024-08-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.249161+00	2026-01-11 15:53:45.080887+00	Aug08-2024
15	15	2024-08-08	2024-08-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.250188+00	2026-01-11 15:53:45.080887+00	Aug23-2024
16	16	2024-08-23	2024-09-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.251225+00	2026-01-11 15:53:45.080887+00	Sep08-2024
17	17	2024-09-08	2024-09-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.25225+00	2026-01-11 15:53:45.080887+00	Sep23-2024
18	18	2024-09-23	2024-10-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.253281+00	2026-01-11 15:53:45.080887+00	Oct08-2024
19	19	2024-10-08	2024-10-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.254293+00	2026-01-11 15:53:45.080887+00	Oct23-2024
20	20	2024-10-23	2024-11-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.255324+00	2026-01-11 15:53:45.080887+00	Nov08-2024
21	21	2024-11-08	2024-11-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.256349+00	2026-01-11 15:53:45.080887+00	Nov23-2024
22	22	2024-11-23	2024-12-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.257381+00	2026-01-11 15:53:45.080887+00	Dec08-2024
23	23	2024-12-08	2024-12-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.25842+00	2026-01-11 15:53:45.080887+00	Dec23-2024
24	24	2024-12-23	2025-01-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.259538+00	2026-01-11 15:53:45.080887+00	Jan08-2025
25	25	2025-01-08	2025-01-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.260567+00	2026-01-11 15:53:45.080887+00	Jan23-2025
26	26	2025-01-23	2025-02-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.261606+00	2026-01-11 15:53:45.080887+00	Feb08-2025
27	27	2025-02-08	2025-02-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.262638+00	2026-01-11 15:53:45.080887+00	Feb23-2025
28	28	2025-02-23	2025-03-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.263678+00	2026-01-11 15:53:45.080887+00	Mar08-2025
29	29	2025-03-08	2025-03-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.26471+00	2026-01-11 15:53:45.080887+00	Mar23-2025
30	30	2025-03-23	2025-04-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.26574+00	2026-01-11 15:53:45.080887+00	Apr08-2025
31	31	2025-04-08	2025-04-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.266767+00	2026-01-11 15:53:45.080887+00	Apr23-2025
32	32	2025-04-23	2025-05-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.26782+00	2026-01-11 15:53:45.080887+00	May08-2025
33	33	2025-05-08	2025-05-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.268866+00	2026-01-11 15:53:45.080887+00	May23-2025
34	34	2025-05-23	2025-06-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.269927+00	2026-01-11 15:53:45.080887+00	Jun08-2025
35	35	2025-06-08	2025-06-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.271003+00	2026-01-11 15:53:45.080887+00	Jun23-2025
36	36	2025-06-23	2025-07-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.272185+00	2026-01-11 15:53:45.080887+00	Jul08-2025
53	53	2026-03-08	2026-03-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.289431+00	2026-01-11 15:53:45.080887+00	Mar23-2026
54	54	2026-03-23	2026-04-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.290424+00	2026-01-11 15:53:45.080887+00	Apr08-2026
55	55	2026-04-08	2026-04-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.291428+00	2026-01-11 15:53:45.080887+00	Apr23-2026
56	56	2026-04-23	2026-05-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.292434+00	2026-01-11 15:53:45.080887+00	May08-2026
57	57	2026-05-08	2026-05-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.293426+00	2026-01-11 15:53:45.080887+00	May23-2026
58	58	2026-05-23	2026-06-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.294429+00	2026-01-11 15:53:45.080887+00	Jun08-2026
59	59	2026-06-08	2026-06-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.295432+00	2026-01-11 15:53:45.080887+00	Jun23-2026
60	60	2026-06-23	2026-07-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.296437+00	2026-01-11 15:53:45.080887+00	Jul08-2026
164	164	2030-10-23	2030-11-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov08-2030
165	165	2030-11-08	2030-11-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov23-2030
166	166	2030-11-23	2030-12-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec08-2030
167	167	2030-12-08	2030-12-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec23-2030
168	168	2030-12-23	2031-01-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan08-2031
169	169	2031-01-08	2031-01-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan23-2031
170	170	2031-01-23	2031-02-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb08-2031
171	171	2031-02-08	2031-02-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb23-2031
103	103	2028-04-08	2028-04-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Apr23-2028
104	104	2028-04-23	2028-05-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	May08-2028
105	105	2028-05-08	2028-05-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	May23-2028
106	106	2028-05-23	2028-06-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jun08-2028
107	107	2028-06-08	2028-06-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jun23-2028
108	108	2028-06-23	2028-07-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jul08-2028
109	109	2028-07-08	2028-07-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jul23-2028
110	110	2028-07-23	2028-08-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Aug08-2028
111	111	2028-08-08	2028-08-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Aug23-2028
112	112	2028-08-23	2028-09-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Sep08-2028
113	113	2028-09-08	2028-09-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Sep23-2028
114	114	2028-09-23	2028-10-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Oct08-2028
115	115	2028-10-08	2028-10-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Oct23-2028
116	116	2028-10-23	2028-11-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Nov08-2028
117	117	2028-11-08	2028-11-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Nov23-2028
118	118	2028-11-23	2028-12-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Dec08-2028
119	119	2028-12-08	2028-12-22	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Dec23-2028
120	120	2028-12-23	2029-01-07	1	0.00	0.00	0.00	1	\N	2026-01-11 13:35:17.630266+00	2026-01-11 16:07:54.720639+00	Jan08-2029
172	172	2031-02-23	2031-03-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar08-2031
173	173	2031-03-08	2031-03-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar23-2031
174	174	2031-03-23	2031-04-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr08-2031
175	175	2031-04-08	2031-04-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr23-2031
176	176	2031-04-23	2031-05-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May08-2031
177	177	2031-05-08	2031-05-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May23-2031
178	178	2031-05-23	2031-06-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun08-2031
179	179	2031-06-08	2031-06-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun23-2031
180	180	2031-06-23	2031-07-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul08-2031
181	181	2031-07-08	2031-07-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul23-2031
182	182	2031-07-23	2031-08-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug08-2031
183	183	2031-08-08	2031-08-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug23-2031
184	184	2031-08-23	2031-09-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep08-2031
185	185	2031-09-08	2031-09-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep23-2031
186	186	2031-09-23	2031-10-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct08-2031
187	187	2031-10-08	2031-10-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct23-2031
188	188	2031-10-23	2031-11-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov08-2031
189	189	2031-11-08	2031-11-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov23-2031
190	190	2031-11-23	2031-12-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec08-2031
191	191	2031-12-08	2031-12-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec23-2031
192	192	2031-12-23	2032-01-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan08-2032
251	251	2034-06-08	2034-06-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun23-2034
252	252	2034-06-23	2034-07-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul08-2034
253	253	2034-07-08	2034-07-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul23-2034
254	254	2034-07-23	2034-08-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug08-2034
255	255	2034-08-08	2034-08-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug23-2034
256	256	2034-08-23	2034-09-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep08-2034
257	257	2034-09-08	2034-09-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep23-2034
258	258	2034-09-23	2034-10-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct08-2034
259	259	2034-10-08	2034-10-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct23-2034
260	260	2034-10-23	2034-11-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov08-2034
261	261	2034-11-08	2034-11-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov23-2034
262	262	2034-11-23	2034-12-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec08-2034
263	263	2034-12-08	2034-12-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec23-2034
264	264	2034-12-23	2035-01-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan08-2035
265	265	2035-01-08	2035-01-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan23-2035
266	266	2035-01-23	2035-02-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb08-2035
267	267	2035-02-08	2035-02-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Feb23-2035
268	268	2035-02-23	2035-03-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar08-2035
269	269	2035-03-08	2035-03-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Mar23-2035
270	270	2035-03-23	2035-04-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr08-2035
271	271	2035-04-08	2035-04-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Apr23-2035
272	272	2035-04-23	2035-05-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May08-2035
273	273	2035-05-08	2035-05-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	May23-2035
274	274	2035-05-23	2035-06-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun08-2035
275	275	2035-06-08	2035-06-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jun23-2035
276	276	2035-06-23	2035-07-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul08-2035
277	277	2035-07-08	2035-07-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jul23-2035
278	278	2035-07-23	2035-08-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug08-2035
279	279	2035-08-08	2035-08-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Aug23-2035
280	280	2035-08-23	2035-09-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep08-2035
281	281	2035-09-08	2035-09-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Sep23-2035
282	282	2035-09-23	2035-10-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct08-2035
283	283	2035-10-08	2035-10-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Oct23-2035
284	284	2035-10-23	2035-11-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov08-2035
285	285	2035-11-08	2035-11-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Nov23-2035
286	286	2035-11-23	2035-12-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec08-2035
287	287	2035-12-08	2035-12-22	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Dec23-2035
288	288	2035-12-23	2036-01-07	1	0.00	0.00	0.00	1	\N	2026-01-11 16:08:33.269075+00	2026-01-11 16:08:33.269075+00	Jan08-2036
49	49	2026-01-08	2026-01-22	4	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.285443+00	2026-01-23 06:02:45.669652+00	Jan23-2026
48	48	2025-12-23	2026-01-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.284442+00	2026-01-23 06:13:57.570603+00	Jan08-2026
\.


--
-- TOC entry 4375 (class 0 OID 16650)
-- Dependencies: 256
-- Data for Name: defaulted_client_reports; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.defaulted_client_reports (id, associate_profile_id, loan_id, client_user_id, reported_at, reported_by, total_debt_amount, evidence_details, evidence_file_path, status, approved_by, approved_at, rejection_reason, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4377 (class 0 OID 16663)
-- Dependencies: 258
-- Data for Name: document_statuses; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.document_statuses (id, name, description, display_order, color_code, created_at, updated_at) FROM stdin;
1	PENDING	Documento cargado, pendiente de revisión.	1	#FFA500	2025-10-31 01:12:22.083043+00	2025-10-31 01:12:22.083043+00
2	UNDER_REVIEW	En proceso de revisión.	2	#2196F3	2025-10-31 01:12:22.083043+00	2025-10-31 01:12:22.083043+00
3	APPROVED	Documento aprobado.	3	#4CAF50	2025-10-31 01:12:22.083043+00	2025-10-31 01:12:22.083043+00
4	REJECTED	Documento rechazado.	4	#F44336	2025-10-31 01:12:22.083043+00	2025-10-31 01:12:22.083043+00
\.


--
-- TOC entry 4379 (class 0 OID 16672)
-- Dependencies: 260
-- Data for Name: document_types; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.document_types (id, name, description, is_required, created_at, updated_at) FROM stdin;
1	Identificación Oficial	INE, Pasaporte o Cédula Profesional	t	2025-10-31 01:12:22.088252+00	2025-10-31 01:12:22.088252+00
2	Comprobante de Domicilio	Recibo de luz, agua o predial	t	2025-10-31 01:12:22.088252+00	2025-10-31 01:12:22.088252+00
3	Comprobante de Ingresos	Estado de cuenta o constancia laboral	t	2025-10-31 01:12:22.088252+00	2025-10-31 01:12:22.088252+00
4	CURP	Clave Única de Registro de Población	f	2025-10-31 01:12:22.088252+00	2025-10-31 01:12:22.088252+00
5	Referencia Personal	Datos de contacto de referencia	f	2025-10-31 01:12:22.088252+00	2025-10-31 01:12:22.088252+00
\.


--
-- TOC entry 4381 (class 0 OID 16681)
-- Dependencies: 262
-- Data for Name: guarantors; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.guarantors (id, user_id, full_name, first_name, paternal_last_name, maternal_last_name, relationship, phone_number, curp, created_at, updated_at, relationship_id) FROM stdin;
2	3	Maria Cruz Escobedo	Maria	Cruz	Escobedo	Madre	6142772794	CUEM641208MCHRSR00	2026-01-20 06:39:09.430948+00	2026-01-20 06:39:09.430948+00	\N
3	4	Jair Noel Franco Cruz	Jair Noel	Franco	Cruz	Hijo/a	6143618298	FACJ950525HCHRRR04	2026-01-21 08:05:35.453452+00	2026-01-21 08:05:35.453452+00	\N
\.


--
-- TOC entry 4383 (class 0 OID 16691)
-- Dependencies: 264
-- Data for Name: legacy_payment_table; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.legacy_payment_table (id, amount, biweekly_payment, term_biweeks, created_at, updated_at, created_by, updated_by, associate_biweekly_payment) FROM stdin;
1	3000.00	392.00	12	2025-11-05 00:58:16.106847+00	2025-11-14 06:14:19.666222+00	\N	\N	337.00
2	4000.00	510.00	12	2025-11-05 00:58:16.106847+00	2025-11-14 06:14:19.666222+00	\N	\N	446.00
3	5000.00	633.00	12	2025-11-05 00:58:16.106847+00	2025-11-14 06:14:19.666222+00	\N	\N	553.00
4	6000.00	752.00	12	2025-11-05 00:58:16.106847+00	2025-11-14 06:14:19.666222+00	\N	\N	662.00
5	7000.00	882.00	12	2025-11-05 00:58:16.106847+00	2025-11-14 06:14:19.666222+00	\N	\N	770.00
9	11000.00	1385.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.778859+00	\N	\N	1215.00
10	12000.00	1504.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.779878+00	\N	\N	1324.00
11	13000.00	1634.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.78118+00	\N	\N	1432.00
12	14000.00	1765.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.78225+00	\N	\N	1541.00
6	8000.00	1006.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.768083+00	\N	\N	878.00
7	9000.00	1131.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.776819+00	\N	\N	987.00
8	10000.00	1255.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.777857+00	\N	\N	1095.00
13	15000.00	1888.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.783265+00	\N	\N	1648.00
14	16000.00	2012.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.784299+00	\N	\N	1756.00
15	17000.00	2137.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.785341+00	\N	\N	1865.00
16	18000.00	2262.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.78657+00	\N	\N	1974.00
17	19000.00	2386.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.788269+00	\N	\N	2082.00
18	20000.00	2510.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.789286+00	\N	\N	2190.00
19	21000.00	2640.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.790324+00	\N	\N	2310.00
20	22000.00	2759.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.791338+00	\N	\N	2419.00
21	23000.00	2889.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.792343+00	\N	\N	2527.00
22	24000.00	3020.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.793351+00	\N	\N	2636.00
23	25000.00	3143.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.79437+00	\N	\N	2743.00
24	26000.00	3267.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.795395+00	\N	\N	2851.00
25	27000.00	3392.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.796425+00	\N	\N	2960.00
26	28000.00	3517.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.797426+00	\N	\N	3069.00
27	29000.00	3641.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.798439+00	\N	\N	3177.00
28	30000.00	3765.00	12	2025-11-05 00:58:16.106847+00	2025-11-19 00:39:21.799449+00	\N	\N	3285.00
\.


--
-- TOC entry 4385 (class 0 OID 16708)
-- Dependencies: 266
-- Data for Name: level_change_types; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.level_change_types (id, name, description, is_automatic, display_order, created_at, updated_at) FROM stdin;
1	PROMOTION	Promoción automática a nivel superior.	t	1	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
2	DEMOTION	Descenso por incumplimiento.	t	2	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
3	MANUAL	Cambio manual por admin.	f	3	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
4	INITIAL	Nivel inicial al registrarse.	f	4	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
5	REWARD	Promoción especial por logro.	f	5	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
6	PENALTY	Descenso por sanción.	f	6	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
\.


--
-- TOC entry 4387 (class 0 OID 16718)
-- Dependencies: 268
-- Data for Name: loan_renewals; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.loan_renewals (id, original_loan_id, renewed_loan_id, renewal_date, pending_balance, new_amount, reason, created_by, created_at) FROM stdin;
\.


--
-- TOC entry 4389 (class 0 OID 16726)
-- Dependencies: 270
-- Data for Name: loan_statuses; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.loan_statuses (id, name, description, is_active, display_order, color_code, icon_name, created_at, updated_at) FROM stdin;
1	PENDING	Préstamo solicitado pero aún no aprobado ni desembolsado.	t	1	#FFA500	clock	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
4	COMPLETED	Préstamo completamente liquidado.	t	4	#00C853	check-all	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
5	PAID	Préstamo totalmente pagado (sinónimo de COMPLETED).	t	5	#00C853	check-all	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
6	DEFAULTED	Préstamo en mora o incumplimiento.	t	6	#F44336	alert-triangle	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
7	REJECTED	Solicitud rechazada por administrador.	t	7	#9E9E9E	x-circle	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
8	CANCELLED	Préstamo cancelado antes de completarse.	t	8	#757575	slash	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
9	IN_AGREEMENT	Préstamo en convenio de pago - pagos pendientes transferidos a deuda del asociado.	t	0	\N	\N	2026-01-08 12:56:44.540864+00	2026-01-08 12:56:44.540864+00
2	ACTIVE	Préstamo desembolsado y activo, con pagos en curso.	t	2	#4CAF50	check-circle	2025-10-31 01:12:22.075733+00	2026-01-09 08:23:39.826778+00
\.


--
-- TOC entry 4391 (class 0 OID 16736)
-- Dependencies: 272
-- Data for Name: loans; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.loans (id, user_id, associate_user_id, amount, interest_rate, commission_rate, term_biweeks, status_id, contract_id, approved_at, approved_by, rejected_at, rejected_by, rejection_reason, notes, created_at, updated_at, profile_code, biweekly_payment, total_payment, total_interest, total_commission, commission_per_payment, associate_payment) FROM stdin;
1	3	4	10000.00	4.22	12.75	12	2	\N	2026-01-22 22:04:36.524118+00	2	\N	\N	\N	prestamo de prueba 1, producción\n[APROBACIÓN] Prueba, Ficticio	2026-01-22 22:03:28.860485+00	2026-01-22 22:04:36.517843+00	legacy	1255.00	15060.00	5060.00	1920.00	160.00	1095.00
2	3	4	15000.00	4.25	1.60	15	2	\N	2026-01-23 06:16:42.73649+00	2	\N	\N	\N	prestamo de prueba 2 con perfil recomendado	2026-01-23 06:15:47.472576+00	2026-01-23 06:16:42.730008+00	standard	1637.50	24562.50	9562.50	3600.00	240.00	1397.50
3	3	4	5000.00	5.00	1.80	6	2	\N	2026-01-23 06:20:21.520289+00	2	\N	\N	\N	prestamo 3 de prueba con perfil personalizado, tasas personalizadas, 5% iinteres quincenal, 1.8 comisión para el asociado, generoso a 6 quincenas	2026-01-23 06:20:00.297814+00	2026-01-23 06:20:21.516237+00	custom	1083.33	6500.00	1500.00	540.00	90.00	993.33
\.


--
-- TOC entry 4393 (class 0 OID 16759)
-- Dependencies: 274
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.payment_methods (id, name, description, is_active, requires_reference, display_order, icon_name, created_at, updated_at) FROM stdin;
1	CASH	Pago en efectivo.	t	f	1	dollar-sign	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
2	TRANSFER	Transferencia bancaria.	t	t	2	arrow-right-circle	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
3	CHECK	Cheque bancario.	t	t	3	file-text	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
4	PAYROLL_DEDUCTION	Descuento de nómina.	t	f	4	briefcase	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
5	CARD	Tarjeta débito/crédito.	t	t	5	credit-card	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
6	DEPOSIT	Depósito bancario.	t	t	6	inbox	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
7	OXXO	Pago en OXXO.	t	t	7	shopping-bag	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
\.


--
-- TOC entry 4395 (class 0 OID 16770)
-- Dependencies: 276
-- Data for Name: payment_status_history; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.payment_status_history (id, payment_id, old_status_id, new_status_id, change_type, changed_by, change_reason, ip_address, user_agent, changed_at) FROM stdin;
\.


--
-- TOC entry 4397 (class 0 OID 16779)
-- Dependencies: 278
-- Data for Name: payment_statuses; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.payment_statuses (id, name, description, is_active, display_order, color_code, icon_name, is_real_payment, created_at, updated_at) FROM stdin;
1	PENDING	Pago programado, aún no vence.	t	1	#9E9E9E	clock	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
2	DUE_TODAY	Pago vence hoy.	t	2	#FF9800	calendar	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
4	OVERDUE	Pago vencido, no pagado.	t	4	#F44336	alert-circle	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
5	PARTIAL	Pago parcial realizado.	t	5	#2196F3	pie-chart	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
6	IN_COLLECTION	En proceso de cobranza.	t	6	#9C27B0	phone	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
7	RESCHEDULED	Pago reprogramado.	t	7	#03A9F4	refresh-cw	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
3	PAID	Pago completado por cliente.	t	3	#4CAF50	check	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
8	PAID_PARTIAL	Pago parcial aceptado.	t	8	#8BC34A	check-circle	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
9	PAID_BY_ASSOCIATE	Pagado por asociado (cliente moroso).	t	9	#FF5722	user-x	f	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
10	PAID_NOT_REPORTED	Pago no reportado al cierre.	t	10	#FFC107	alert-triangle	f	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
11	FORGIVEN	Pago perdonado por administración.	t	11	#00BCD4	heart	f	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
12	CANCELLED	Pago cancelado.	t	12	#607D8B	x	f	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
13	IN_AGREEMENT	Pago incluido en convenio - se cobrará al asociado via convenio.	t	0	\N	\N	f	2026-01-08 12:56:44.540864+00	2026-01-08 12:56:44.540864+00
\.


--
-- TOC entry 4399 (class 0 OID 16790)
-- Dependencies: 280
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.payments (id, loan_id, amount_paid, payment_date, payment_due_date, is_late, status_id, cut_period_id, marked_by, marked_at, marking_notes, created_at, updated_at, payment_number, expected_amount, interest_amount, principal_amount, commission_amount, associate_payment, balance_remaining, associate_balance_remaining, cumulative_associate_paid, total_associate_payment, notes) FROM stdin;
1	1	0.00	\N	2026-01-31	f	1	49	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	1	1255.00	421.67	833.33	160.00	1095.00	\N	\N	1095.00	13140.00	Generado automáticamente - Perfil: legacy
2	1	0.00	\N	2026-02-15	f	1	50	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	2	1255.00	421.67	833.33	160.00	1095.00	\N	\N	2190.00	13140.00	Generado automáticamente - Perfil: legacy
3	1	0.00	\N	2026-02-28	f	1	51	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	3	1255.00	421.67	833.33	160.00	1095.00	\N	\N	3285.00	13140.00	Generado automáticamente - Perfil: legacy
4	1	0.00	\N	2026-03-15	f	1	52	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	4	1255.00	421.67	833.33	160.00	1095.00	\N	\N	4380.00	13140.00	Generado automáticamente - Perfil: legacy
5	1	0.00	\N	2026-03-31	f	1	53	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	5	1255.00	421.67	833.33	160.00	1095.00	\N	\N	5475.00	13140.00	Generado automáticamente - Perfil: legacy
6	1	0.00	\N	2026-04-15	f	1	54	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	6	1255.00	421.67	833.33	160.00	1095.00	\N	\N	6570.00	13140.00	Generado automáticamente - Perfil: legacy
7	1	0.00	\N	2026-04-30	f	1	55	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	7	1255.00	421.67	833.33	160.00	1095.00	\N	\N	7665.00	13140.00	Generado automáticamente - Perfil: legacy
8	1	0.00	\N	2026-05-15	f	1	56	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	8	1255.00	421.67	833.33	160.00	1095.00	\N	\N	8760.00	13140.00	Generado automáticamente - Perfil: legacy
9	1	0.00	\N	2026-05-31	f	1	57	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	9	1255.00	421.67	833.33	160.00	1095.00	\N	\N	9855.00	13140.00	Generado automáticamente - Perfil: legacy
10	1	0.00	\N	2026-06-15	f	1	58	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	10	1255.00	421.67	833.33	160.00	1095.00	\N	\N	10950.00	13140.00	Generado automáticamente - Perfil: legacy
11	1	0.00	\N	2026-06-30	f	1	59	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	11	1255.00	421.67	833.33	160.00	1095.00	\N	\N	12045.00	13140.00	Generado automáticamente - Perfil: legacy
12	1	0.00	\N	2026-07-15	f	1	60	\N	\N	\N	2026-01-22 22:04:36.517843+00	2026-01-22 22:04:36.517843+00	12	1255.00	421.67	833.33	160.00	1095.00	\N	\N	13140.00	13140.00	Generado automáticamente - Perfil: legacy
13	2	0.00	\N	2026-02-15	f	1	50	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	1	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	1397.50	20962.50	Generado automáticamente - Perfil: standard
14	2	0.00	\N	2026-02-28	f	1	51	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	2	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	2795.00	20962.50	Generado automáticamente - Perfil: standard
15	2	0.00	\N	2026-03-15	f	1	52	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	3	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	4192.50	20962.50	Generado automáticamente - Perfil: standard
16	2	0.00	\N	2026-03-31	f	1	53	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	4	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	5590.00	20962.50	Generado automáticamente - Perfil: standard
17	2	0.00	\N	2026-04-15	f	1	54	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	5	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	6987.50	20962.50	Generado automáticamente - Perfil: standard
18	2	0.00	\N	2026-04-30	f	1	55	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	6	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	8385.00	20962.50	Generado automáticamente - Perfil: standard
19	2	0.00	\N	2026-05-15	f	1	56	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	7	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	9782.50	20962.50	Generado automáticamente - Perfil: standard
20	2	0.00	\N	2026-05-31	f	1	57	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	8	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	11180.00	20962.50	Generado automáticamente - Perfil: standard
21	2	0.00	\N	2026-06-15	f	1	58	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	9	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	12577.50	20962.50	Generado automáticamente - Perfil: standard
22	2	0.00	\N	2026-06-30	f	1	59	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	10	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	13975.00	20962.50	Generado automáticamente - Perfil: standard
23	2	0.00	\N	2026-07-15	f	1	60	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	11	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	15372.50	20962.50	Generado automáticamente - Perfil: standard
24	2	0.00	\N	2026-07-31	f	1	61	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	12	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	16770.00	20962.50	Generado automáticamente - Perfil: standard
25	2	0.00	\N	2026-08-15	f	1	62	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	13	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	18167.50	20962.50	Generado automáticamente - Perfil: standard
26	2	0.00	\N	2026-08-31	f	1	63	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	14	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	19565.00	20962.50	Generado automáticamente - Perfil: standard
27	2	0.00	\N	2026-09-15	f	1	64	\N	\N	\N	2026-01-23 06:16:42.730008+00	2026-01-23 06:16:42.730008+00	15	1637.50	637.50	1000.00	240.00	1397.50	\N	\N	20962.50	20962.50	Generado automáticamente - Perfil: standard
28	3	0.00	\N	2026-02-15	f	1	50	\N	\N	\N	2026-01-23 06:20:21.516237+00	2026-01-23 06:20:21.516237+00	1	1083.33	250.00	833.33	90.00	993.33	\N	\N	993.33	5959.98	Generado automáticamente - Perfil: custom
29	3	0.00	\N	2026-02-28	f	1	51	\N	\N	\N	2026-01-23 06:20:21.516237+00	2026-01-23 06:20:21.516237+00	2	1083.33	250.00	833.33	90.00	993.33	\N	\N	1986.66	5959.98	Generado automáticamente - Perfil: custom
30	3	0.00	\N	2026-03-15	f	1	52	\N	\N	\N	2026-01-23 06:20:21.516237+00	2026-01-23 06:20:21.516237+00	3	1083.33	250.00	833.33	90.00	993.33	\N	\N	2979.99	5959.98	Generado automáticamente - Perfil: custom
31	3	0.00	\N	2026-03-31	f	1	53	\N	\N	\N	2026-01-23 06:20:21.516237+00	2026-01-23 06:20:21.516237+00	4	1083.33	250.00	833.33	90.00	993.33	\N	\N	3973.32	5959.98	Generado automáticamente - Perfil: custom
32	3	0.00	\N	2026-04-15	f	1	54	\N	\N	\N	2026-01-23 06:20:21.516237+00	2026-01-23 06:20:21.516237+00	5	1083.33	250.00	833.33	90.00	993.33	\N	\N	4966.65	5959.98	Generado automáticamente - Perfil: custom
33	3	0.00	\N	2026-04-30	f	1	55	\N	\N	\N	2026-01-23 06:20:21.516237+00	2026-01-23 06:20:21.516237+00	6	1083.33	250.00	833.33	90.00	993.33	\N	\N	5959.98	5959.98	Generado automáticamente - Perfil: custom
\.


--
-- TOC entry 4401 (class 0 OID 16815)
-- Dependencies: 282
-- Data for Name: rate_profile_reference_table; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.rate_profile_reference_table (id, profile_code, amount, term_biweeks, biweekly_payment, total_payment, commission_per_payment, total_commission, associate_payment, associate_total, interest_rate_percent, commission_rate_percent, created_at) FROM stdin;
1	transition	3000.00	6	612.50	3675.00	73.50	441.00	539.00	3234.00	3.750	12.000	2025-11-14 06:28:37.101355+00
2	transition	4000.00	6	816.67	4900.00	98.00	588.00	718.67	4312.02	3.750	12.000	2025-11-14 06:28:37.101355+00
3	transition	5000.00	6	1020.83	6125.00	122.50	735.00	898.33	5389.98	3.750	12.000	2025-11-14 06:28:37.101355+00
4	transition	6000.00	6	1225.00	7350.00	147.00	882.00	1078.00	6468.00	3.750	12.000	2025-11-14 06:28:37.101355+00
5	transition	7000.00	6	1429.17	8575.00	171.50	1029.00	1257.67	7546.02	3.750	12.000	2025-11-14 06:28:37.101355+00
6	transition	8000.00	6	1633.33	9800.00	196.00	1176.00	1437.33	8623.98	3.750	12.000	2025-11-14 06:28:37.101355+00
7	transition	9000.00	6	1837.50	11025.00	220.50	1323.00	1617.00	9702.00	3.750	12.000	2025-11-14 06:28:37.101355+00
8	transition	10000.00	6	2041.67	12250.00	245.00	1470.00	1796.67	10780.02	3.750	12.000	2025-11-14 06:28:37.101355+00
9	transition	12000.00	6	2450.00	14700.00	294.00	1764.00	2156.00	12936.00	3.750	12.000	2025-11-14 06:28:37.101355+00
10	transition	15000.00	6	3062.50	18375.00	367.50	2205.00	2695.00	16170.00	3.750	12.000	2025-11-14 06:28:37.101355+00
11	transition	18000.00	6	3675.00	22050.00	441.00	2646.00	3234.00	19404.00	3.750	12.000	2025-11-14 06:28:37.101355+00
12	transition	20000.00	6	4083.33	24500.00	490.00	2940.00	3593.33	21559.98	3.750	12.000	2025-11-14 06:28:37.101355+00
13	transition	25000.00	6	5104.17	30625.00	612.50	3675.00	4491.67	26950.02	3.750	12.000	2025-11-14 06:28:37.101355+00
14	transition	30000.00	6	6125.00	36750.00	735.00	4410.00	5390.00	32340.00	3.750	12.000	2025-11-14 06:28:37.101355+00
15	transition	3000.00	12	362.50	4350.00	43.50	522.00	319.00	3828.00	3.750	12.000	2025-11-14 06:28:37.101355+00
16	transition	4000.00	12	483.33	5800.00	58.00	696.00	425.33	5103.96	3.750	12.000	2025-11-14 06:28:37.101355+00
17	transition	5000.00	12	604.17	7250.00	72.50	870.00	531.67	6380.04	3.750	12.000	2025-11-14 06:28:37.101355+00
18	transition	6000.00	12	725.00	8700.00	87.00	1044.00	638.00	7656.00	3.750	12.000	2025-11-14 06:28:37.101355+00
19	transition	7000.00	12	845.83	10150.00	101.50	1218.00	744.33	8931.96	3.750	12.000	2025-11-14 06:28:37.101355+00
20	transition	8000.00	12	966.67	11600.00	116.00	1392.00	850.67	10208.04	3.750	12.000	2025-11-14 06:28:37.101355+00
21	transition	9000.00	12	1087.50	13050.00	130.50	1566.00	957.00	11484.00	3.750	12.000	2025-11-14 06:28:37.101355+00
22	transition	10000.00	12	1208.33	14500.00	145.00	1740.00	1063.33	12759.96	3.750	12.000	2025-11-14 06:28:37.101355+00
23	transition	12000.00	12	1450.00	17400.00	174.00	2088.00	1276.00	15312.00	3.750	12.000	2025-11-14 06:28:37.101355+00
24	transition	15000.00	12	1812.50	21750.00	217.50	2610.00	1595.00	19140.00	3.750	12.000	2025-11-14 06:28:37.101355+00
25	transition	18000.00	12	2175.00	26100.00	261.00	3132.00	1914.00	22968.00	3.750	12.000	2025-11-14 06:28:37.101355+00
26	transition	20000.00	12	2416.67	29000.00	290.00	3480.00	2126.67	25520.04	3.750	12.000	2025-11-14 06:28:37.101355+00
27	transition	25000.00	12	3020.83	36250.00	362.50	4350.00	2658.33	31899.96	3.750	12.000	2025-11-14 06:28:37.101355+00
28	transition	30000.00	12	3625.00	43500.00	435.00	5220.00	3190.00	38280.00	3.750	12.000	2025-11-14 06:28:37.101355+00
29	transition	3000.00	18	279.17	5025.00	33.50	603.00	245.67	4422.06	3.750	12.000	2025-11-14 06:28:37.101355+00
30	transition	4000.00	18	372.22	6700.00	44.67	804.06	327.55	5895.90	3.750	12.000	2025-11-14 06:28:37.101355+00
31	transition	5000.00	18	465.28	8375.00	55.83	1004.94	409.45	7370.10	3.750	12.000	2025-11-14 06:28:37.101355+00
32	transition	6000.00	18	558.33	10050.00	67.00	1206.00	491.33	8843.94	3.750	12.000	2025-11-14 06:28:37.101355+00
33	transition	7000.00	18	651.39	11725.00	78.17	1407.06	573.22	10317.96	3.750	12.000	2025-11-14 06:28:37.101355+00
34	transition	8000.00	18	744.44	13400.00	89.33	1607.94	655.11	11791.98	3.750	12.000	2025-11-14 06:28:37.101355+00
35	transition	9000.00	18	837.50	15075.00	100.50	1809.00	737.00	13266.00	3.750	12.000	2025-11-14 06:28:37.101355+00
36	transition	10000.00	18	930.56	16750.00	111.67	2010.06	818.89	14740.02	3.750	12.000	2025-11-14 06:28:37.101355+00
37	transition	12000.00	18	1116.67	20100.00	134.00	2412.00	982.67	17688.06	3.750	12.000	2025-11-14 06:28:37.101355+00
38	transition	15000.00	18	1395.83	25125.00	167.50	3015.00	1228.33	22109.94	3.750	12.000	2025-11-14 06:28:37.101355+00
39	transition	18000.00	18	1675.00	30150.00	201.00	3618.00	1474.00	26532.00	3.750	12.000	2025-11-14 06:28:37.101355+00
40	transition	20000.00	18	1861.11	33500.00	223.33	4019.94	1637.78	29480.04	3.750	12.000	2025-11-14 06:28:37.101355+00
41	transition	25000.00	18	2326.39	41875.00	279.17	5025.06	2047.22	36849.96	3.750	12.000	2025-11-14 06:28:37.101355+00
42	transition	30000.00	18	2791.67	50250.00	335.00	6030.00	2456.67	44220.06	3.750	12.000	2025-11-14 06:28:37.101355+00
43	transition	3000.00	24	237.50	5700.00	28.50	684.00	209.00	5016.00	3.750	12.000	2025-11-14 06:28:37.101355+00
44	transition	4000.00	24	316.67	7600.00	38.00	912.00	278.67	6688.08	3.750	12.000	2025-11-14 06:28:37.101355+00
45	transition	5000.00	24	395.83	9500.00	47.50	1140.00	348.33	8359.92	3.750	12.000	2025-11-14 06:28:37.101355+00
46	transition	6000.00	24	475.00	11400.00	57.00	1368.00	418.00	10032.00	3.750	12.000	2025-11-14 06:28:37.101355+00
47	transition	7000.00	24	554.17	13300.00	66.50	1596.00	487.67	11704.08	3.750	12.000	2025-11-14 06:28:37.101355+00
48	transition	8000.00	24	633.33	15200.00	76.00	1824.00	557.33	13375.92	3.750	12.000	2025-11-14 06:28:37.101355+00
49	transition	9000.00	24	712.50	17100.00	85.50	2052.00	627.00	15048.00	3.750	12.000	2025-11-14 06:28:37.101355+00
50	transition	10000.00	24	791.67	19000.00	95.00	2280.00	696.67	16720.08	3.750	12.000	2025-11-14 06:28:37.101355+00
51	transition	12000.00	24	950.00	22800.00	114.00	2736.00	836.00	20064.00	3.750	12.000	2025-11-14 06:28:37.101355+00
52	transition	15000.00	24	1187.50	28500.00	142.50	3420.00	1045.00	25080.00	3.750	12.000	2025-11-14 06:28:37.101355+00
53	transition	18000.00	24	1425.00	34200.00	171.00	4104.00	1254.00	30096.00	3.750	12.000	2025-11-14 06:28:37.101355+00
54	transition	20000.00	24	1583.33	38000.00	190.00	4560.00	1393.33	33439.92	3.750	12.000	2025-11-14 06:28:37.101355+00
55	transition	25000.00	24	1979.17	47500.00	237.50	5700.00	1741.67	41800.08	3.750	12.000	2025-11-14 06:28:37.101355+00
56	transition	30000.00	24	2375.00	57000.00	285.00	6840.00	2090.00	50160.00	3.750	12.000	2025-11-14 06:28:37.101355+00
57	standard	3000.00	3	1127.50	3382.50	135.30	405.90	992.20	2976.60	4.250	12.000	2025-11-14 06:28:43.931117+00
58	standard	4000.00	3	1503.33	4510.00	180.40	541.20	1322.93	3968.79	4.250	12.000	2025-11-14 06:28:43.931117+00
59	standard	5000.00	3	1879.17	5637.50	225.50	676.50	1653.67	4961.01	4.250	12.000	2025-11-14 06:28:43.931117+00
60	standard	6000.00	3	2255.00	6765.00	270.60	811.80	1984.40	5953.20	4.250	12.000	2025-11-14 06:28:43.931117+00
61	standard	7000.00	3	2630.83	7892.50	315.70	947.10	2315.13	6945.39	4.250	12.000	2025-11-14 06:28:43.931117+00
62	standard	8000.00	3	3006.67	9020.00	360.80	1082.40	2645.87	7937.61	4.250	12.000	2025-11-14 06:28:43.931117+00
63	standard	9000.00	3	3382.50	10147.50	405.90	1217.70	2976.60	8929.80	4.250	12.000	2025-11-14 06:28:43.931117+00
64	standard	10000.00	3	3758.33	11275.00	451.00	1353.00	3307.33	9921.99	4.250	12.000	2025-11-14 06:28:43.931117+00
65	standard	12000.00	3	4510.00	13530.00	541.20	1623.60	3968.80	11906.40	4.250	12.000	2025-11-14 06:28:43.931117+00
66	standard	15000.00	3	5637.50	16912.50	676.50	2029.50	4961.00	14883.00	4.250	12.000	2025-11-14 06:28:43.931117+00
67	standard	18000.00	3	6765.00	20295.00	811.80	2435.40	5953.20	17859.60	4.250	12.000	2025-11-14 06:28:43.931117+00
68	standard	20000.00	3	7516.67	22550.00	902.00	2706.00	6614.67	19844.01	4.250	12.000	2025-11-14 06:28:43.931117+00
69	standard	25000.00	3	9395.83	28187.50	1127.50	3382.50	8268.33	24804.99	4.250	12.000	2025-11-14 06:28:43.931117+00
70	standard	30000.00	3	11275.00	33825.00	1353.00	4059.00	9922.00	29766.00	4.250	12.000	2025-11-14 06:28:43.931117+00
71	standard	3000.00	6	627.50	3765.00	75.30	451.80	552.20	3313.20	4.250	12.000	2025-11-14 06:28:43.931117+00
72	standard	4000.00	6	836.67	5020.00	100.40	602.40	736.27	4417.62	4.250	12.000	2025-11-14 06:28:43.931117+00
73	standard	5000.00	6	1045.83	6275.00	125.50	753.00	920.33	5521.98	4.250	12.000	2025-11-14 06:28:43.931117+00
74	standard	6000.00	6	1255.00	7530.00	150.60	903.60	1104.40	6626.40	4.250	12.000	2025-11-14 06:28:43.931117+00
75	standard	7000.00	6	1464.17	8785.00	175.70	1054.20	1288.47	7730.82	4.250	12.000	2025-11-14 06:28:43.931117+00
76	standard	8000.00	6	1673.33	10040.00	200.80	1204.80	1472.53	8835.18	4.250	12.000	2025-11-14 06:28:43.931117+00
77	standard	9000.00	6	1882.50	11295.00	225.90	1355.40	1656.60	9939.60	4.250	12.000	2025-11-14 06:28:43.931117+00
78	standard	10000.00	6	2091.67	12550.00	251.00	1506.00	1840.67	11044.02	4.250	12.000	2025-11-14 06:28:43.931117+00
79	standard	12000.00	6	2510.00	15060.00	301.20	1807.20	2208.80	13252.80	4.250	12.000	2025-11-14 06:28:43.931117+00
80	standard	15000.00	6	3137.50	18825.00	376.50	2259.00	2761.00	16566.00	4.250	12.000	2025-11-14 06:28:43.931117+00
81	standard	18000.00	6	3765.00	22590.00	451.80	2710.80	3313.20	19879.20	4.250	12.000	2025-11-14 06:28:43.931117+00
82	standard	20000.00	6	4183.33	25100.00	502.00	3012.00	3681.33	22087.98	4.250	12.000	2025-11-14 06:28:43.931117+00
83	standard	25000.00	6	5229.17	31375.00	627.50	3765.00	4601.67	27610.02	4.250	12.000	2025-11-14 06:28:43.931117+00
84	standard	30000.00	6	6275.00	37650.00	753.00	4518.00	5522.00	33132.00	4.250	12.000	2025-11-14 06:28:43.931117+00
85	standard	3000.00	9	460.83	4147.50	55.30	497.70	405.53	3649.77	4.250	12.000	2025-11-14 06:28:43.931117+00
86	standard	4000.00	9	614.44	5530.00	73.73	663.57	540.71	4866.39	4.250	12.000	2025-11-14 06:28:43.931117+00
87	standard	5000.00	9	768.06	6912.50	92.17	829.53	675.89	6083.01	4.250	12.000	2025-11-14 06:28:43.931117+00
88	standard	6000.00	9	921.67	8295.00	110.60	995.40	811.07	7299.63	4.250	12.000	2025-11-14 06:28:43.931117+00
89	standard	7000.00	9	1075.28	9677.50	129.03	1161.27	946.25	8516.25	4.250	12.000	2025-11-14 06:28:43.931117+00
90	standard	8000.00	9	1228.89	11060.00	147.47	1327.23	1081.42	9732.78	4.250	12.000	2025-11-14 06:28:43.931117+00
91	standard	9000.00	9	1382.50	12442.50	165.90	1493.10	1216.60	10949.40	4.250	12.000	2025-11-14 06:28:43.931117+00
92	standard	10000.00	9	1536.11	13825.00	184.33	1658.97	1351.78	12166.02	4.250	12.000	2025-11-14 06:28:43.931117+00
93	standard	12000.00	9	1843.33	16590.00	221.20	1990.80	1622.13	14599.17	4.250	12.000	2025-11-14 06:28:43.931117+00
94	standard	15000.00	9	2304.17	20737.50	276.50	2488.50	2027.67	18249.03	4.250	12.000	2025-11-14 06:28:43.931117+00
95	standard	18000.00	9	2765.00	24885.00	331.80	2986.20	2433.20	21898.80	4.250	12.000	2025-11-14 06:28:43.931117+00
96	standard	20000.00	9	3072.22	27650.00	368.67	3318.03	2703.55	24331.95	4.250	12.000	2025-11-14 06:28:43.931117+00
97	standard	25000.00	9	3840.28	34562.50	460.83	4147.47	3379.45	30415.05	4.250	12.000	2025-11-14 06:28:43.931117+00
98	standard	30000.00	9	4608.33	41475.00	553.00	4977.00	4055.33	36497.97	4.250	12.000	2025-11-14 06:28:43.931117+00
99	standard	3000.00	12	377.50	4530.00	45.30	543.60	332.20	3986.40	4.250	12.000	2025-11-14 06:28:43.931117+00
100	standard	4000.00	12	503.33	6040.00	60.40	724.80	442.93	5315.16	4.250	12.000	2025-11-14 06:28:43.931117+00
101	standard	5000.00	12	629.17	7550.00	75.50	906.00	553.67	6644.04	4.250	12.000	2025-11-14 06:28:43.931117+00
102	standard	6000.00	12	755.00	9060.00	90.60	1087.20	664.40	7972.80	4.250	12.000	2025-11-14 06:28:43.931117+00
103	standard	7000.00	12	880.83	10570.00	105.70	1268.40	775.13	9301.56	4.250	12.000	2025-11-14 06:28:43.931117+00
104	standard	8000.00	12	1006.67	12080.00	120.80	1449.60	885.87	10630.44	4.250	12.000	2025-11-14 06:28:43.931117+00
105	standard	9000.00	12	1132.50	13590.00	135.90	1630.80	996.60	11959.20	4.250	12.000	2025-11-14 06:28:43.931117+00
106	standard	10000.00	12	1258.33	15100.00	151.00	1812.00	1107.33	13287.96	4.250	12.000	2025-11-14 06:28:43.931117+00
107	standard	12000.00	12	1510.00	18120.00	181.20	2174.40	1328.80	15945.60	4.250	12.000	2025-11-14 06:28:43.931117+00
108	standard	15000.00	12	1887.50	22650.00	226.50	2718.00	1661.00	19932.00	4.250	12.000	2025-11-14 06:28:43.931117+00
109	standard	18000.00	12	2265.00	27180.00	271.80	3261.60	1993.20	23918.40	4.250	12.000	2025-11-14 06:28:43.931117+00
110	standard	20000.00	12	2516.67	30200.00	302.00	3624.00	2214.67	26576.04	4.250	12.000	2025-11-14 06:28:43.931117+00
111	standard	25000.00	12	3145.83	37750.00	377.50	4530.00	2768.33	33219.96	4.250	12.000	2025-11-14 06:28:43.931117+00
112	standard	30000.00	12	3775.00	45300.00	453.00	5436.00	3322.00	39864.00	4.250	12.000	2025-11-14 06:28:43.931117+00
113	standard	3000.00	15	327.50	4912.50	39.30	589.50	288.20	4323.00	4.250	12.000	2025-11-14 06:28:43.931117+00
114	standard	4000.00	15	436.67	6550.00	52.40	786.00	384.27	5764.05	4.250	12.000	2025-11-14 06:28:43.931117+00
115	standard	5000.00	15	545.83	8187.50	65.50	982.50	480.33	7204.95	4.250	12.000	2025-11-14 06:28:43.931117+00
116	standard	6000.00	15	655.00	9825.00	78.60	1179.00	576.40	8646.00	4.250	12.000	2025-11-14 06:28:43.931117+00
117	standard	7000.00	15	764.17	11462.50	91.70	1375.50	672.47	10087.05	4.250	12.000	2025-11-14 06:28:43.931117+00
118	standard	8000.00	15	873.33	13100.00	104.80	1572.00	768.53	11527.95	4.250	12.000	2025-11-14 06:28:43.931117+00
119	standard	9000.00	15	982.50	14737.50	117.90	1768.50	864.60	12969.00	4.250	12.000	2025-11-14 06:28:43.931117+00
120	standard	10000.00	15	1091.67	16375.00	131.00	1965.00	960.67	14410.05	4.250	12.000	2025-11-14 06:28:43.931117+00
121	standard	12000.00	15	1310.00	19650.00	157.20	2358.00	1152.80	17292.00	4.250	12.000	2025-11-14 06:28:43.931117+00
122	standard	15000.00	15	1637.50	24562.50	196.50	2947.50	1441.00	21615.00	4.250	12.000	2025-11-14 06:28:43.931117+00
123	standard	18000.00	15	1965.00	29475.00	235.80	3537.00	1729.20	25938.00	4.250	12.000	2025-11-14 06:28:43.931117+00
124	standard	20000.00	15	2183.33	32750.00	262.00	3930.00	1921.33	28819.95	4.250	12.000	2025-11-14 06:28:43.931117+00
125	standard	25000.00	15	2729.17	40937.50	327.50	4912.50	2401.67	36025.05	4.250	12.000	2025-11-14 06:28:43.931117+00
126	standard	30000.00	15	3275.00	49125.00	393.00	5895.00	2882.00	43230.00	4.250	12.000	2025-11-14 06:28:43.931117+00
127	standard	3000.00	18	294.17	5295.00	35.30	635.40	258.87	4659.66	4.250	12.000	2025-11-14 06:28:43.931117+00
128	standard	4000.00	18	392.22	7060.00	47.07	847.26	345.15	6212.70	4.250	12.000	2025-11-14 06:28:43.931117+00
129	standard	5000.00	18	490.28	8825.00	58.83	1058.94	431.45	7766.10	4.250	12.000	2025-11-14 06:28:43.931117+00
130	standard	6000.00	18	588.33	10590.00	70.60	1270.80	517.73	9319.14	4.250	12.000	2025-11-14 06:28:43.931117+00
131	standard	7000.00	18	686.39	12355.00	82.37	1482.66	604.02	10872.36	4.250	12.000	2025-11-14 06:28:43.931117+00
132	standard	8000.00	18	784.44	14120.00	94.13	1694.34	690.31	12425.58	4.250	12.000	2025-11-14 06:28:43.931117+00
133	standard	9000.00	18	882.50	15885.00	105.90	1906.20	776.60	13978.80	4.250	12.000	2025-11-14 06:28:43.931117+00
134	standard	10000.00	18	980.56	17650.00	117.67	2118.06	862.89	15532.02	4.250	12.000	2025-11-14 06:28:43.931117+00
135	standard	12000.00	18	1176.67	21180.00	141.20	2541.60	1035.47	18638.46	4.250	12.000	2025-11-14 06:28:43.931117+00
136	standard	15000.00	18	1470.83	26475.00	176.50	3177.00	1294.33	23297.94	4.250	12.000	2025-11-14 06:28:43.931117+00
137	standard	18000.00	18	1765.00	31770.00	211.80	3812.40	1553.20	27957.60	4.250	12.000	2025-11-14 06:28:43.931117+00
138	standard	20000.00	18	1961.11	35300.00	235.33	4235.94	1725.78	31064.04	4.250	12.000	2025-11-14 06:28:43.931117+00
139	standard	25000.00	18	2451.39	44125.00	294.17	5295.06	2157.22	38829.96	4.250	12.000	2025-11-14 06:28:43.931117+00
140	standard	30000.00	18	2941.67	52950.00	353.00	6354.00	2588.67	46596.06	4.250	12.000	2025-11-14 06:28:43.931117+00
141	standard	3000.00	21	270.36	5677.50	32.44	681.24	237.92	4996.32	4.250	12.000	2025-11-14 06:28:43.931117+00
142	standard	4000.00	21	360.48	7570.00	43.26	908.46	317.22	6661.62	4.250	12.000	2025-11-14 06:28:43.931117+00
143	standard	5000.00	21	450.60	9462.50	54.07	1135.47	396.53	8327.13	4.250	12.000	2025-11-14 06:28:43.931117+00
144	standard	6000.00	21	540.71	11355.00	64.89	1362.69	475.82	9992.22	4.250	12.000	2025-11-14 06:28:43.931117+00
145	standard	7000.00	21	630.83	13247.50	75.70	1589.70	555.13	11657.73	4.250	12.000	2025-11-14 06:28:43.931117+00
146	standard	8000.00	21	720.95	15140.00	86.51	1816.71	634.44	13323.24	4.250	12.000	2025-11-14 06:28:43.931117+00
147	standard	9000.00	21	811.07	17032.50	97.33	2043.93	713.74	14988.54	4.250	12.000	2025-11-14 06:28:43.931117+00
148	standard	10000.00	21	901.19	18925.00	108.14	2270.94	793.05	16654.05	4.250	12.000	2025-11-14 06:28:43.931117+00
149	standard	12000.00	21	1081.43	22710.00	129.77	2725.17	951.66	19984.86	4.250	12.000	2025-11-14 06:28:43.931117+00
150	standard	15000.00	21	1351.79	28387.50	162.21	3406.41	1189.58	24981.18	4.250	12.000	2025-11-14 06:28:43.931117+00
151	standard	18000.00	21	1622.14	34065.00	194.66	4087.86	1427.48	29977.08	4.250	12.000	2025-11-14 06:28:43.931117+00
152	standard	20000.00	21	1802.38	37850.00	216.29	4542.09	1586.09	33307.89	4.250	12.000	2025-11-14 06:28:43.931117+00
153	standard	25000.00	21	2252.98	47312.50	270.36	5677.56	1982.62	41635.02	4.250	12.000	2025-11-14 06:28:43.931117+00
154	standard	30000.00	21	2703.57	56775.00	324.43	6813.03	2379.14	49961.94	4.250	12.000	2025-11-14 06:28:43.931117+00
155	standard	3000.00	24	252.50	6060.00	30.30	727.20	222.20	5332.80	4.250	12.000	2025-11-14 06:28:43.931117+00
156	standard	4000.00	24	336.67	8080.00	40.40	969.60	296.27	7110.48	4.250	12.000	2025-11-14 06:28:43.931117+00
157	standard	5000.00	24	420.83	10100.00	50.50	1212.00	370.33	8887.92	4.250	12.000	2025-11-14 06:28:43.931117+00
158	standard	6000.00	24	505.00	12120.00	60.60	1454.40	444.40	10665.60	4.250	12.000	2025-11-14 06:28:43.931117+00
159	standard	7000.00	24	589.17	14140.00	70.70	1696.80	518.47	12443.28	4.250	12.000	2025-11-14 06:28:43.931117+00
160	standard	8000.00	24	673.33	16160.00	80.80	1939.20	592.53	14220.72	4.250	12.000	2025-11-14 06:28:43.931117+00
161	standard	9000.00	24	757.50	18180.00	90.90	2181.60	666.60	15998.40	4.250	12.000	2025-11-14 06:28:43.931117+00
162	standard	10000.00	24	841.67	20200.00	101.00	2424.00	740.67	17776.08	4.250	12.000	2025-11-14 06:28:43.931117+00
163	standard	12000.00	24	1010.00	24240.00	121.20	2908.80	888.80	21331.20	4.250	12.000	2025-11-14 06:28:43.931117+00
164	standard	15000.00	24	1262.50	30300.00	151.50	3636.00	1111.00	26664.00	4.250	12.000	2025-11-14 06:28:43.931117+00
165	standard	18000.00	24	1515.00	36360.00	181.80	4363.20	1333.20	31996.80	4.250	12.000	2025-11-14 06:28:43.931117+00
166	standard	20000.00	24	1683.33	40400.00	202.00	4848.00	1481.33	35551.92	4.250	12.000	2025-11-14 06:28:43.931117+00
167	standard	25000.00	24	2104.17	50500.00	252.50	6060.00	1851.67	44440.08	4.250	12.000	2025-11-14 06:28:43.931117+00
168	standard	30000.00	24	2525.00	60600.00	303.00	7272.00	2222.00	53328.00	4.250	12.000	2025-11-14 06:28:43.931117+00
169	standard	3000.00	30	227.50	6825.00	27.30	819.00	200.20	6006.00	4.250	12.000	2025-11-14 06:28:43.931117+00
170	standard	4000.00	30	303.33	9100.00	36.40	1092.00	266.93	8007.90	4.250	12.000	2025-11-14 06:28:43.931117+00
171	standard	5000.00	30	379.17	11375.00	45.50	1365.00	333.67	10010.10	4.250	12.000	2025-11-14 06:28:43.931117+00
172	standard	6000.00	30	455.00	13650.00	54.60	1638.00	400.40	12012.00	4.250	12.000	2025-11-14 06:28:43.931117+00
173	standard	7000.00	30	530.83	15925.00	63.70	1911.00	467.13	14013.90	4.250	12.000	2025-11-14 06:28:43.931117+00
174	standard	8000.00	30	606.67	18200.00	72.80	2184.00	533.87	16016.10	4.250	12.000	2025-11-14 06:28:43.931117+00
175	standard	9000.00	30	682.50	20475.00	81.90	2457.00	600.60	18018.00	4.250	12.000	2025-11-14 06:28:43.931117+00
176	standard	10000.00	30	758.33	22750.00	91.00	2730.00	667.33	20019.90	4.250	12.000	2025-11-14 06:28:43.931117+00
177	standard	12000.00	30	910.00	27300.00	109.20	3276.00	800.80	24024.00	4.250	12.000	2025-11-14 06:28:43.931117+00
178	standard	15000.00	30	1137.50	34125.00	136.50	4095.00	1001.00	30030.00	4.250	12.000	2025-11-14 06:28:43.931117+00
179	standard	18000.00	30	1365.00	40950.00	163.80	4914.00	1201.20	36036.00	4.250	12.000	2025-11-14 06:28:43.931117+00
180	standard	20000.00	30	1516.67	45500.00	182.00	5460.00	1334.67	40040.10	4.250	12.000	2025-11-14 06:28:43.931117+00
181	standard	25000.00	30	1895.83	56875.00	227.50	6825.00	1668.33	50049.90	4.250	12.000	2025-11-14 06:28:43.931117+00
182	standard	30000.00	30	2275.00	68250.00	273.00	8190.00	2002.00	60060.00	4.250	12.000	2025-11-14 06:28:43.931117+00
183	standard	3000.00	36	210.83	7590.00	25.30	910.80	185.53	6679.08	4.250	12.000	2025-11-14 06:28:43.931117+00
184	standard	4000.00	36	281.11	10120.00	33.73	1214.28	247.38	8905.68	4.250	12.000	2025-11-14 06:28:43.931117+00
185	standard	5000.00	36	351.39	12650.00	42.17	1518.12	309.22	11131.92	4.250	12.000	2025-11-14 06:28:43.931117+00
186	standard	6000.00	36	421.67	15180.00	50.60	1821.60	371.07	13358.52	4.250	12.000	2025-11-14 06:28:43.931117+00
187	standard	7000.00	36	491.94	17710.00	59.03	2125.08	432.91	15584.76	4.250	12.000	2025-11-14 06:28:43.931117+00
188	standard	8000.00	36	562.22	20240.00	67.47	2428.92	494.75	17811.00	4.250	12.000	2025-11-14 06:28:43.931117+00
189	standard	9000.00	36	632.50	22770.00	75.90	2732.40	556.60	20037.60	4.250	12.000	2025-11-14 06:28:43.931117+00
190	standard	10000.00	36	702.78	25300.00	84.33	3035.88	618.45	22264.20	4.250	12.000	2025-11-14 06:28:43.931117+00
191	standard	12000.00	36	843.33	30360.00	101.20	3643.20	742.13	26716.68	4.250	12.000	2025-11-14 06:28:43.931117+00
192	standard	15000.00	36	1054.17	37950.00	126.50	4554.00	927.67	33396.12	4.250	12.000	2025-11-14 06:28:43.931117+00
193	standard	18000.00	36	1265.00	45540.00	151.80	5464.80	1113.20	40075.20	4.250	12.000	2025-11-14 06:28:43.931117+00
194	standard	20000.00	36	1405.56	50600.00	168.67	6072.12	1236.89	44528.04	4.250	12.000	2025-11-14 06:28:43.931117+00
195	standard	25000.00	36	1756.94	63250.00	210.83	7589.88	1546.11	55659.96	4.250	12.000	2025-11-14 06:28:43.931117+00
196	standard	30000.00	36	2108.33	75900.00	253.00	9108.00	1855.33	66791.88	4.250	12.000	2025-11-14 06:28:43.931117+00
197	premium	3000.00	3	1135.00	3405.00	136.20	408.60	998.80	2996.40	4.500	12.000	2025-11-14 06:28:50.754992+00
198	premium	4000.00	3	1513.33	4540.00	181.60	544.80	1331.73	3995.19	4.500	12.000	2025-11-14 06:28:50.754992+00
199	premium	5000.00	3	1891.67	5675.00	227.00	681.00	1664.67	4994.01	4.500	12.000	2025-11-14 06:28:50.754992+00
200	premium	6000.00	3	2270.00	6810.00	272.40	817.20	1997.60	5992.80	4.500	12.000	2025-11-14 06:28:50.754992+00
201	premium	7000.00	3	2648.33	7945.00	317.80	953.40	2330.53	6991.59	4.500	12.000	2025-11-14 06:28:50.754992+00
202	premium	8000.00	3	3026.67	9080.00	363.20	1089.60	2663.47	7990.41	4.500	12.000	2025-11-14 06:28:50.754992+00
203	premium	9000.00	3	3405.00	10215.00	408.60	1225.80	2996.40	8989.20	4.500	12.000	2025-11-14 06:28:50.754992+00
204	premium	10000.00	3	3783.33	11350.00	454.00	1362.00	3329.33	9987.99	4.500	12.000	2025-11-14 06:28:50.754992+00
205	premium	12000.00	3	4540.00	13620.00	544.80	1634.40	3995.20	11985.60	4.500	12.000	2025-11-14 06:28:50.754992+00
206	premium	15000.00	3	5675.00	17025.00	681.00	2043.00	4994.00	14982.00	4.500	12.000	2025-11-14 06:28:50.754992+00
207	premium	18000.00	3	6810.00	20430.00	817.20	2451.60	5992.80	17978.40	4.500	12.000	2025-11-14 06:28:50.754992+00
208	premium	20000.00	3	7566.67	22700.00	908.00	2724.00	6658.67	19976.01	4.500	12.000	2025-11-14 06:28:50.754992+00
209	premium	25000.00	3	9458.33	28375.00	1135.00	3405.00	8323.33	24969.99	4.500	12.000	2025-11-14 06:28:50.754992+00
210	premium	30000.00	3	11350.00	34050.00	1362.00	4086.00	9988.00	29964.00	4.500	12.000	2025-11-14 06:28:50.754992+00
211	premium	3000.00	6	635.00	3810.00	76.20	457.20	558.80	3352.80	4.500	12.000	2025-11-14 06:28:50.754992+00
212	premium	4000.00	6	846.67	5080.00	101.60	609.60	745.07	4470.42	4.500	12.000	2025-11-14 06:28:50.754992+00
213	premium	5000.00	6	1058.33	6350.00	127.00	762.00	931.33	5587.98	4.500	12.000	2025-11-14 06:28:50.754992+00
214	premium	6000.00	6	1270.00	7620.00	152.40	914.40	1117.60	6705.60	4.500	12.000	2025-11-14 06:28:50.754992+00
215	premium	7000.00	6	1481.67	8890.00	177.80	1066.80	1303.87	7823.22	4.500	12.000	2025-11-14 06:28:50.754992+00
216	premium	8000.00	6	1693.33	10160.00	203.20	1219.20	1490.13	8940.78	4.500	12.000	2025-11-14 06:28:50.754992+00
217	premium	9000.00	6	1905.00	11430.00	228.60	1371.60	1676.40	10058.40	4.500	12.000	2025-11-14 06:28:50.754992+00
218	premium	10000.00	6	2116.67	12700.00	254.00	1524.00	1862.67	11176.02	4.500	12.000	2025-11-14 06:28:50.754992+00
219	premium	12000.00	6	2540.00	15240.00	304.80	1828.80	2235.20	13411.20	4.500	12.000	2025-11-14 06:28:50.754992+00
220	premium	15000.00	6	3175.00	19050.00	381.00	2286.00	2794.00	16764.00	4.500	12.000	2025-11-14 06:28:50.754992+00
221	premium	18000.00	6	3810.00	22860.00	457.20	2743.20	3352.80	20116.80	4.500	12.000	2025-11-14 06:28:50.754992+00
222	premium	20000.00	6	4233.33	25400.00	508.00	3048.00	3725.33	22351.98	4.500	12.000	2025-11-14 06:28:50.754992+00
223	premium	25000.00	6	5291.67	31750.00	635.00	3810.00	4656.67	27940.02	4.500	12.000	2025-11-14 06:28:50.754992+00
224	premium	30000.00	6	6350.00	38100.00	762.00	4572.00	5588.00	33528.00	4.500	12.000	2025-11-14 06:28:50.754992+00
225	premium	3000.00	9	468.33	4215.00	56.20	505.80	412.13	3709.17	4.500	12.000	2025-11-14 06:28:50.754992+00
226	premium	4000.00	9	624.44	5620.00	74.93	674.37	549.51	4945.59	4.500	12.000	2025-11-14 06:28:50.754992+00
227	premium	5000.00	9	780.56	7025.00	93.67	843.03	686.89	6182.01	4.500	12.000	2025-11-14 06:28:50.754992+00
228	premium	6000.00	9	936.67	8430.00	112.40	1011.60	824.27	7418.43	4.500	12.000	2025-11-14 06:28:50.754992+00
229	premium	7000.00	9	1092.78	9835.00	131.13	1180.17	961.65	8654.85	4.500	12.000	2025-11-14 06:28:50.754992+00
230	premium	8000.00	9	1248.89	11240.00	149.87	1348.83	1099.02	9891.18	4.500	12.000	2025-11-14 06:28:50.754992+00
231	premium	9000.00	9	1405.00	12645.00	168.60	1517.40	1236.40	11127.60	4.500	12.000	2025-11-14 06:28:50.754992+00
232	premium	10000.00	9	1561.11	14050.00	187.33	1685.97	1373.78	12364.02	4.500	12.000	2025-11-14 06:28:50.754992+00
233	premium	12000.00	9	1873.33	16860.00	224.80	2023.20	1648.53	14836.77	4.500	12.000	2025-11-14 06:28:50.754992+00
234	premium	15000.00	9	2341.67	21075.00	281.00	2529.00	2060.67	18546.03	4.500	12.000	2025-11-14 06:28:50.754992+00
235	premium	18000.00	9	2810.00	25290.00	337.20	3034.80	2472.80	22255.20	4.500	12.000	2025-11-14 06:28:50.754992+00
236	premium	20000.00	9	3122.22	28100.00	374.67	3372.03	2747.55	24727.95	4.500	12.000	2025-11-14 06:28:50.754992+00
237	premium	25000.00	9	3902.78	35125.00	468.33	4214.97	3434.45	30910.05	4.500	12.000	2025-11-14 06:28:50.754992+00
238	premium	30000.00	9	4683.33	42150.00	562.00	5058.00	4121.33	37091.97	4.500	12.000	2025-11-14 06:28:50.754992+00
239	premium	3000.00	12	385.00	4620.00	46.20	554.40	338.80	4065.60	4.500	12.000	2025-11-14 06:28:50.754992+00
240	premium	4000.00	12	513.33	6160.00	61.60	739.20	451.73	5420.76	4.500	12.000	2025-11-14 06:28:50.754992+00
241	premium	5000.00	12	641.67	7700.00	77.00	924.00	564.67	6776.04	4.500	12.000	2025-11-14 06:28:50.754992+00
242	premium	6000.00	12	770.00	9240.00	92.40	1108.80	677.60	8131.20	4.500	12.000	2025-11-14 06:28:50.754992+00
243	premium	7000.00	12	898.33	10780.00	107.80	1293.60	790.53	9486.36	4.500	12.000	2025-11-14 06:28:50.754992+00
244	premium	8000.00	12	1026.67	12320.00	123.20	1478.40	903.47	10841.64	4.500	12.000	2025-11-14 06:28:50.754992+00
245	premium	9000.00	12	1155.00	13860.00	138.60	1663.20	1016.40	12196.80	4.500	12.000	2025-11-14 06:28:50.754992+00
246	premium	10000.00	12	1283.33	15400.00	154.00	1848.00	1129.33	13551.96	4.500	12.000	2025-11-14 06:28:50.754992+00
247	premium	12000.00	12	1540.00	18480.00	184.80	2217.60	1355.20	16262.40	4.500	12.000	2025-11-14 06:28:50.754992+00
248	premium	15000.00	12	1925.00	23100.00	231.00	2772.00	1694.00	20328.00	4.500	12.000	2025-11-14 06:28:50.754992+00
249	premium	18000.00	12	2310.00	27720.00	277.20	3326.40	2032.80	24393.60	4.500	12.000	2025-11-14 06:28:50.754992+00
250	premium	20000.00	12	2566.67	30800.00	308.00	3696.00	2258.67	27104.04	4.500	12.000	2025-11-14 06:28:50.754992+00
251	premium	25000.00	12	3208.33	38500.00	385.00	4620.00	2823.33	33879.96	4.500	12.000	2025-11-14 06:28:50.754992+00
252	premium	30000.00	12	3850.00	46200.00	462.00	5544.00	3388.00	40656.00	4.500	12.000	2025-11-14 06:28:50.754992+00
253	premium	3000.00	15	335.00	5025.00	40.20	603.00	294.80	4422.00	4.500	12.000	2025-11-14 06:28:50.754992+00
254	premium	4000.00	15	446.67	6700.00	53.60	804.00	393.07	5896.05	4.500	12.000	2025-11-14 06:28:50.754992+00
255	premium	5000.00	15	558.33	8375.00	67.00	1005.00	491.33	7369.95	4.500	12.000	2025-11-14 06:28:50.754992+00
256	premium	6000.00	15	670.00	10050.00	80.40	1206.00	589.60	8844.00	4.500	12.000	2025-11-14 06:28:50.754992+00
257	premium	7000.00	15	781.67	11725.00	93.80	1407.00	687.87	10318.05	4.500	12.000	2025-11-14 06:28:50.754992+00
258	premium	8000.00	15	893.33	13400.00	107.20	1608.00	786.13	11791.95	4.500	12.000	2025-11-14 06:28:50.754992+00
259	premium	9000.00	15	1005.00	15075.00	120.60	1809.00	884.40	13266.00	4.500	12.000	2025-11-14 06:28:50.754992+00
260	premium	10000.00	15	1116.67	16750.00	134.00	2010.00	982.67	14740.05	4.500	12.000	2025-11-14 06:28:50.754992+00
261	premium	12000.00	15	1340.00	20100.00	160.80	2412.00	1179.20	17688.00	4.500	12.000	2025-11-14 06:28:50.754992+00
262	premium	15000.00	15	1675.00	25125.00	201.00	3015.00	1474.00	22110.00	4.500	12.000	2025-11-14 06:28:50.754992+00
263	premium	18000.00	15	2010.00	30150.00	241.20	3618.00	1768.80	26532.00	4.500	12.000	2025-11-14 06:28:50.754992+00
264	premium	20000.00	15	2233.33	33500.00	268.00	4020.00	1965.33	29479.95	4.500	12.000	2025-11-14 06:28:50.754992+00
265	premium	25000.00	15	2791.67	41875.00	335.00	5025.00	2456.67	36850.05	4.500	12.000	2025-11-14 06:28:50.754992+00
266	premium	30000.00	15	3350.00	50250.00	402.00	6030.00	2948.00	44220.00	4.500	12.000	2025-11-14 06:28:50.754992+00
267	premium	3000.00	18	301.67	5430.00	36.20	651.60	265.47	4778.46	4.500	12.000	2025-11-14 06:28:50.754992+00
268	premium	4000.00	18	402.22	7240.00	48.27	868.86	353.95	6371.10	4.500	12.000	2025-11-14 06:28:50.754992+00
269	premium	5000.00	18	502.78	9050.00	60.33	1085.94	442.45	7964.10	4.500	12.000	2025-11-14 06:28:50.754992+00
270	premium	6000.00	18	603.33	10860.00	72.40	1303.20	530.93	9556.74	4.500	12.000	2025-11-14 06:28:50.754992+00
271	premium	7000.00	18	703.89	12670.00	84.47	1520.46	619.42	11149.56	4.500	12.000	2025-11-14 06:28:50.754992+00
272	premium	8000.00	18	804.44	14480.00	96.53	1737.54	707.91	12742.38	4.500	12.000	2025-11-14 06:28:50.754992+00
273	premium	9000.00	18	905.00	16290.00	108.60	1954.80	796.40	14335.20	4.500	12.000	2025-11-14 06:28:50.754992+00
274	premium	10000.00	18	1005.56	18100.00	120.67	2172.06	884.89	15928.02	4.500	12.000	2025-11-14 06:28:50.754992+00
275	premium	12000.00	18	1206.67	21720.00	144.80	2606.40	1061.87	19113.66	4.500	12.000	2025-11-14 06:28:50.754992+00
276	premium	15000.00	18	1508.33	27150.00	181.00	3258.00	1327.33	23891.94	4.500	12.000	2025-11-14 06:28:50.754992+00
277	premium	18000.00	18	1810.00	32580.00	217.20	3909.60	1592.80	28670.40	4.500	12.000	2025-11-14 06:28:50.754992+00
278	premium	20000.00	18	2011.11	36200.00	241.33	4343.94	1769.78	31856.04	4.500	12.000	2025-11-14 06:28:50.754992+00
279	premium	25000.00	18	2513.89	45250.00	301.67	5430.06	2212.22	39819.96	4.500	12.000	2025-11-14 06:28:50.754992+00
280	premium	30000.00	18	3016.67	54300.00	362.00	6516.00	2654.67	47784.06	4.500	12.000	2025-11-14 06:28:50.754992+00
281	premium	3000.00	21	277.86	5835.00	33.34	700.14	244.52	5134.92	4.500	12.000	2025-11-14 06:28:50.754992+00
282	premium	4000.00	21	370.48	7780.00	44.46	933.66	326.02	6846.42	4.500	12.000	2025-11-14 06:28:50.754992+00
283	premium	5000.00	21	463.10	9725.00	55.57	1166.97	407.53	8558.13	4.500	12.000	2025-11-14 06:28:50.754992+00
284	premium	6000.00	21	555.71	11670.00	66.69	1400.49	489.02	10269.42	4.500	12.000	2025-11-14 06:28:50.754992+00
285	premium	7000.00	21	648.33	13615.00	77.80	1633.80	570.53	11981.13	4.500	12.000	2025-11-14 06:28:50.754992+00
286	premium	8000.00	21	740.95	15560.00	88.91	1867.11	652.04	13692.84	4.500	12.000	2025-11-14 06:28:50.754992+00
287	premium	9000.00	21	833.57	17505.00	100.03	2100.63	733.54	15404.34	4.500	12.000	2025-11-14 06:28:50.754992+00
288	premium	10000.00	21	926.19	19450.00	111.14	2333.94	815.05	17116.05	4.500	12.000	2025-11-14 06:28:50.754992+00
289	premium	12000.00	21	1111.43	23340.00	133.37	2800.77	978.06	20539.26	4.500	12.000	2025-11-14 06:28:50.754992+00
290	premium	15000.00	21	1389.29	29175.00	166.71	3500.91	1222.58	25674.18	4.500	12.000	2025-11-14 06:28:50.754992+00
291	premium	18000.00	21	1667.14	35010.00	200.06	4201.26	1467.08	30808.68	4.500	12.000	2025-11-14 06:28:50.754992+00
292	premium	20000.00	21	1852.38	38900.00	222.29	4668.09	1630.09	34231.89	4.500	12.000	2025-11-14 06:28:50.754992+00
293	premium	25000.00	21	2315.48	48625.00	277.86	5835.06	2037.62	42790.02	4.500	12.000	2025-11-14 06:28:50.754992+00
294	premium	30000.00	21	2778.57	58350.00	333.43	7002.03	2445.14	51347.94	4.500	12.000	2025-11-14 06:28:50.754992+00
295	premium	3000.00	24	260.00	6240.00	31.20	748.80	228.80	5491.20	4.500	12.000	2025-11-14 06:28:50.754992+00
296	premium	4000.00	24	346.67	8320.00	41.60	998.40	305.07	7321.68	4.500	12.000	2025-11-14 06:28:50.754992+00
297	premium	5000.00	24	433.33	10400.00	52.00	1248.00	381.33	9151.92	4.500	12.000	2025-11-14 06:28:50.754992+00
298	premium	6000.00	24	520.00	12480.00	62.40	1497.60	457.60	10982.40	4.500	12.000	2025-11-14 06:28:50.754992+00
299	premium	7000.00	24	606.67	14560.00	72.80	1747.20	533.87	12812.88	4.500	12.000	2025-11-14 06:28:50.754992+00
300	premium	8000.00	24	693.33	16640.00	83.20	1996.80	610.13	14643.12	4.500	12.000	2025-11-14 06:28:50.754992+00
301	premium	9000.00	24	780.00	18720.00	93.60	2246.40	686.40	16473.60	4.500	12.000	2025-11-14 06:28:50.754992+00
302	premium	10000.00	24	866.67	20800.00	104.00	2496.00	762.67	18304.08	4.500	12.000	2025-11-14 06:28:50.754992+00
303	premium	12000.00	24	1040.00	24960.00	124.80	2995.20	915.20	21964.80	4.500	12.000	2025-11-14 06:28:50.754992+00
304	premium	15000.00	24	1300.00	31200.00	156.00	3744.00	1144.00	27456.00	4.500	12.000	2025-11-14 06:28:50.754992+00
305	premium	18000.00	24	1560.00	37440.00	187.20	4492.80	1372.80	32947.20	4.500	12.000	2025-11-14 06:28:50.754992+00
306	premium	20000.00	24	1733.33	41600.00	208.00	4992.00	1525.33	36607.92	4.500	12.000	2025-11-14 06:28:50.754992+00
307	premium	25000.00	24	2166.67	52000.00	260.00	6240.00	1906.67	45760.08	4.500	12.000	2025-11-14 06:28:50.754992+00
308	premium	30000.00	24	2600.00	62400.00	312.00	7488.00	2288.00	54912.00	4.500	12.000	2025-11-14 06:28:50.754992+00
309	premium	3000.00	30	235.00	7050.00	28.20	846.00	206.80	6204.00	4.500	12.000	2025-11-14 06:28:50.754992+00
310	premium	4000.00	30	313.33	9400.00	37.60	1128.00	275.73	8271.90	4.500	12.000	2025-11-14 06:28:50.754992+00
311	premium	5000.00	30	391.67	11750.00	47.00	1410.00	344.67	10340.10	4.500	12.000	2025-11-14 06:28:50.754992+00
312	premium	6000.00	30	470.00	14100.00	56.40	1692.00	413.60	12408.00	4.500	12.000	2025-11-14 06:28:50.754992+00
313	premium	7000.00	30	548.33	16450.00	65.80	1974.00	482.53	14475.90	4.500	12.000	2025-11-14 06:28:50.754992+00
314	premium	8000.00	30	626.67	18800.00	75.20	2256.00	551.47	16544.10	4.500	12.000	2025-11-14 06:28:50.754992+00
315	premium	9000.00	30	705.00	21150.00	84.60	2538.00	620.40	18612.00	4.500	12.000	2025-11-14 06:28:50.754992+00
316	premium	10000.00	30	783.33	23500.00	94.00	2820.00	689.33	20679.90	4.500	12.000	2025-11-14 06:28:50.754992+00
317	premium	12000.00	30	940.00	28200.00	112.80	3384.00	827.20	24816.00	4.500	12.000	2025-11-14 06:28:50.754992+00
318	premium	15000.00	30	1175.00	35250.00	141.00	4230.00	1034.00	31020.00	4.500	12.000	2025-11-14 06:28:50.754992+00
319	premium	18000.00	30	1410.00	42300.00	169.20	5076.00	1240.80	37224.00	4.500	12.000	2025-11-14 06:28:50.754992+00
320	premium	20000.00	30	1566.67	47000.00	188.00	5640.00	1378.67	41360.10	4.500	12.000	2025-11-14 06:28:50.754992+00
321	premium	25000.00	30	1958.33	58750.00	235.00	7050.00	1723.33	51699.90	4.500	12.000	2025-11-14 06:28:50.754992+00
322	premium	30000.00	30	2350.00	70500.00	282.00	8460.00	2068.00	62040.00	4.500	12.000	2025-11-14 06:28:50.754992+00
323	premium	3000.00	36	218.33	7860.00	26.20	943.20	192.13	6916.68	4.500	12.000	2025-11-14 06:28:50.754992+00
324	premium	4000.00	36	291.11	10480.00	34.93	1257.48	256.18	9222.48	4.500	12.000	2025-11-14 06:28:50.754992+00
325	premium	5000.00	36	363.89	13100.00	43.67	1572.12	320.22	11527.92	4.500	12.000	2025-11-14 06:28:50.754992+00
326	premium	6000.00	36	436.67	15720.00	52.40	1886.40	384.27	13833.72	4.500	12.000	2025-11-14 06:28:50.754992+00
327	premium	7000.00	36	509.44	18340.00	61.13	2200.68	448.31	16139.16	4.500	12.000	2025-11-14 06:28:50.754992+00
328	premium	8000.00	36	582.22	20960.00	69.87	2515.32	512.35	18444.60	4.500	12.000	2025-11-14 06:28:50.754992+00
329	premium	9000.00	36	655.00	23580.00	78.60	2829.60	576.40	20750.40	4.500	12.000	2025-11-14 06:28:50.754992+00
330	premium	10000.00	36	727.78	26200.00	87.33	3143.88	640.45	23056.20	4.500	12.000	2025-11-14 06:28:50.754992+00
331	premium	12000.00	36	873.33	31440.00	104.80	3772.80	768.53	27667.08	4.500	12.000	2025-11-14 06:28:50.754992+00
332	premium	15000.00	36	1091.67	39300.00	131.00	4716.00	960.67	34584.12	4.500	12.000	2025-11-14 06:28:50.754992+00
333	premium	18000.00	36	1310.00	47160.00	157.20	5659.20	1152.80	41500.80	4.500	12.000	2025-11-14 06:28:50.754992+00
334	premium	20000.00	36	1455.56	52400.00	174.67	6288.12	1280.89	46112.04	4.500	12.000	2025-11-14 06:28:50.754992+00
335	premium	25000.00	36	1819.44	65500.00	218.33	7859.88	1601.11	57639.96	4.500	12.000	2025-11-14 06:28:50.754992+00
336	premium	30000.00	36	2183.33	78600.00	262.00	9432.00	1921.33	69167.88	4.500	12.000	2025-11-14 06:28:50.754992+00
345	standard	22000.00	3	8268.33	24805.00	992.20	2976.60	7276.13	21828.39	4.250	12.000	2025-11-14 07:06:09.511403+00
347	standard	27000.00	3	10147.50	30442.50	1217.70	3653.10	8929.80	26789.40	4.250	12.000	2025-11-14 07:06:09.511403+00
357	standard	22000.00	6	4601.67	27610.00	552.20	3313.20	4049.47	24296.82	4.250	12.000	2025-11-14 07:06:09.511403+00
359	standard	27000.00	6	5647.50	33885.00	677.70	4066.20	4969.80	29818.80	4.250	12.000	2025-11-14 07:06:09.511403+00
369	standard	22000.00	9	3379.44	30415.00	405.53	3649.77	2973.91	26765.19	4.250	12.000	2025-11-14 07:06:09.511403+00
371	standard	27000.00	9	4147.50	37327.50	497.70	4479.30	3649.80	32848.20	4.250	12.000	2025-11-14 07:06:09.511403+00
381	standard	22000.00	12	2768.33	33220.00	332.20	3986.40	2436.13	29233.56	4.250	12.000	2025-11-14 07:06:09.511403+00
383	standard	27000.00	12	3397.50	40770.00	407.70	4892.40	2989.80	35877.60	4.250	12.000	2025-11-14 07:06:09.511403+00
393	standard	22000.00	15	2401.67	36025.00	288.20	4323.00	2113.47	31702.05	4.250	12.000	2025-11-14 07:06:09.511403+00
395	standard	27000.00	15	2947.50	44212.50	353.70	5305.50	2593.80	38907.00	4.250	12.000	2025-11-14 07:06:09.511403+00
405	standard	22000.00	18	2157.22	38830.00	258.87	4659.66	1898.35	34170.30	4.250	12.000	2025-11-14 07:06:09.511403+00
407	standard	27000.00	18	2647.50	47655.00	317.70	5718.60	2329.80	41936.40	4.250	12.000	2025-11-14 07:06:09.511403+00
417	standard	22000.00	21	1982.62	41635.00	237.91	4996.11	1744.71	36638.91	4.250	12.000	2025-11-14 07:06:09.511403+00
419	standard	27000.00	21	2433.21	51097.50	291.99	6131.79	2141.22	44965.62	4.250	12.000	2025-11-14 07:06:09.511403+00
429	standard	22000.00	24	1851.67	44440.00	222.20	5332.80	1629.47	39107.28	4.250	12.000	2025-11-14 07:06:09.511403+00
431	standard	27000.00	24	2272.50	54540.00	272.70	6544.80	1999.80	47995.20	4.250	12.000	2025-11-14 07:06:09.511403+00
441	standard	22000.00	30	1668.33	50050.00	200.20	6006.00	1468.13	44043.90	4.250	12.000	2025-11-14 07:06:09.511403+00
443	standard	27000.00	30	2047.50	61425.00	245.70	7371.00	1801.80	54054.00	4.250	12.000	2025-11-14 07:06:09.511403+00
453	standard	22000.00	36	1546.11	55660.00	185.53	6679.08	1360.58	48980.88	4.250	12.000	2025-11-14 07:06:09.511403+00
455	standard	27000.00	36	1897.50	68310.00	227.70	8197.20	1669.80	60112.80	4.250	12.000	2025-11-14 07:06:09.511403+00
515	legacy	3000.00	12	392.00	4704.00	55.00	660.00	337.00	4044.00	4.733	14.031	2025-11-19 00:39:21.802725+00
516	legacy	4000.00	12	510.00	6120.00	64.00	768.00	446.00	5352.00	4.417	12.549	2025-11-19 00:39:21.802725+00
517	legacy	5000.00	12	633.00	7596.00	80.00	960.00	553.00	6636.00	4.327	12.638	2025-11-19 00:39:21.802725+00
518	legacy	6000.00	12	752.00	9024.00	90.00	1080.00	662.00	7944.00	4.200	11.968	2025-11-19 00:39:21.802725+00
519	legacy	7000.00	12	882.00	10584.00	112.00	1344.00	770.00	9240.00	4.267	12.698	2025-11-19 00:39:21.802725+00
520	legacy	8000.00	12	1006.00	12072.00	128.00	1536.00	878.00	10536.00	4.242	12.724	2025-11-19 00:39:21.802725+00
521	legacy	9000.00	12	1131.00	13572.00	144.00	1728.00	987.00	11844.00	4.233	12.732	2025-11-19 00:39:21.802725+00
522	legacy	10000.00	12	1255.00	15060.00	160.00	1920.00	1095.00	13140.00	4.217	12.749	2025-11-19 00:39:21.802725+00
523	legacy	11000.00	12	1385.00	16620.00	170.00	2040.00	1215.00	14580.00	4.258	12.274	2025-11-19 00:39:21.802725+00
524	legacy	12000.00	12	1504.00	18048.00	180.00	2160.00	1324.00	15888.00	4.200	11.968	2025-11-19 00:39:21.802725+00
525	legacy	13000.00	12	1634.00	19608.00	202.00	2424.00	1432.00	17184.00	4.236	12.362	2025-11-19 00:39:21.802725+00
526	legacy	14000.00	12	1765.00	21180.00	224.00	2688.00	1541.00	18492.00	4.274	12.691	2025-11-19 00:39:21.802725+00
527	legacy	15000.00	12	1888.00	22656.00	240.00	2880.00	1648.00	19776.00	4.253	12.712	2025-11-19 00:39:21.802725+00
528	legacy	16000.00	12	2012.00	24144.00	256.00	3072.00	1756.00	21072.00	4.242	12.724	2025-11-19 00:39:21.802725+00
529	legacy	17000.00	12	2137.00	25644.00	272.00	3264.00	1865.00	22380.00	4.237	12.728	2025-11-19 00:39:21.802725+00
530	legacy	18000.00	12	2262.00	27144.00	288.00	3456.00	1974.00	23688.00	4.233	12.732	2025-11-19 00:39:21.802725+00
531	legacy	19000.00	12	2386.00	28632.00	304.00	3648.00	2082.00	24984.00	4.225	12.741	2025-11-19 00:39:21.802725+00
532	legacy	20000.00	12	2510.00	30120.00	320.00	3840.00	2190.00	26280.00	4.217	12.749	2025-11-19 00:39:21.802725+00
533	legacy	21000.00	12	2640.00	31680.00	330.00	3960.00	2310.00	27720.00	4.238	12.500	2025-11-19 00:39:21.802725+00
534	legacy	22000.00	12	2759.00	33108.00	340.00	4080.00	2419.00	29028.00	4.208	12.323	2025-11-19 00:39:21.802725+00
535	legacy	23000.00	12	2889.00	34668.00	362.00	4344.00	2527.00	30324.00	4.228	12.530	2025-11-19 00:39:21.802725+00
536	legacy	24000.00	12	3020.00	36240.00	384.00	4608.00	2636.00	31632.00	4.250	12.715	2025-11-19 00:39:21.802725+00
537	legacy	25000.00	12	3143.00	37716.00	400.00	4800.00	2743.00	32916.00	4.239	12.727	2025-11-19 00:39:21.802725+00
538	legacy	26000.00	12	3267.00	39204.00	416.00	4992.00	2851.00	34212.00	4.232	12.733	2025-11-19 00:39:21.802725+00
539	legacy	27000.00	12	3392.00	40704.00	432.00	5184.00	2960.00	35520.00	4.230	12.736	2025-11-19 00:39:21.802725+00
540	legacy	28000.00	12	3517.00	42204.00	448.00	5376.00	3069.00	36828.00	4.227	12.738	2025-11-19 00:39:21.802725+00
541	legacy	29000.00	12	3641.00	43692.00	464.00	5568.00	3177.00	38124.00	4.222	12.744	2025-11-19 00:39:21.802725+00
542	legacy	30000.00	12	3765.00	45180.00	480.00	5760.00	3285.00	39420.00	4.217	12.749	2025-11-19 00:39:21.802725+00
\.


--
-- TOC entry 4403 (class 0 OID 16820)
-- Dependencies: 284
-- Data for Name: rate_profiles; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.rate_profiles (id, code, name, description, calculation_type, interest_rate_percent, enabled, is_recommended, display_order, min_amount, max_amount, valid_terms, created_at, updated_at, created_by, updated_by, commission_rate_percent) FROM stdin;
1	legacy	Tabla Histórica v2.0	Sistema actual con montos predefinidos en tabla. Totalmente editable por admin. Permite agregar nuevos montos como $7,500, $12,350, etc.	table_lookup	\N	t	f	1	\N	\N	{12}	2025-11-05 00:58:16.105135+00	2025-11-05 00:58:16.105135+00	\N	\N	\N
3	standard	Estándar - Recomendado ⭐	Balance óptimo entre competitividad y rentabilidad. Tasa ~51% total (12Q), similar al promedio actual. Recomendado para mayoría de casos.	formula	4.250	t	t	3	\N	\N	{3,6,9,12,15,18,21,24,30,36}	2025-11-05 00:58:16.105135+00	2025-11-25 11:34:00.499195+00	\N	\N	1.600
2	transition	Transición Suave 3.75%	Tasa reducida para facilitar adopción gradual. Cliente ahorra vs tabla actual. Ideal para primeros 6 meses de migración.	formula	3.750	f	f	2	\N	\N	{6,12,18,24}	2025-11-05 00:58:16.105135+00	2025-11-05 00:58:16.105135+00	\N	\N	12.000
4	premium	Premium 4.5%	Tasa objetivo con máxima rentabilidad (54% total en 12Q). Mantiene competitividad vs mercado (60-80%). Activar desde mes 7+ de migración.	formula	4.500	f	f	4	\N	\N	{3,6,9,12,15,18,21,24,30,36}	2025-11-05 00:58:16.105135+00	2025-11-05 00:58:16.105135+00	\N	\N	12.000
5	custom	Personalizado	Tasa ajustable manualmente para casos especiales. Requiere aprobación de gerente/admin. Rango permitido: 2.0% - 6.0% quincenal.	formula	4.250	t	f	5	\N	\N	{3,6,9,12,15,18,21,24,30,36}	2025-11-05 00:58:16.105135+00	2025-11-05 00:58:16.105135+00	\N	\N	1.600
\.


--
-- TOC entry 4405 (class 0 OID 16832)
-- Dependencies: 286
-- Data for Name: relationships; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.relationships (id, name, description, active, created_at, updated_at) FROM stdin;
1	Padre	Padre del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
2	Madre	Madre del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
3	Hijo	Hijo del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
4	Hija	Hija del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
5	Hermano	Hermano del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
6	Hermana	Hermana del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
7	Esposo	Esposo del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
8	Esposa	Esposa del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
9	Abuelo	Abuelo del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
10	Abuela	Abuela del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
11	Tío	Tío del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
12	Tía	Tía del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
13	Primo	Primo del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
14	Prima	Prima del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
15	Sobrino	Sobrino del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
16	Sobrina	Sobrina del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
17	Amigo	Amigo del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
18	Amiga	Amiga del titular	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
19	Otro	Otra relación no especificada	t	2025-11-13 11:08:51.909367+00	2025-11-13 11:08:51.909367+00
\.


--
-- TOC entry 4407 (class 0 OID 16841)
-- Dependencies: 288
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.roles (id, name, description, created_at) FROM stdin;
1	desarrollador	\N	2025-10-31 01:12:22.07323+00
2	administrador	\N	2025-10-31 01:12:22.07323+00
3	auxiliar_administrativo	\N	2025-10-31 01:12:22.07323+00
4	asociado	\N	2025-10-31 01:12:22.07323+00
5	cliente	\N	2025-10-31 01:12:22.07323+00
\.


--
-- TOC entry 4409 (class 0 OID 16848)
-- Dependencies: 290
-- Data for Name: statement_statuses; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.statement_statuses (id, name, description, is_paid, display_order, color_code, created_at, updated_at) FROM stdin;
6	DRAFT	BORRADOR - Vista preliminar editable. Admin puede ajustar antes de cerrar corte.	f	0	#FFC107	2025-11-26 20:11:34.098392+00	2025-12-04 08:30:19.259578+00
3	PAID	PAGADO - Asociado pagó completamente a CrediCuenta.	t	2	#4CAF50	2025-10-31 01:12:22.084329+00	2025-12-04 08:30:19.259578+00
1	GENERATED	DEPRECADO - Usar FINALIZED en su lugar.	f	99	#9E9E9E	2025-10-31 01:12:22.084329+00	2025-12-04 08:30:19.259578+00
2	SENT	DEPRECADO - Usar flag sent_date en statement.	f	99	#2196F3	2025-10-31 01:12:22.084329+00	2025-12-04 08:30:19.259578+00
7	COLLECTING	EN COBRO - Statement oficial, esperando pago del asociado a CrediCuenta.	f	1	#2196F3	2025-11-26 20:11:34.098392+00	2025-12-04 09:17:25.171181+00
9	SETTLING	EN LIQUIDACIÓN - Período en proceso de cierre, último esfuerzo de cobro.	f	5	#9C27B0	2025-12-18 06:17:27.755561+00	2025-12-18 06:17:27.755561+00
10	CLOSED	CERRADO - Período cerrado definitivamente.	f	6	#455A64	2025-12-18 06:17:27.755561+00	2025-12-18 06:17:27.755561+00
8	ABSORBED	DEPRECADO - ABSORBIDO - Deuda transferida al balance acumulado del asociado.	f	99	#607D8B	2025-12-04 08:30:19.259578+00	2025-12-18 06:17:27.755561+00
5	OVERDUE	DEPRECADO - VENCIDO - Período terminó sin pago completo del asociado.	f	99	#F44336	2025-10-31 01:12:22.084329+00	2025-12-18 06:17:27.755561+00
4	PARTIAL	DEPRECADO - PAGO PARCIAL - Asociado realizó abono parcial, saldo pendiente.	f	99	#FF9800	2025-10-31 01:12:22.084329+00	2025-12-18 06:17:27.755561+00
\.


--
-- TOC entry 4411 (class 0 OID 16858)
-- Dependencies: 292
-- Data for Name: system_configurations; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.system_configurations (id, config_key, config_value, description, config_type_id, updated_by, created_at, updated_at) FROM stdin;
1	max_loan_amount	1000000	Monto máximo de préstamo permitido	2	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
2	default_interest_rate	2.5	Tasa de interés por defecto	2	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
3	default_commission_rate	2.5	Tasa de comisión por defecto	2	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
4	system_name	Credinet	Nombre del sistema	1	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
5	maintenance_mode	false	Modo de mantenimiento	3	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
6	payment_system	BIWEEKLY_v2.0	Sistema de pagos quincenal v2.0	1	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
7	perfect_dates_enabled	true	Fechas perfectas (día 15 y último)	3	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
8	cut_days	8,23	Días de corte exactos	1	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
9	payment_days	15,LAST	Días de pago permitidos	1	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
10	db_version	2.0.0	Versión de base de datos	1	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
\.


--
-- TOC entry 4413 (class 0 OID 16866)
-- Dependencies: 294
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.user_roles (user_id, role_id, created_at) FROM stdin;
1	1	2025-10-31 01:12:22.092816+00
2	2	2025-10-31 01:12:22.092816+00
3	5	2026-01-20 06:39:09.119045+00
4	4	2026-01-21 08:05:34.979937+00
\.


--
-- TOC entry 4414 (class 0 OID 16870)
-- Dependencies: 295
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: credinet_user
--

COPY public.users (id, username, password_hash, first_name, last_name, email, phone_number, birth_date, curp, profile_picture_url, created_at, updated_at, active) FROM stdin;
1	jair	$2b$12$aSMdt0Kd8I2lrCIvSNbxx.X5U.BmY9MAZAoPvM/MgK5mXOxQgq0s6	Jair	FC	jair@dev.com	5511223344	1990-01-15	FERJ900115HDFXXX01	\N	2025-10-31 01:12:22.089593+00	2025-10-31 01:12:22.089593+00	t
2	admin	$2b$12$ywgRfgZMquHfEX/2EhS13uvK2DYNm.dumTbdoE31CMdtbw89zMCju	Admin	Total	admin@credinet.com	5522334455	\N	\N	\N	2025-10-31 01:12:22.089593+00	2025-12-09 07:02:22.076105+00	t
3	jairnoel.franco	$2b$12$tE8axGk0UCn8QgdZiRKR0ueHhURSuUOLNJv3zkjhjBk1zfTvxAsmW	Jair Noel	Franco Cruz	francojair81@gmail.com	6143618298	1995-05-25	FACJ950525HCHRRR04	\N	2026-01-20 06:39:09.119045+00	2026-01-20 06:39:09.119045+00	t
4	maria.cruz	$2b$12$KsBaPRvGl4PrCFo4PQUfzOPhfvKTjUUPmYb0Oyoo/Z5E9gUmR/G.q	Maria	Cruz Escobedo	maria.c@credinet.temp	6142772794	1964-08-15	CUEM640815MCHRSR02	\N	2026-01-21 08:05:34.979937+00	2026-01-21 08:05:34.979937+00	t
\.


--
-- TOC entry 4617 (class 0 OID 0)
-- Dependencies: 215
-- Name: addresses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.addresses_id_seq', 3, true);


--
-- TOC entry 4618 (class 0 OID 0)
-- Dependencies: 217
-- Name: agreement_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.agreement_items_id_seq', 1, false);


--
-- TOC entry 4619 (class 0 OID 0)
-- Dependencies: 219
-- Name: agreement_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.agreement_payments_id_seq', 1, false);


--
-- TOC entry 4620 (class 0 OID 0)
-- Dependencies: 221
-- Name: agreements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.agreements_id_seq', 1, false);


--
-- TOC entry 4621 (class 0 OID 0)
-- Dependencies: 223
-- Name: associate_accumulated_balances_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.associate_accumulated_balances_id_seq', 1, false);


--
-- TOC entry 4622 (class 0 OID 0)
-- Dependencies: 225
-- Name: associate_debt_breakdown_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.associate_debt_breakdown_id_seq', 1, false);


--
-- TOC entry 4623 (class 0 OID 0)
-- Dependencies: 227
-- Name: associate_debt_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.associate_debt_payments_id_seq', 1, false);


--
-- TOC entry 4624 (class 0 OID 0)
-- Dependencies: 229
-- Name: associate_level_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.associate_level_history_id_seq', 1, false);


--
-- TOC entry 4625 (class 0 OID 0)
-- Dependencies: 231
-- Name: associate_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.associate_levels_id_seq', 1, false);


--
-- TOC entry 4626 (class 0 OID 0)
-- Dependencies: 233
-- Name: associate_payment_statements_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.associate_payment_statements_id_seq', 2, true);


--
-- TOC entry 4627 (class 0 OID 0)
-- Dependencies: 235
-- Name: associate_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.associate_profiles_id_seq', 2, true);


--
-- TOC entry 4628 (class 0 OID 0)
-- Dependencies: 237
-- Name: associate_statement_payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.associate_statement_payments_id_seq', 1, true);


--
-- TOC entry 4629 (class 0 OID 0)
-- Dependencies: 239
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 50, true);


--
-- TOC entry 4630 (class 0 OID 0)
-- Dependencies: 241
-- Name: audit_session_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.audit_session_log_id_seq', 1, false);


--
-- TOC entry 4631 (class 0 OID 0)
-- Dependencies: 243
-- Name: beneficiaries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.beneficiaries_id_seq', 3, true);


--
-- TOC entry 4632 (class 0 OID 0)
-- Dependencies: 245
-- Name: client_documents_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.client_documents_id_seq', 1, false);


--
-- TOC entry 4633 (class 0 OID 0)
-- Dependencies: 247
-- Name: config_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.config_types_id_seq', 8, true);


--
-- TOC entry 4634 (class 0 OID 0)
-- Dependencies: 249
-- Name: contract_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.contract_statuses_id_seq', 6, true);


--
-- TOC entry 4635 (class 0 OID 0)
-- Dependencies: 251
-- Name: contracts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.contracts_id_seq', 1, false);


--
-- TOC entry 4636 (class 0 OID 0)
-- Dependencies: 253
-- Name: cut_period_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.cut_period_statuses_id_seq', 6, true);


--
-- TOC entry 4637 (class 0 OID 0)
-- Dependencies: 255
-- Name: cut_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.cut_periods_id_seq', 120, true);


--
-- TOC entry 4638 (class 0 OID 0)
-- Dependencies: 257
-- Name: defaulted_client_reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.defaulted_client_reports_id_seq', 1, false);


--
-- TOC entry 4639 (class 0 OID 0)
-- Dependencies: 259
-- Name: document_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.document_statuses_id_seq', 4, true);


--
-- TOC entry 4640 (class 0 OID 0)
-- Dependencies: 261
-- Name: document_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.document_types_id_seq', 1, false);


--
-- TOC entry 4641 (class 0 OID 0)
-- Dependencies: 263
-- Name: guarantors_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.guarantors_id_seq', 3, true);


--
-- TOC entry 4642 (class 0 OID 0)
-- Dependencies: 265
-- Name: legacy_payment_table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.legacy_payment_table_id_seq', 30, true);


--
-- TOC entry 4643 (class 0 OID 0)
-- Dependencies: 267
-- Name: level_change_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.level_change_types_id_seq', 6, true);


--
-- TOC entry 4644 (class 0 OID 0)
-- Dependencies: 269
-- Name: loan_renewals_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.loan_renewals_id_seq', 1, false);


--
-- TOC entry 4645 (class 0 OID 0)
-- Dependencies: 271
-- Name: loan_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.loan_statuses_id_seq', 8, true);


--
-- TOC entry 4646 (class 0 OID 0)
-- Dependencies: 273
-- Name: loans_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.loans_id_seq', 3, true);


--
-- TOC entry 4647 (class 0 OID 0)
-- Dependencies: 275
-- Name: payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.payment_methods_id_seq', 7, true);


--
-- TOC entry 4648 (class 0 OID 0)
-- Dependencies: 277
-- Name: payment_status_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.payment_status_history_id_seq', 1, false);


--
-- TOC entry 4649 (class 0 OID 0)
-- Dependencies: 279
-- Name: payment_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.payment_statuses_id_seq', 1, false);


--
-- TOC entry 4650 (class 0 OID 0)
-- Dependencies: 281
-- Name: payments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.payments_id_seq', 33, true);


--
-- TOC entry 4651 (class 0 OID 0)
-- Dependencies: 283
-- Name: rate_profile_reference_table_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.rate_profile_reference_table_id_seq', 542, true);


--
-- TOC entry 4652 (class 0 OID 0)
-- Dependencies: 285
-- Name: rate_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.rate_profiles_id_seq', 6, true);


--
-- TOC entry 4653 (class 0 OID 0)
-- Dependencies: 287
-- Name: relationships_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.relationships_id_seq', 19, true);


--
-- TOC entry 4654 (class 0 OID 0)
-- Dependencies: 289
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.roles_id_seq', 6, false);


--
-- TOC entry 4655 (class 0 OID 0)
-- Dependencies: 291
-- Name: statement_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.statement_statuses_id_seq', 6, true);


--
-- TOC entry 4656 (class 0 OID 0)
-- Dependencies: 293
-- Name: system_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.system_configurations_id_seq', 10, true);


--
-- TOC entry 4657 (class 0 OID 0)
-- Dependencies: 296
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: credinet_user
--

SELECT pg_catalog.setval('public.users_id_seq', 4, true);


--
-- TOC entry 3823 (class 2606 OID 17002)
-- Name: addresses addresses_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_pkey PRIMARY KEY (id);


--
-- TOC entry 3825 (class 2606 OID 17004)
-- Name: addresses addresses_user_id_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_user_id_key UNIQUE (user_id);


--
-- TOC entry 3827 (class 2606 OID 17006)
-- Name: agreement_items agreement_items_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreement_items
    ADD CONSTRAINT agreement_items_pkey PRIMARY KEY (id);


--
-- TOC entry 3831 (class 2606 OID 17008)
-- Name: agreement_payments agreement_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreement_payments
    ADD CONSTRAINT agreement_payments_pkey PRIMARY KEY (id);


--
-- TOC entry 3835 (class 2606 OID 17010)
-- Name: agreements agreements_agreement_number_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreements
    ADD CONSTRAINT agreements_agreement_number_key UNIQUE (agreement_number);


--
-- TOC entry 3837 (class 2606 OID 17012)
-- Name: agreements agreements_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreements
    ADD CONSTRAINT agreements_pkey PRIMARY KEY (id);


--
-- TOC entry 3841 (class 2606 OID 17014)
-- Name: associate_accumulated_balances associate_accumulated_balances_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_accumulated_balances
    ADD CONSTRAINT associate_accumulated_balances_pkey PRIMARY KEY (id);


--
-- TOC entry 3843 (class 2606 OID 17016)
-- Name: associate_accumulated_balances associate_accumulated_balances_user_id_cut_period_id_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_accumulated_balances
    ADD CONSTRAINT associate_accumulated_balances_user_id_cut_period_id_key UNIQUE (user_id, cut_period_id);


--
-- TOC entry 3845 (class 2606 OID 17018)
-- Name: associate_debt_breakdown associate_debt_breakdown_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_breakdown
    ADD CONSTRAINT associate_debt_breakdown_pkey PRIMARY KEY (id);


--
-- TOC entry 3849 (class 2606 OID 17020)
-- Name: associate_debt_payments associate_debt_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_payments
    ADD CONSTRAINT associate_debt_payments_pkey PRIMARY KEY (id);


--
-- TOC entry 3857 (class 2606 OID 17022)
-- Name: associate_level_history associate_level_history_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_level_history
    ADD CONSTRAINT associate_level_history_pkey PRIMARY KEY (id);


--
-- TOC entry 3859 (class 2606 OID 17024)
-- Name: associate_levels associate_levels_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_levels
    ADD CONSTRAINT associate_levels_name_key UNIQUE (name);


--
-- TOC entry 3861 (class 2606 OID 17026)
-- Name: associate_levels associate_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_levels
    ADD CONSTRAINT associate_levels_pkey PRIMARY KEY (id);


--
-- TOC entry 3863 (class 2606 OID 17028)
-- Name: associate_payment_statements associate_payment_statements_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_payment_statements
    ADD CONSTRAINT associate_payment_statements_pkey PRIMARY KEY (id);


--
-- TOC entry 3865 (class 2606 OID 17030)
-- Name: associate_profiles associate_profiles_contact_email_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_profiles
    ADD CONSTRAINT associate_profiles_contact_email_key UNIQUE (contact_email);


--
-- TOC entry 3867 (class 2606 OID 17032)
-- Name: associate_profiles associate_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_profiles
    ADD CONSTRAINT associate_profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 3869 (class 2606 OID 17034)
-- Name: associate_profiles associate_profiles_user_id_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_profiles
    ADD CONSTRAINT associate_profiles_user_id_key UNIQUE (user_id);


--
-- TOC entry 3875 (class 2606 OID 17036)
-- Name: associate_statement_payments associate_statement_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_statement_payments
    ADD CONSTRAINT associate_statement_payments_pkey PRIMARY KEY (id);


--
-- TOC entry 3882 (class 2606 OID 17038)
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3888 (class 2606 OID 17040)
-- Name: audit_session_log audit_session_log_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.audit_session_log
    ADD CONSTRAINT audit_session_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3893 (class 2606 OID 17042)
-- Name: beneficiaries beneficiaries_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.beneficiaries
    ADD CONSTRAINT beneficiaries_pkey PRIMARY KEY (id);


--
-- TOC entry 3895 (class 2606 OID 17044)
-- Name: beneficiaries beneficiaries_user_id_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.beneficiaries
    ADD CONSTRAINT beneficiaries_user_id_key UNIQUE (user_id);


--
-- TOC entry 3898 (class 2606 OID 17046)
-- Name: client_documents client_documents_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.client_documents
    ADD CONSTRAINT client_documents_pkey PRIMARY KEY (id);


--
-- TOC entry 3902 (class 2606 OID 17048)
-- Name: config_types config_types_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.config_types
    ADD CONSTRAINT config_types_name_key UNIQUE (name);


--
-- TOC entry 3904 (class 2606 OID 17050)
-- Name: config_types config_types_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.config_types
    ADD CONSTRAINT config_types_pkey PRIMARY KEY (id);


--
-- TOC entry 3907 (class 2606 OID 17052)
-- Name: contract_statuses contract_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.contract_statuses
    ADD CONSTRAINT contract_statuses_name_key UNIQUE (name);


--
-- TOC entry 3909 (class 2606 OID 17054)
-- Name: contract_statuses contract_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.contract_statuses
    ADD CONSTRAINT contract_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 3912 (class 2606 OID 17056)
-- Name: contracts contracts_document_number_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_document_number_key UNIQUE (document_number);


--
-- TOC entry 3914 (class 2606 OID 17058)
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- TOC entry 3918 (class 2606 OID 17060)
-- Name: cut_period_statuses cut_period_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.cut_period_statuses
    ADD CONSTRAINT cut_period_statuses_name_key UNIQUE (name);


--
-- TOC entry 3920 (class 2606 OID 17062)
-- Name: cut_period_statuses cut_period_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.cut_period_statuses
    ADD CONSTRAINT cut_period_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 3923 (class 2606 OID 17064)
-- Name: cut_periods cut_periods_cut_code_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.cut_periods
    ADD CONSTRAINT cut_periods_cut_code_key UNIQUE (cut_code);


--
-- TOC entry 3925 (class 2606 OID 17066)
-- Name: cut_periods cut_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.cut_periods
    ADD CONSTRAINT cut_periods_pkey PRIMARY KEY (id);


--
-- TOC entry 3931 (class 2606 OID 17068)
-- Name: defaulted_client_reports defaulted_client_reports_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.defaulted_client_reports
    ADD CONSTRAINT defaulted_client_reports_pkey PRIMARY KEY (id);


--
-- TOC entry 3938 (class 2606 OID 17070)
-- Name: document_statuses document_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.document_statuses
    ADD CONSTRAINT document_statuses_name_key UNIQUE (name);


--
-- TOC entry 3940 (class 2606 OID 17072)
-- Name: document_statuses document_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.document_statuses
    ADD CONSTRAINT document_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 3943 (class 2606 OID 17074)
-- Name: document_types document_types_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_name_key UNIQUE (name);


--
-- TOC entry 3945 (class 2606 OID 17076)
-- Name: document_types document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_pkey PRIMARY KEY (id);


--
-- TOC entry 3947 (class 2606 OID 17078)
-- Name: guarantors guarantors_curp_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.guarantors
    ADD CONSTRAINT guarantors_curp_key UNIQUE (curp);


--
-- TOC entry 3949 (class 2606 OID 17080)
-- Name: guarantors guarantors_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.guarantors
    ADD CONSTRAINT guarantors_pkey PRIMARY KEY (id);


--
-- TOC entry 3951 (class 2606 OID 17082)
-- Name: guarantors guarantors_user_id_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.guarantors
    ADD CONSTRAINT guarantors_user_id_key UNIQUE (user_id);


--
-- TOC entry 3957 (class 2606 OID 17084)
-- Name: legacy_payment_table legacy_payment_table_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.legacy_payment_table
    ADD CONSTRAINT legacy_payment_table_pkey PRIMARY KEY (id);


--
-- TOC entry 3962 (class 2606 OID 17086)
-- Name: level_change_types level_change_types_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.level_change_types
    ADD CONSTRAINT level_change_types_name_key UNIQUE (name);


--
-- TOC entry 3964 (class 2606 OID 17088)
-- Name: level_change_types level_change_types_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.level_change_types
    ADD CONSTRAINT level_change_types_pkey PRIMARY KEY (id);


--
-- TOC entry 3968 (class 2606 OID 17090)
-- Name: loan_renewals loan_renewals_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loan_renewals
    ADD CONSTRAINT loan_renewals_pkey PRIMARY KEY (id);


--
-- TOC entry 3972 (class 2606 OID 17092)
-- Name: loan_statuses loan_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loan_statuses
    ADD CONSTRAINT loan_statuses_name_key UNIQUE (name);


--
-- TOC entry 3974 (class 2606 OID 17094)
-- Name: loan_statuses loan_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loan_statuses
    ADD CONSTRAINT loan_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 3984 (class 2606 OID 17096)
-- Name: loans loans_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT loans_pkey PRIMARY KEY (id);


--
-- TOC entry 3987 (class 2606 OID 17098)
-- Name: payment_methods payment_methods_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_name_key UNIQUE (name);


--
-- TOC entry 3989 (class 2606 OID 17100)
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- TOC entry 3997 (class 2606 OID 17102)
-- Name: payment_status_history payment_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_pkey PRIMARY KEY (id);


--
-- TOC entry 4002 (class 2606 OID 17104)
-- Name: payment_statuses payment_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_statuses
    ADD CONSTRAINT payment_statuses_name_key UNIQUE (name);


--
-- TOC entry 4004 (class 2606 OID 17106)
-- Name: payment_statuses payment_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_statuses
    ADD CONSTRAINT payment_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 4017 (class 2606 OID 17108)
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- TOC entry 4019 (class 2606 OID 17110)
-- Name: rate_profile_reference_table rate_profile_reference_table_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.rate_profile_reference_table
    ADD CONSTRAINT rate_profile_reference_table_pkey PRIMARY KEY (id);


--
-- TOC entry 4026 (class 2606 OID 17112)
-- Name: rate_profiles rate_profiles_code_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.rate_profiles
    ADD CONSTRAINT rate_profiles_code_key UNIQUE (code);


--
-- TOC entry 4028 (class 2606 OID 17114)
-- Name: rate_profiles rate_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.rate_profiles
    ADD CONSTRAINT rate_profiles_pkey PRIMARY KEY (id);


--
-- TOC entry 4030 (class 2606 OID 17116)
-- Name: relationships relationships_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.relationships
    ADD CONSTRAINT relationships_name_key UNIQUE (name);


--
-- TOC entry 4032 (class 2606 OID 17118)
-- Name: relationships relationships_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.relationships
    ADD CONSTRAINT relationships_pkey PRIMARY KEY (id);


--
-- TOC entry 4034 (class 2606 OID 17120)
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- TOC entry 4036 (class 2606 OID 17122)
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- TOC entry 4039 (class 2606 OID 17124)
-- Name: statement_statuses statement_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.statement_statuses
    ADD CONSTRAINT statement_statuses_name_key UNIQUE (name);


--
-- TOC entry 4041 (class 2606 OID 17126)
-- Name: statement_statuses statement_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.statement_statuses
    ADD CONSTRAINT statement_statuses_pkey PRIMARY KEY (id);


--
-- TOC entry 4043 (class 2606 OID 17128)
-- Name: system_configurations system_configurations_config_key_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT system_configurations_config_key_key UNIQUE (config_key);


--
-- TOC entry 4045 (class 2606 OID 17130)
-- Name: system_configurations system_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT system_configurations_pkey PRIMARY KEY (id);


--
-- TOC entry 3959 (class 2606 OID 17132)
-- Name: legacy_payment_table uq_legacy_amount_term; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.legacy_payment_table
    ADD CONSTRAINT uq_legacy_amount_term UNIQUE (amount, term_biweeks);


--
-- TOC entry 4021 (class 2606 OID 17134)
-- Name: rate_profile_reference_table uq_profile_amount_term; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.rate_profile_reference_table
    ADD CONSTRAINT uq_profile_amount_term UNIQUE (profile_code, amount, term_biweeks);


--
-- TOC entry 4047 (class 2606 OID 17136)
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- TOC entry 4052 (class 2606 OID 17138)
-- Name: users users_curp_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_curp_key UNIQUE (curp);


--
-- TOC entry 4054 (class 2606 OID 17140)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- TOC entry 4056 (class 2606 OID 17142)
-- Name: users users_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_number_key UNIQUE (phone_number);


--
-- TOC entry 4058 (class 2606 OID 17144)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 4060 (class 2606 OID 17146)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3828 (class 1259 OID 17147)
-- Name: idx_agreement_items_agreement_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_agreement_items_agreement_id ON public.agreement_items USING btree (agreement_id);


--
-- TOC entry 3829 (class 1259 OID 17148)
-- Name: idx_agreement_items_loan_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_agreement_items_loan_id ON public.agreement_items USING btree (loan_id);


--
-- TOC entry 3832 (class 1259 OID 17149)
-- Name: idx_agreement_payments_agreement_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_agreement_payments_agreement_id ON public.agreement_payments USING btree (agreement_id);


--
-- TOC entry 3833 (class 1259 OID 17150)
-- Name: idx_agreement_payments_status; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_agreement_payments_status ON public.agreement_payments USING btree (status);


--
-- TOC entry 3838 (class 1259 OID 17151)
-- Name: idx_agreements_associate_profile_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_agreements_associate_profile_id ON public.agreements USING btree (associate_profile_id);


--
-- TOC entry 3839 (class 1259 OID 17152)
-- Name: idx_agreements_status; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_agreements_status ON public.agreements USING btree (status);


--
-- TOC entry 3870 (class 1259 OID 17153)
-- Name: idx_associate_profiles_active; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_associate_profiles_active ON public.associate_profiles USING btree (active);


--
-- TOC entry 3871 (class 1259 OID 17154)
-- Name: idx_associate_profiles_credit_used; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_associate_profiles_credit_used ON public.associate_profiles USING btree (pending_payments_total);


--
-- TOC entry 3872 (class 1259 OID 17155)
-- Name: idx_associate_profiles_level_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_associate_profiles_level_id ON public.associate_profiles USING btree (level_id);


--
-- TOC entry 3873 (class 1259 OID 17156)
-- Name: idx_associate_profiles_user_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_associate_profiles_user_id ON public.associate_profiles USING btree (user_id);


--
-- TOC entry 3883 (class 1259 OID 17157)
-- Name: idx_audit_log_changed_at; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_audit_log_changed_at ON public.audit_log USING btree (changed_at);


--
-- TOC entry 3884 (class 1259 OID 17158)
-- Name: idx_audit_log_changed_by; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_audit_log_changed_by ON public.audit_log USING btree (changed_by);


--
-- TOC entry 3885 (class 1259 OID 17159)
-- Name: idx_audit_log_operation; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_audit_log_operation ON public.audit_log USING btree (operation);


--
-- TOC entry 3886 (class 1259 OID 17160)
-- Name: idx_audit_log_table_record; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_audit_log_table_record ON public.audit_log USING btree (table_name, record_id);


--
-- TOC entry 3896 (class 1259 OID 17161)
-- Name: idx_beneficiaries_relationship_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_beneficiaries_relationship_id ON public.beneficiaries USING btree (relationship_id);


--
-- TOC entry 3899 (class 1259 OID 17162)
-- Name: idx_client_documents_status_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_client_documents_status_id ON public.client_documents USING btree (status_id);


--
-- TOC entry 3900 (class 1259 OID 17163)
-- Name: idx_client_documents_user_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_client_documents_user_id ON public.client_documents USING btree (user_id);


--
-- TOC entry 3905 (class 1259 OID 17164)
-- Name: idx_config_types_name; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_config_types_name ON public.config_types USING btree (name);


--
-- TOC entry 3910 (class 1259 OID 17165)
-- Name: idx_contract_statuses_name; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_contract_statuses_name ON public.contract_statuses USING btree (name);


--
-- TOC entry 3915 (class 1259 OID 17166)
-- Name: idx_contracts_document_number; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_contracts_document_number ON public.contracts USING btree (document_number);


--
-- TOC entry 3916 (class 1259 OID 17167)
-- Name: idx_contracts_loan_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_contracts_loan_id ON public.contracts USING btree (loan_id);


--
-- TOC entry 3921 (class 1259 OID 17168)
-- Name: idx_cut_period_statuses_name; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_cut_period_statuses_name ON public.cut_period_statuses USING btree (name);


--
-- TOC entry 3926 (class 1259 OID 17169)
-- Name: idx_cut_periods_active; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_cut_periods_active ON public.cut_periods USING btree (status_id) WHERE (status_id = ANY (ARRAY[1, 2]));


--
-- TOC entry 3927 (class 1259 OID 17170)
-- Name: idx_cut_periods_cut_code; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_cut_periods_cut_code ON public.cut_periods USING btree (cut_code);


--
-- TOC entry 3928 (class 1259 OID 17171)
-- Name: idx_cut_periods_dates; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_cut_periods_dates ON public.cut_periods USING btree (period_start_date, period_end_date);


--
-- TOC entry 3929 (class 1259 OID 17172)
-- Name: idx_cut_periods_status_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_cut_periods_status_id ON public.cut_periods USING btree (status_id);


--
-- TOC entry 3846 (class 1259 OID 17173)
-- Name: idx_debt_breakdown_associate; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_debt_breakdown_associate ON public.associate_debt_breakdown USING btree (associate_profile_id);


--
-- TOC entry 3847 (class 1259 OID 17174)
-- Name: idx_debt_breakdown_is_liquidated; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_debt_breakdown_is_liquidated ON public.associate_debt_breakdown USING btree (is_liquidated);


--
-- TOC entry 3850 (class 1259 OID 17175)
-- Name: idx_debt_payments_applied_items; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_debt_payments_applied_items ON public.associate_debt_payments USING gin (applied_breakdown_items);


--
-- TOC entry 3851 (class 1259 OID 17176)
-- Name: idx_debt_payments_associate_date; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_debt_payments_associate_date ON public.associate_debt_payments USING btree (associate_profile_id, payment_date DESC);


--
-- TOC entry 3852 (class 1259 OID 17177)
-- Name: idx_debt_payments_associate_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_debt_payments_associate_id ON public.associate_debt_payments USING btree (associate_profile_id);


--
-- TOC entry 3853 (class 1259 OID 17178)
-- Name: idx_debt_payments_method; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_debt_payments_method ON public.associate_debt_payments USING btree (payment_method_id);


--
-- TOC entry 3854 (class 1259 OID 17179)
-- Name: idx_debt_payments_payment_date; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_debt_payments_payment_date ON public.associate_debt_payments USING btree (payment_date);


--
-- TOC entry 3855 (class 1259 OID 17180)
-- Name: idx_debt_payments_registered_by; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_debt_payments_registered_by ON public.associate_debt_payments USING btree (registered_by);


--
-- TOC entry 3932 (class 1259 OID 17181)
-- Name: idx_defaulted_reports_associate_profile_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_defaulted_reports_associate_profile_id ON public.defaulted_client_reports USING btree (associate_profile_id);


--
-- TOC entry 3933 (class 1259 OID 17182)
-- Name: idx_defaulted_reports_client_user_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_defaulted_reports_client_user_id ON public.defaulted_client_reports USING btree (client_user_id);


--
-- TOC entry 3934 (class 1259 OID 17183)
-- Name: idx_defaulted_reports_loan_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_defaulted_reports_loan_id ON public.defaulted_client_reports USING btree (loan_id);


--
-- TOC entry 3935 (class 1259 OID 17184)
-- Name: idx_defaulted_reports_reported_at; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_defaulted_reports_reported_at ON public.defaulted_client_reports USING btree (reported_at DESC);


--
-- TOC entry 3936 (class 1259 OID 17185)
-- Name: idx_defaulted_reports_status; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_defaulted_reports_status ON public.defaulted_client_reports USING btree (status);


--
-- TOC entry 3941 (class 1259 OID 17186)
-- Name: idx_document_statuses_name; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_document_statuses_name ON public.document_statuses USING btree (name);


--
-- TOC entry 3952 (class 1259 OID 17187)
-- Name: idx_guarantors_relationship_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_guarantors_relationship_id ON public.guarantors USING btree (relationship_id);


--
-- TOC entry 3953 (class 1259 OID 17188)
-- Name: idx_legacy_amount; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_legacy_amount ON public.legacy_payment_table USING btree (amount);


--
-- TOC entry 3954 (class 1259 OID 17189)
-- Name: idx_legacy_amount_term_unique; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE UNIQUE INDEX idx_legacy_amount_term_unique ON public.legacy_payment_table USING btree (amount, term_biweeks);


--
-- TOC entry 3955 (class 1259 OID 17190)
-- Name: idx_legacy_term; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_legacy_term ON public.legacy_payment_table USING btree (term_biweeks);


--
-- TOC entry 3960 (class 1259 OID 17191)
-- Name: idx_level_change_types_name; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_level_change_types_name ON public.level_change_types USING btree (name);


--
-- TOC entry 3965 (class 1259 OID 17192)
-- Name: idx_loan_renewals_original_loan_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loan_renewals_original_loan_id ON public.loan_renewals USING btree (original_loan_id);


--
-- TOC entry 3966 (class 1259 OID 17193)
-- Name: idx_loan_renewals_renewed_loan_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loan_renewals_renewed_loan_id ON public.loan_renewals USING btree (renewed_loan_id);


--
-- TOC entry 3969 (class 1259 OID 17194)
-- Name: idx_loan_statuses_active; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loan_statuses_active ON public.loan_statuses USING btree (is_active);


--
-- TOC entry 3970 (class 1259 OID 17195)
-- Name: idx_loan_statuses_name; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loan_statuses_name ON public.loan_statuses USING btree (name);


--
-- TOC entry 3975 (class 1259 OID 17196)
-- Name: idx_loans_approved_at; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loans_approved_at ON public.loans USING btree (approved_at) WHERE (approved_at IS NOT NULL);


--
-- TOC entry 3976 (class 1259 OID 17197)
-- Name: idx_loans_associate_user_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loans_associate_user_id ON public.loans USING btree (associate_user_id);


--
-- TOC entry 3977 (class 1259 OID 17198)
-- Name: idx_loans_biweekly_payment; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loans_biweekly_payment ON public.loans USING btree (biweekly_payment) WHERE (biweekly_payment IS NOT NULL);


--
-- TOC entry 3978 (class 1259 OID 17199)
-- Name: idx_loans_profile_code_biweekly; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loans_profile_code_biweekly ON public.loans USING btree (profile_code, biweekly_payment) WHERE ((profile_code IS NOT NULL) AND (biweekly_payment IS NOT NULL));


--
-- TOC entry 3979 (class 1259 OID 17200)
-- Name: idx_loans_status_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loans_status_id ON public.loans USING btree (status_id);


--
-- TOC entry 3980 (class 1259 OID 17201)
-- Name: idx_loans_status_id_approved_at; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loans_status_id_approved_at ON public.loans USING btree (status_id, approved_at);


--
-- TOC entry 3981 (class 1259 OID 17202)
-- Name: idx_loans_total_payment; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loans_total_payment ON public.loans USING btree (total_payment) WHERE (total_payment IS NOT NULL);


--
-- TOC entry 3982 (class 1259 OID 17203)
-- Name: idx_loans_user_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_loans_user_id ON public.loans USING btree (user_id);


--
-- TOC entry 3985 (class 1259 OID 17204)
-- Name: idx_payment_methods_name; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payment_methods_name ON public.payment_methods USING btree (name);


--
-- TOC entry 3990 (class 1259 OID 17205)
-- Name: idx_payment_status_history_change_type; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payment_status_history_change_type ON public.payment_status_history USING btree (change_type);


--
-- TOC entry 3991 (class 1259 OID 17206)
-- Name: idx_payment_status_history_changed_at; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payment_status_history_changed_at ON public.payment_status_history USING btree (changed_at DESC);


--
-- TOC entry 3992 (class 1259 OID 17207)
-- Name: idx_payment_status_history_changed_by; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payment_status_history_changed_by ON public.payment_status_history USING btree (changed_by);


--
-- TOC entry 3993 (class 1259 OID 17208)
-- Name: idx_payment_status_history_new_status_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payment_status_history_new_status_id ON public.payment_status_history USING btree (new_status_id);


--
-- TOC entry 3994 (class 1259 OID 17209)
-- Name: idx_payment_status_history_payment_changed_at; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payment_status_history_payment_changed_at ON public.payment_status_history USING btree (payment_id, changed_at DESC);


--
-- TOC entry 3995 (class 1259 OID 17210)
-- Name: idx_payment_status_history_payment_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payment_status_history_payment_id ON public.payment_status_history USING btree (payment_id);


--
-- TOC entry 3998 (class 1259 OID 17211)
-- Name: idx_payment_statuses_active; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payment_statuses_active ON public.payment_statuses USING btree (is_active);


--
-- TOC entry 3999 (class 1259 OID 17212)
-- Name: idx_payment_statuses_is_real; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payment_statuses_is_real ON public.payment_statuses USING btree (is_real_payment);


--
-- TOC entry 4000 (class 1259 OID 17213)
-- Name: idx_payment_statuses_name; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payment_statuses_name ON public.payment_statuses USING btree (name);


--
-- TOC entry 4005 (class 1259 OID 17214)
-- Name: idx_payments_balance_remaining; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payments_balance_remaining ON public.payments USING btree (balance_remaining) WHERE (balance_remaining IS NOT NULL);


--
-- TOC entry 4006 (class 1259 OID 17215)
-- Name: idx_payments_cut_period_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payments_cut_period_id ON public.payments USING btree (cut_period_id);


--
-- TOC entry 4007 (class 1259 OID 17216)
-- Name: idx_payments_due_date_status_expected; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payments_due_date_status_expected ON public.payments USING btree (payment_due_date, status_id, expected_amount) WHERE (expected_amount IS NOT NULL);


--
-- TOC entry 4008 (class 1259 OID 17217)
-- Name: idx_payments_expected_amount; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payments_expected_amount ON public.payments USING btree (expected_amount) WHERE (expected_amount IS NOT NULL);


--
-- TOC entry 4009 (class 1259 OID 17218)
-- Name: idx_payments_is_late; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payments_is_late ON public.payments USING btree (is_late);


--
-- TOC entry 4010 (class 1259 OID 17219)
-- Name: idx_payments_late_loan; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payments_late_loan ON public.payments USING btree (loan_id, is_late, payment_due_date);


--
-- TOC entry 4011 (class 1259 OID 17220)
-- Name: idx_payments_loan_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payments_loan_id ON public.payments USING btree (loan_id);


--
-- TOC entry 4012 (class 1259 OID 17221)
-- Name: idx_payments_loan_number_unique; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE UNIQUE INDEX idx_payments_loan_number_unique ON public.payments USING btree (loan_id, payment_number) WHERE (payment_number IS NOT NULL);


--
-- TOC entry 4013 (class 1259 OID 17222)
-- Name: idx_payments_payment_due_date; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payments_payment_due_date ON public.payments USING btree (payment_due_date);


--
-- TOC entry 4014 (class 1259 OID 17223)
-- Name: idx_payments_payment_number; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payments_payment_number ON public.payments USING btree (payment_number) WHERE (payment_number IS NOT NULL);


--
-- TOC entry 4015 (class 1259 OID 17224)
-- Name: idx_payments_status_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_payments_status_id ON public.payments USING btree (status_id);


--
-- TOC entry 4022 (class 1259 OID 17225)
-- Name: idx_rate_profiles_code; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_rate_profiles_code ON public.rate_profiles USING btree (code);


--
-- TOC entry 4023 (class 1259 OID 17226)
-- Name: idx_rate_profiles_display; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_rate_profiles_display ON public.rate_profiles USING btree (display_order);


--
-- TOC entry 4024 (class 1259 OID 17227)
-- Name: idx_rate_profiles_enabled; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_rate_profiles_enabled ON public.rate_profiles USING btree (enabled) WHERE (enabled = true);


--
-- TOC entry 3889 (class 1259 OID 17228)
-- Name: idx_session_log_is_active; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_session_log_is_active ON public.audit_session_log USING btree (is_active);


--
-- TOC entry 3890 (class 1259 OID 17229)
-- Name: idx_session_log_login_at; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_session_log_login_at ON public.audit_session_log USING btree (login_at DESC);


--
-- TOC entry 3891 (class 1259 OID 17230)
-- Name: idx_session_log_user_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_session_log_user_id ON public.audit_session_log USING btree (user_id);


--
-- TOC entry 3876 (class 1259 OID 17231)
-- Name: idx_statement_payments_method; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_statement_payments_method ON public.associate_statement_payments USING btree (payment_method_id);


--
-- TOC entry 3877 (class 1259 OID 17232)
-- Name: idx_statement_payments_payment_date; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_statement_payments_payment_date ON public.associate_statement_payments USING btree (payment_date);


--
-- TOC entry 3878 (class 1259 OID 17233)
-- Name: idx_statement_payments_registered_by; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_statement_payments_registered_by ON public.associate_statement_payments USING btree (registered_by);


--
-- TOC entry 3879 (class 1259 OID 17234)
-- Name: idx_statement_payments_statement_amount; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_statement_payments_statement_amount ON public.associate_statement_payments USING btree (statement_id, payment_amount);


--
-- TOC entry 3880 (class 1259 OID 17235)
-- Name: idx_statement_payments_statement_id; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_statement_payments_statement_id ON public.associate_statement_payments USING btree (statement_id);


--
-- TOC entry 4037 (class 1259 OID 17236)
-- Name: idx_statement_statuses_name; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_statement_statuses_name ON public.statement_statuses USING btree (name);


--
-- TOC entry 4048 (class 1259 OID 17237)
-- Name: idx_users_active; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_users_active ON public.users USING btree (active);


--
-- TOC entry 4049 (class 1259 OID 17238)
-- Name: idx_users_email_lower; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_users_email_lower ON public.users USING btree (lower((email)::text));


--
-- TOC entry 4050 (class 1259 OID 17239)
-- Name: idx_users_username_lower; Type: INDEX; Schema: public; Owner: credinet_user
--

CREATE INDEX idx_users_username_lower ON public.users USING btree (lower((username)::text));


--
-- TOC entry 4149 (class 2620 OID 17240)
-- Name: contracts audit_contracts_trigger; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER audit_contracts_trigger AFTER INSERT OR DELETE OR UPDATE ON public.contracts FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_function();


--
-- TOC entry 4152 (class 2620 OID 17241)
-- Name: cut_periods audit_cut_periods_trigger; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER audit_cut_periods_trigger AFTER INSERT OR DELETE OR UPDATE ON public.cut_periods FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_function();


--
-- TOC entry 4159 (class 2620 OID 17242)
-- Name: loans audit_loans_trigger; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER audit_loans_trigger AFTER INSERT OR DELETE OR UPDATE ON public.loans FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_function();


--
-- TOC entry 4658 (class 0 OID 0)
-- Dependencies: 4159
-- Name: TRIGGER audit_loans_trigger ON loans; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TRIGGER audit_loans_trigger ON public.loans IS 'Registra todos los cambios en la tabla loans en audit_log para trazabilidad completa.';


--
-- TOC entry 4167 (class 2620 OID 17243)
-- Name: payments audit_payments_trigger; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER audit_payments_trigger AFTER INSERT OR DELETE OR UPDATE ON public.payments FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_function();


--
-- TOC entry 4659 (class 0 OID 0)
-- Dependencies: 4167
-- Name: TRIGGER audit_payments_trigger ON payments; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TRIGGER audit_payments_trigger ON public.payments IS 'Registra todos los cambios en la tabla payments en audit_log para trazabilidad completa.';


--
-- TOC entry 4173 (class 2620 OID 17244)
-- Name: users audit_users_trigger; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER audit_users_trigger AFTER INSERT OR DELETE OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_function();


--
-- TOC entry 4160 (class 2620 OID 17245)
-- Name: loans handle_loan_approval_trigger; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER handle_loan_approval_trigger BEFORE UPDATE ON public.loans FOR EACH ROW EXECUTE FUNCTION public.handle_loan_approval_status();


--
-- TOC entry 4660 (class 0 OID 0)
-- Dependencies: 4160
-- Name: TRIGGER handle_loan_approval_trigger ON loans; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TRIGGER handle_loan_approval_trigger ON public.loans IS 'Setea automáticamente approved_at o rejected_at cuando el estado del préstamo cambia a APPROVED o REJECTED.';


--
-- TOC entry 4161 (class 2620 OID 17246)
-- Name: loans trigger_generate_payment_schedule; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER trigger_generate_payment_schedule AFTER UPDATE OF status_id ON public.loans FOR EACH ROW EXECUTE FUNCTION public.generate_payment_schedule();


--
-- TOC entry 4661 (class 0 OID 0)
-- Dependencies: 4161
-- Name: TRIGGER trigger_generate_payment_schedule ON loans; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TRIGGER trigger_generate_payment_schedule ON public.loans IS '⭐ CRÍTICO: Ejecuta la generación automática del payment schedule cuando el estado del préstamo cambia a APPROVED. Inserta N registros en payments donde N = term_biweeks.';


--
-- TOC entry 4156 (class 2620 OID 17247)
-- Name: legacy_payment_table trigger_legacy_payment_table_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER trigger_legacy_payment_table_updated_at BEFORE UPDATE ON public.legacy_payment_table FOR EACH ROW EXECUTE FUNCTION public.update_legacy_payment_table_timestamp();


--
-- TOC entry 4168 (class 2620 OID 17248)
-- Name: payments trigger_log_payment_status_change; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER trigger_log_payment_status_change AFTER UPDATE OF status_id ON public.payments FOR EACH ROW EXECUTE FUNCTION public.log_payment_status_change();


--
-- TOC entry 4662 (class 0 OID 0)
-- Dependencies: 4168
-- Name: TRIGGER trigger_log_payment_status_change ON payments; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TRIGGER trigger_log_payment_status_change ON public.payments IS '⭐ MIGRACIÓN 12: Registra automáticamente todos los cambios de estado de pagos en payment_status_history para auditoría completa y compliance.';


--
-- TOC entry 4141 (class 2620 OID 17249)
-- Name: associate_profiles trigger_update_associate_credit_on_level_change; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER trigger_update_associate_credit_on_level_change AFTER UPDATE OF level_id ON public.associate_profiles FOR EACH ROW EXECUTE FUNCTION public.trigger_update_associate_credit_on_level_change();


--
-- TOC entry 4663 (class 0 OID 0)
-- Dependencies: 4141
-- Name: TRIGGER trigger_update_associate_credit_on_level_change ON associate_profiles; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TRIGGER trigger_update_associate_credit_on_level_change ON public.associate_profiles IS '⭐ MIGRACIÓN 07: Actualiza credit_limit del asociado cuando cambia de nivel (promoción/descenso).';


--
-- TOC entry 4162 (class 2620 OID 17250)
-- Name: loans trigger_update_associate_credit_on_loan_approval; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER trigger_update_associate_credit_on_loan_approval AFTER UPDATE OF status_id ON public.loans FOR EACH ROW EXECUTE FUNCTION public.trigger_update_associate_credit_on_loan_approval();


--
-- TOC entry 4664 (class 0 OID 0)
-- Dependencies: 4162
-- Name: TRIGGER trigger_update_associate_credit_on_loan_approval ON loans; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TRIGGER trigger_update_associate_credit_on_loan_approval ON public.loans IS '⭐ MIGRACIÓN 07: Incrementa credit_used del asociado cuando se aprueba un préstamo.';


--
-- TOC entry 4163 (class 2620 OID 17251)
-- Name: loans trigger_update_credit_on_loan_cancel; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER trigger_update_credit_on_loan_cancel AFTER UPDATE ON public.loans FOR EACH ROW EXECUTE FUNCTION public.trigger_update_associate_credit_on_loan_cancel();


--
-- TOC entry 4164 (class 2620 OID 17252)
-- Name: loans trigger_update_credit_on_loan_delete; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER trigger_update_credit_on_loan_delete BEFORE DELETE ON public.loans FOR EACH ROW EXECUTE FUNCTION public.trigger_update_associate_credit_on_loan_delete();


--
-- TOC entry 4169 (class 2620 OID 17253)
-- Name: payments trigger_update_credit_on_payment; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER trigger_update_credit_on_payment AFTER UPDATE ON public.payments FOR EACH ROW EXECUTE FUNCTION public.trigger_update_associate_credit_on_payment();


--
-- TOC entry 4143 (class 2620 OID 17254)
-- Name: associate_statement_payments trigger_update_statement_on_payment; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER trigger_update_statement_on_payment AFTER INSERT ON public.associate_statement_payments FOR EACH ROW EXECUTE FUNCTION public.update_statement_on_payment();


--
-- TOC entry 4665 (class 0 OID 0)
-- Dependencies: 4143
-- Name: TRIGGER trigger_update_statement_on_payment ON associate_statement_payments; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TRIGGER trigger_update_statement_on_payment ON public.associate_statement_payments IS '⭐ NUEVO v2.0: Actualiza automáticamente el estado de cuenta (associate_payment_statements) cuando se registra un abono. Suma todos los abonos y actualiza estado a PARTIAL_PAID o PAID según corresponda.';


--
-- TOC entry 4138 (class 2620 OID 17255)
-- Name: addresses update_addresses_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_addresses_updated_at BEFORE UPDATE ON public.addresses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4139 (class 2620 OID 17256)
-- Name: associate_debt_payments update_associate_debt_payments_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_associate_debt_payments_updated_at BEFORE UPDATE ON public.associate_debt_payments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4140 (class 2620 OID 17257)
-- Name: associate_payment_statements update_associate_payment_statements_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_associate_payment_statements_updated_at BEFORE UPDATE ON public.associate_payment_statements FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4142 (class 2620 OID 17258)
-- Name: associate_profiles update_associate_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_associate_profiles_updated_at BEFORE UPDATE ON public.associate_profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4144 (class 2620 OID 17259)
-- Name: associate_statement_payments update_associate_statement_payments_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_associate_statement_payments_updated_at BEFORE UPDATE ON public.associate_statement_payments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4145 (class 2620 OID 17260)
-- Name: beneficiaries update_beneficiaries_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_beneficiaries_updated_at BEFORE UPDATE ON public.beneficiaries FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4146 (class 2620 OID 17261)
-- Name: client_documents update_client_documents_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_client_documents_updated_at BEFORE UPDATE ON public.client_documents FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4147 (class 2620 OID 17262)
-- Name: config_types update_config_types_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_config_types_updated_at BEFORE UPDATE ON public.config_types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4148 (class 2620 OID 17263)
-- Name: contract_statuses update_contract_statuses_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_contract_statuses_updated_at BEFORE UPDATE ON public.contract_statuses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4150 (class 2620 OID 17264)
-- Name: contracts update_contracts_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_contracts_updated_at BEFORE UPDATE ON public.contracts FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4151 (class 2620 OID 17265)
-- Name: cut_period_statuses update_cut_period_statuses_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_cut_period_statuses_updated_at BEFORE UPDATE ON public.cut_period_statuses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4153 (class 2620 OID 17266)
-- Name: cut_periods update_cut_periods_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_cut_periods_updated_at BEFORE UPDATE ON public.cut_periods FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4154 (class 2620 OID 17267)
-- Name: document_statuses update_document_statuses_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_document_statuses_updated_at BEFORE UPDATE ON public.document_statuses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4155 (class 2620 OID 17268)
-- Name: guarantors update_guarantors_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_guarantors_updated_at BEFORE UPDATE ON public.guarantors FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4157 (class 2620 OID 17269)
-- Name: level_change_types update_level_change_types_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_level_change_types_updated_at BEFORE UPDATE ON public.level_change_types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4158 (class 2620 OID 17270)
-- Name: loan_statuses update_loan_statuses_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_loan_statuses_updated_at BEFORE UPDATE ON public.loan_statuses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4165 (class 2620 OID 17271)
-- Name: loans update_loans_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_loans_updated_at BEFORE UPDATE ON public.loans FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4666 (class 0 OID 0)
-- Dependencies: 4165
-- Name: TRIGGER update_loans_updated_at ON loans; Type: COMMENT; Schema: public; Owner: credinet_user
--

COMMENT ON TRIGGER update_loans_updated_at ON public.loans IS 'Actualiza automáticamente el campo updated_at cuando se modifica un registro de loans.';


--
-- TOC entry 4166 (class 2620 OID 17272)
-- Name: payment_methods update_payment_methods_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_payment_methods_updated_at BEFORE UPDATE ON public.payment_methods FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4170 (class 2620 OID 17273)
-- Name: payments update_payments_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_payments_updated_at BEFORE UPDATE ON public.payments FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4171 (class 2620 OID 17274)
-- Name: statement_statuses update_statement_statuses_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_statement_statuses_updated_at BEFORE UPDATE ON public.statement_statuses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4172 (class 2620 OID 17275)
-- Name: system_configurations update_system_configurations_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_system_configurations_updated_at BEFORE UPDATE ON public.system_configurations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4174 (class 2620 OID 17276)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: credinet_user
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 4061 (class 2606 OID 17277)
-- Name: addresses addresses_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.addresses
    ADD CONSTRAINT addresses_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4062 (class 2606 OID 17282)
-- Name: agreement_items agreement_items_agreement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreement_items
    ADD CONSTRAINT agreement_items_agreement_id_fkey FOREIGN KEY (agreement_id) REFERENCES public.agreements(id) ON DELETE CASCADE;


--
-- TOC entry 4063 (class 2606 OID 17287)
-- Name: agreement_items agreement_items_client_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreement_items
    ADD CONSTRAINT agreement_items_client_user_id_fkey FOREIGN KEY (client_user_id) REFERENCES public.users(id);


--
-- TOC entry 4064 (class 2606 OID 17292)
-- Name: agreement_items agreement_items_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreement_items
    ADD CONSTRAINT agreement_items_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.loans(id);


--
-- TOC entry 4065 (class 2606 OID 17297)
-- Name: agreement_payments agreement_payments_agreement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreement_payments
    ADD CONSTRAINT agreement_payments_agreement_id_fkey FOREIGN KEY (agreement_id) REFERENCES public.agreements(id) ON DELETE CASCADE;


--
-- TOC entry 4066 (class 2606 OID 17302)
-- Name: agreement_payments agreement_payments_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreement_payments
    ADD CONSTRAINT agreement_payments_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- TOC entry 4067 (class 2606 OID 17307)
-- Name: agreements agreements_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreements
    ADD CONSTRAINT agreements_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- TOC entry 4068 (class 2606 OID 17312)
-- Name: agreements agreements_associate_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreements
    ADD CONSTRAINT agreements_associate_profile_id_fkey FOREIGN KEY (associate_profile_id) REFERENCES public.associate_profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4069 (class 2606 OID 17317)
-- Name: agreements agreements_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.agreements
    ADD CONSTRAINT agreements_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 4070 (class 2606 OID 17322)
-- Name: associate_accumulated_balances associate_accumulated_balances_cut_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_accumulated_balances
    ADD CONSTRAINT associate_accumulated_balances_cut_period_id_fkey FOREIGN KEY (cut_period_id) REFERENCES public.cut_periods(id);


--
-- TOC entry 4071 (class 2606 OID 17327)
-- Name: associate_accumulated_balances associate_accumulated_balances_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_accumulated_balances
    ADD CONSTRAINT associate_accumulated_balances_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4072 (class 2606 OID 17332)
-- Name: associate_debt_breakdown associate_debt_breakdown_associate_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_breakdown
    ADD CONSTRAINT associate_debt_breakdown_associate_profile_id_fkey FOREIGN KEY (associate_profile_id) REFERENCES public.associate_profiles(id);


--
-- TOC entry 4073 (class 2606 OID 17337)
-- Name: associate_debt_breakdown associate_debt_breakdown_client_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_breakdown
    ADD CONSTRAINT associate_debt_breakdown_client_user_id_fkey FOREIGN KEY (client_user_id) REFERENCES public.users(id);


--
-- TOC entry 4074 (class 2606 OID 17342)
-- Name: associate_debt_breakdown associate_debt_breakdown_cut_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_breakdown
    ADD CONSTRAINT associate_debt_breakdown_cut_period_id_fkey FOREIGN KEY (cut_period_id) REFERENCES public.cut_periods(id);


--
-- TOC entry 4075 (class 2606 OID 17347)
-- Name: associate_debt_breakdown associate_debt_breakdown_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_breakdown
    ADD CONSTRAINT associate_debt_breakdown_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.loans(id);


--
-- TOC entry 4076 (class 2606 OID 17352)
-- Name: associate_debt_payments associate_debt_payments_associate_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_payments
    ADD CONSTRAINT associate_debt_payments_associate_profile_id_fkey FOREIGN KEY (associate_profile_id) REFERENCES public.associate_profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4077 (class 2606 OID 17357)
-- Name: associate_debt_payments associate_debt_payments_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_payments
    ADD CONSTRAINT associate_debt_payments_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- TOC entry 4078 (class 2606 OID 17362)
-- Name: associate_debt_payments associate_debt_payments_registered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_debt_payments
    ADD CONSTRAINT associate_debt_payments_registered_by_fkey FOREIGN KEY (registered_by) REFERENCES public.users(id);


--
-- TOC entry 4079 (class 2606 OID 17367)
-- Name: associate_level_history associate_level_history_associate_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_level_history
    ADD CONSTRAINT associate_level_history_associate_profile_id_fkey FOREIGN KEY (associate_profile_id) REFERENCES public.associate_profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4080 (class 2606 OID 17372)
-- Name: associate_level_history associate_level_history_change_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_level_history
    ADD CONSTRAINT associate_level_history_change_type_id_fkey FOREIGN KEY (change_type_id) REFERENCES public.level_change_types(id);


--
-- TOC entry 4081 (class 2606 OID 17377)
-- Name: associate_level_history associate_level_history_new_level_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_level_history
    ADD CONSTRAINT associate_level_history_new_level_id_fkey FOREIGN KEY (new_level_id) REFERENCES public.associate_levels(id);


--
-- TOC entry 4082 (class 2606 OID 17382)
-- Name: associate_level_history associate_level_history_old_level_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_level_history
    ADD CONSTRAINT associate_level_history_old_level_id_fkey FOREIGN KEY (old_level_id) REFERENCES public.associate_levels(id);


--
-- TOC entry 4083 (class 2606 OID 17387)
-- Name: associate_payment_statements associate_payment_statements_cut_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_payment_statements
    ADD CONSTRAINT associate_payment_statements_cut_period_id_fkey FOREIGN KEY (cut_period_id) REFERENCES public.cut_periods(id);


--
-- TOC entry 4084 (class 2606 OID 17392)
-- Name: associate_payment_statements associate_payment_statements_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_payment_statements
    ADD CONSTRAINT associate_payment_statements_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- TOC entry 4085 (class 2606 OID 17397)
-- Name: associate_payment_statements associate_payment_statements_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_payment_statements
    ADD CONSTRAINT associate_payment_statements_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.statement_statuses(id);


--
-- TOC entry 4086 (class 2606 OID 17402)
-- Name: associate_payment_statements associate_payment_statements_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_payment_statements
    ADD CONSTRAINT associate_payment_statements_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 4087 (class 2606 OID 17407)
-- Name: associate_profiles associate_profiles_level_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_profiles
    ADD CONSTRAINT associate_profiles_level_id_fkey FOREIGN KEY (level_id) REFERENCES public.associate_levels(id);


--
-- TOC entry 4088 (class 2606 OID 17412)
-- Name: associate_profiles associate_profiles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_profiles
    ADD CONSTRAINT associate_profiles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4089 (class 2606 OID 17417)
-- Name: associate_statement_payments associate_statement_payments_payment_method_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_statement_payments
    ADD CONSTRAINT associate_statement_payments_payment_method_id_fkey FOREIGN KEY (payment_method_id) REFERENCES public.payment_methods(id);


--
-- TOC entry 4090 (class 2606 OID 17422)
-- Name: associate_statement_payments associate_statement_payments_registered_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_statement_payments
    ADD CONSTRAINT associate_statement_payments_registered_by_fkey FOREIGN KEY (registered_by) REFERENCES public.users(id);


--
-- TOC entry 4091 (class 2606 OID 17427)
-- Name: associate_statement_payments associate_statement_payments_statement_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.associate_statement_payments
    ADD CONSTRAINT associate_statement_payments_statement_id_fkey FOREIGN KEY (statement_id) REFERENCES public.associate_payment_statements(id) ON DELETE CASCADE;


--
-- TOC entry 4092 (class 2606 OID 17432)
-- Name: audit_log audit_log_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- TOC entry 4093 (class 2606 OID 17437)
-- Name: audit_session_log audit_session_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.audit_session_log
    ADD CONSTRAINT audit_session_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4094 (class 2606 OID 17442)
-- Name: beneficiaries beneficiaries_relationship_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.beneficiaries
    ADD CONSTRAINT beneficiaries_relationship_id_fkey FOREIGN KEY (relationship_id) REFERENCES public.relationships(id);


--
-- TOC entry 4095 (class 2606 OID 17447)
-- Name: beneficiaries beneficiaries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.beneficiaries
    ADD CONSTRAINT beneficiaries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4096 (class 2606 OID 17452)
-- Name: client_documents client_documents_document_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.client_documents
    ADD CONSTRAINT client_documents_document_type_id_fkey FOREIGN KEY (document_type_id) REFERENCES public.document_types(id);


--
-- TOC entry 4097 (class 2606 OID 17457)
-- Name: client_documents client_documents_reviewed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.client_documents
    ADD CONSTRAINT client_documents_reviewed_by_fkey FOREIGN KEY (reviewed_by) REFERENCES public.users(id);


--
-- TOC entry 4098 (class 2606 OID 17462)
-- Name: client_documents client_documents_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.client_documents
    ADD CONSTRAINT client_documents_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.document_statuses(id);


--
-- TOC entry 4099 (class 2606 OID 17467)
-- Name: client_documents client_documents_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.client_documents
    ADD CONSTRAINT client_documents_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4100 (class 2606 OID 17472)
-- Name: contracts contracts_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.loans(id) ON DELETE CASCADE;


--
-- TOC entry 4101 (class 2606 OID 17477)
-- Name: contracts contracts_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.contract_statuses(id);


--
-- TOC entry 4102 (class 2606 OID 17482)
-- Name: cut_periods cut_periods_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.cut_periods
    ADD CONSTRAINT cut_periods_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id);


--
-- TOC entry 4103 (class 2606 OID 17487)
-- Name: cut_periods cut_periods_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.cut_periods
    ADD CONSTRAINT cut_periods_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 4104 (class 2606 OID 17492)
-- Name: cut_periods cut_periods_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.cut_periods
    ADD CONSTRAINT cut_periods_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.cut_period_statuses(id);


--
-- TOC entry 4105 (class 2606 OID 17497)
-- Name: defaulted_client_reports defaulted_client_reports_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.defaulted_client_reports
    ADD CONSTRAINT defaulted_client_reports_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- TOC entry 4106 (class 2606 OID 17502)
-- Name: defaulted_client_reports defaulted_client_reports_associate_profile_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.defaulted_client_reports
    ADD CONSTRAINT defaulted_client_reports_associate_profile_id_fkey FOREIGN KEY (associate_profile_id) REFERENCES public.associate_profiles(id) ON DELETE CASCADE;


--
-- TOC entry 4107 (class 2606 OID 17507)
-- Name: defaulted_client_reports defaulted_client_reports_client_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.defaulted_client_reports
    ADD CONSTRAINT defaulted_client_reports_client_user_id_fkey FOREIGN KEY (client_user_id) REFERENCES public.users(id);


--
-- TOC entry 4108 (class 2606 OID 17512)
-- Name: defaulted_client_reports defaulted_client_reports_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.defaulted_client_reports
    ADD CONSTRAINT defaulted_client_reports_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.loans(id);


--
-- TOC entry 4109 (class 2606 OID 17517)
-- Name: defaulted_client_reports defaulted_client_reports_reported_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.defaulted_client_reports
    ADD CONSTRAINT defaulted_client_reports_reported_by_fkey FOREIGN KEY (reported_by) REFERENCES public.users(id);


--
-- TOC entry 4117 (class 2606 OID 17522)
-- Name: loans fk_loans_contract_id; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT fk_loans_contract_id FOREIGN KEY (contract_id) REFERENCES public.contracts(id);


--
-- TOC entry 4118 (class 2606 OID 17527)
-- Name: loans fk_loans_profile_code; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT fk_loans_profile_code FOREIGN KEY (profile_code) REFERENCES public.rate_profiles(code) ON DELETE SET NULL;


--
-- TOC entry 4110 (class 2606 OID 17532)
-- Name: guarantors guarantors_relationship_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.guarantors
    ADD CONSTRAINT guarantors_relationship_id_fkey FOREIGN KEY (relationship_id) REFERENCES public.relationships(id);


--
-- TOC entry 4111 (class 2606 OID 17537)
-- Name: guarantors guarantors_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.guarantors
    ADD CONSTRAINT guarantors_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4112 (class 2606 OID 17542)
-- Name: legacy_payment_table legacy_payment_table_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.legacy_payment_table
    ADD CONSTRAINT legacy_payment_table_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 4113 (class 2606 OID 17547)
-- Name: legacy_payment_table legacy_payment_table_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.legacy_payment_table
    ADD CONSTRAINT legacy_payment_table_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- TOC entry 4114 (class 2606 OID 17552)
-- Name: loan_renewals loan_renewals_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loan_renewals
    ADD CONSTRAINT loan_renewals_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 4115 (class 2606 OID 17557)
-- Name: loan_renewals loan_renewals_original_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loan_renewals
    ADD CONSTRAINT loan_renewals_original_loan_id_fkey FOREIGN KEY (original_loan_id) REFERENCES public.loans(id);


--
-- TOC entry 4116 (class 2606 OID 17562)
-- Name: loan_renewals loan_renewals_renewed_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loan_renewals
    ADD CONSTRAINT loan_renewals_renewed_loan_id_fkey FOREIGN KEY (renewed_loan_id) REFERENCES public.loans(id);


--
-- TOC entry 4119 (class 2606 OID 17567)
-- Name: loans loans_approved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT loans_approved_by_fkey FOREIGN KEY (approved_by) REFERENCES public.users(id);


--
-- TOC entry 4120 (class 2606 OID 17572)
-- Name: loans loans_associate_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT loans_associate_user_id_fkey FOREIGN KEY (associate_user_id) REFERENCES public.users(id);


--
-- TOC entry 4121 (class 2606 OID 17577)
-- Name: loans loans_rejected_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT loans_rejected_by_fkey FOREIGN KEY (rejected_by) REFERENCES public.users(id);


--
-- TOC entry 4122 (class 2606 OID 17582)
-- Name: loans loans_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT loans_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.loan_statuses(id);


--
-- TOC entry 4123 (class 2606 OID 17587)
-- Name: loans loans_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.loans
    ADD CONSTRAINT loans_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 4124 (class 2606 OID 17592)
-- Name: payment_status_history payment_status_history_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.users(id);


--
-- TOC entry 4125 (class 2606 OID 17597)
-- Name: payment_status_history payment_status_history_new_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_new_status_id_fkey FOREIGN KEY (new_status_id) REFERENCES public.payment_statuses(id);


--
-- TOC entry 4126 (class 2606 OID 17602)
-- Name: payment_status_history payment_status_history_old_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_old_status_id_fkey FOREIGN KEY (old_status_id) REFERENCES public.payment_statuses(id);


--
-- TOC entry 4127 (class 2606 OID 17607)
-- Name: payment_status_history payment_status_history_payment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payment_status_history
    ADD CONSTRAINT payment_status_history_payment_id_fkey FOREIGN KEY (payment_id) REFERENCES public.payments(id) ON DELETE CASCADE;


--
-- TOC entry 4128 (class 2606 OID 17612)
-- Name: payments payments_cut_period_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_cut_period_id_fkey FOREIGN KEY (cut_period_id) REFERENCES public.cut_periods(id);


--
-- TOC entry 4129 (class 2606 OID 17617)
-- Name: payments payments_loan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_loan_id_fkey FOREIGN KEY (loan_id) REFERENCES public.loans(id) ON DELETE CASCADE;


--
-- TOC entry 4130 (class 2606 OID 17622)
-- Name: payments payments_marked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_marked_by_fkey FOREIGN KEY (marked_by) REFERENCES public.users(id);


--
-- TOC entry 4131 (class 2606 OID 17627)
-- Name: payments payments_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.payment_statuses(id);


--
-- TOC entry 4132 (class 2606 OID 17632)
-- Name: rate_profiles rate_profiles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.rate_profiles
    ADD CONSTRAINT rate_profiles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 4133 (class 2606 OID 17637)
-- Name: rate_profiles rate_profiles_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.rate_profiles
    ADD CONSTRAINT rate_profiles_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- TOC entry 4134 (class 2606 OID 17642)
-- Name: system_configurations system_configurations_config_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT system_configurations_config_type_id_fkey FOREIGN KEY (config_type_id) REFERENCES public.config_types(id);


--
-- TOC entry 4135 (class 2606 OID 17647)
-- Name: system_configurations system_configurations_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT system_configurations_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- TOC entry 4136 (class 2606 OID 17652)
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- TOC entry 4137 (class 2606 OID 17657)
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: credinet_user
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


-- Completed on 2026-01-23 12:27:19 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict zdPYBqGuzQMiHkwqkjrhEJzb6sddeA9icZNdtOnGkzlflcWIKVzSftOn5NGuFF1

