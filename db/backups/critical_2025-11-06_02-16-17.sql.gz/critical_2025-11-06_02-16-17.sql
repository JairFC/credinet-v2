--
-- PostgreSQL database dump
--

\restrict pFmCDeS0EbIhgwgbF43s2GZvrxJ0qHIwqY3OBeVvWcrM5ys6cfaHfgc9WdlaNUK

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cut_periods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cut_periods (
    id integer NOT NULL,
    cut_number integer NOT NULL,
    period_start_date date NOT NULL,
    period_end_date date NOT NULL,
    status_id integer NOT NULL,
    total_payments_expected numeric(12,2) DEFAULT 0.00 NOT NULL,
    total_payments_received numeric(12,2) DEFAULT 0.00 NOT NULL,
    total_commission numeric(12,2) DEFAULT 0.00 NOT NULL,
    created_by integer NOT NULL,
    closed_by integer,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    cut_code character varying(10),
    CONSTRAINT check_cut_periods_dates_logical CHECK ((period_end_date > period_start_date)),
    CONSTRAINT check_cut_periods_totals_non_negative CHECK (((total_payments_expected >= (0)::numeric) AND (total_payments_received >= (0)::numeric) AND (total_commission >= (0)::numeric)))
);


--
-- Name: TABLE cut_periods; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.cut_periods IS 'Períodos administrativos quincenales del sistema (8-22 y 23-7 de cada mes). Usados para cortes de caja y liquidaciones.';


--
-- Name: COLUMN cut_periods.cut_number; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cut_periods.cut_number IS 'Número secuencial del período de corte. Se reinicia cada año (1-24 por año).';


--
-- Name: COLUMN cut_periods.cut_code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cut_periods.cut_code IS 'Código único del periodo: {YYYY}-Q{NN}. Ej: 2025-Q01 (ene 8-22), 2025-Q24 (dic 23-ene 7)';


--
-- Name: cut_periods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cut_periods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cut_periods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cut_periods_id_seq OWNED BY public.cut_periods.id;


--
-- Name: system_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_configurations (
    id integer NOT NULL,
    config_key character varying(100) NOT NULL,
    config_value text NOT NULL,
    description text,
    config_type_id integer NOT NULL,
    updated_by integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE system_configurations; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.system_configurations IS 'Configuraciones globales del sistema (tasas, montos, flags de funcionalidad).';


--
-- Name: system_configurations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_configurations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_configurations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_configurations_id_seq OWNED BY public.system_configurations.id;


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id integer NOT NULL,
    role_id integer NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE user_roles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.user_roles IS 'Relación N:M entre usuarios y roles. Un usuario puede tener múltiples roles.';


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(50) NOT NULL,
    password_hash character varying(255) NOT NULL,
    first_name character varying(100) NOT NULL,
    last_name character varying(100) NOT NULL,
    email character varying(150),
    phone_number character varying(20) NOT NULL,
    birth_date date,
    curp character varying(18),
    profile_picture_url character varying(500),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    active boolean DEFAULT true NOT NULL,
    CONSTRAINT check_users_curp_length CHECK (((curp IS NULL) OR (length((curp)::text) = 18))),
    CONSTRAINT check_users_phone_format CHECK (((phone_number)::text ~ '^[0-9]{10}$'::text))
);


--
-- Name: TABLE users; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.users IS 'Usuarios del sistema (clientes, asociados, administradores).';


--
-- Name: COLUMN users.password_hash; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.password_hash IS 'Hash bcrypt de la contraseña del usuario. NUNCA almacenar contraseñas en texto plano.';


--
-- Name: COLUMN users.email; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.email IS 'Email del usuario (OPCIONAL - algunos usuarios mayores pueden no tener correo electrónico).';


--
-- Name: COLUMN users.curp; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.curp IS 'Clave Única de Registro de Población (CURP) de México. Formato: 18 caracteres alfanuméricos.';


--
-- Name: COLUMN users.active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.active IS 'Indica si el usuario está activo en el sistema. Los usuarios inactivos no pueden iniciar sesión.';


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: cut_periods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cut_periods ALTER COLUMN id SET DEFAULT nextval('public.cut_periods_id_seq'::regclass);


--
-- Name: system_configurations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_configurations ALTER COLUMN id SET DEFAULT nextval('public.system_configurations_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: cut_periods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cut_periods (id, cut_number, period_start_date, period_end_date, status_id, total_payments_expected, total_payments_received, total_commission, created_by, closed_by, created_at, updated_at, cut_code) FROM stdin;
1	1	2024-01-08	2024-01-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.232865+00	2025-11-06 08:12:35.232865+00	2024-Q01
2	2	2024-01-23	2024-02-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.236375+00	2025-11-06 08:12:35.236375+00	2024-Q02
3	3	2024-02-08	2024-02-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.237509+00	2025-11-06 08:12:35.237509+00	2024-Q03
4	4	2024-02-23	2024-03-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.238601+00	2025-11-06 08:12:35.238601+00	2024-Q04
5	5	2024-03-08	2024-03-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.239673+00	2025-11-06 08:12:35.239673+00	2024-Q05
6	6	2024-03-23	2024-04-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.240759+00	2025-11-06 08:12:35.240759+00	2024-Q06
7	7	2024-04-08	2024-04-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.241855+00	2025-11-06 08:12:35.241855+00	2024-Q07
8	8	2024-04-23	2024-05-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.242878+00	2025-11-06 08:12:35.242878+00	2024-Q08
9	9	2024-05-08	2024-05-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.243887+00	2025-11-06 08:12:35.243887+00	2024-Q09
10	10	2024-05-23	2024-06-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.244909+00	2025-11-06 08:12:35.244909+00	2024-Q10
11	11	2024-06-08	2024-06-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.24612+00	2025-11-06 08:12:35.24612+00	2024-Q11
12	12	2024-06-23	2024-07-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.247165+00	2025-11-06 08:12:35.247165+00	2024-Q12
13	13	2024-07-08	2024-07-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.24812+00	2025-11-06 08:12:35.24812+00	2024-Q13
14	14	2024-07-23	2024-08-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.249161+00	2025-11-06 08:12:35.249161+00	2024-Q14
15	15	2024-08-08	2024-08-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.250188+00	2025-11-06 08:12:35.250188+00	2024-Q15
16	16	2024-08-23	2024-09-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.251225+00	2025-11-06 08:12:35.251225+00	2024-Q16
17	17	2024-09-08	2024-09-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.25225+00	2025-11-06 08:12:35.25225+00	2024-Q17
18	18	2024-09-23	2024-10-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.253281+00	2025-11-06 08:12:35.253281+00	2024-Q18
19	19	2024-10-08	2024-10-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.254293+00	2025-11-06 08:12:35.254293+00	2024-Q19
20	20	2024-10-23	2024-11-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.255324+00	2025-11-06 08:12:35.255324+00	2024-Q20
21	21	2024-11-08	2024-11-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.256349+00	2025-11-06 08:12:35.256349+00	2024-Q21
22	22	2024-11-23	2024-12-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.257381+00	2025-11-06 08:12:35.257381+00	2024-Q22
23	23	2024-12-08	2024-12-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.25842+00	2025-11-06 08:12:35.25842+00	2024-Q23
24	24	2024-12-23	2025-01-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.259538+00	2025-11-06 08:12:35.259538+00	2024-Q24
25	1	2025-01-08	2025-01-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.260567+00	2025-11-06 08:12:35.260567+00	2025-Q01
26	2	2025-01-23	2025-02-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.261606+00	2025-11-06 08:12:35.261606+00	2025-Q02
27	3	2025-02-08	2025-02-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.262638+00	2025-11-06 08:12:35.262638+00	2025-Q03
28	4	2025-02-23	2025-03-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.263678+00	2025-11-06 08:12:35.263678+00	2025-Q04
29	5	2025-03-08	2025-03-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.26471+00	2025-11-06 08:12:35.26471+00	2025-Q05
30	6	2025-03-23	2025-04-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.26574+00	2025-11-06 08:12:35.26574+00	2025-Q06
31	7	2025-04-08	2025-04-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.266767+00	2025-11-06 08:12:35.266767+00	2025-Q07
32	8	2025-04-23	2025-05-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.26782+00	2025-11-06 08:12:35.26782+00	2025-Q08
33	9	2025-05-08	2025-05-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.268866+00	2025-11-06 08:12:35.268866+00	2025-Q09
34	10	2025-05-23	2025-06-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.269927+00	2025-11-06 08:12:35.269927+00	2025-Q10
35	11	2025-06-08	2025-06-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.271003+00	2025-11-06 08:12:35.271003+00	2025-Q11
36	12	2025-06-23	2025-07-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.272185+00	2025-11-06 08:12:35.272185+00	2025-Q12
37	13	2025-07-08	2025-07-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.273257+00	2025-11-06 08:12:35.273257+00	2025-Q13
38	14	2025-07-23	2025-08-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.274299+00	2025-11-06 08:12:35.274299+00	2025-Q14
39	15	2025-08-08	2025-08-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.275323+00	2025-11-06 08:12:35.275323+00	2025-Q15
40	16	2025-08-23	2025-09-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.276338+00	2025-11-06 08:12:35.276338+00	2025-Q16
41	17	2025-09-08	2025-09-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.277349+00	2025-11-06 08:12:35.277349+00	2025-Q17
42	18	2025-09-23	2025-10-07	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.278353+00	2025-11-06 08:12:35.278353+00	2025-Q18
43	19	2025-10-08	2025-10-22	5	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.279354+00	2025-11-06 08:12:35.279354+00	2025-Q19
44	20	2025-10-23	2025-11-07	2	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.280379+00	2025-11-06 08:12:35.280379+00	2025-Q20
45	21	2025-11-08	2025-11-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.281436+00	2025-11-06 08:12:35.281436+00	2025-Q21
46	22	2025-11-23	2025-12-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.282433+00	2025-11-06 08:12:35.282433+00	2025-Q22
47	23	2025-12-08	2025-12-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.283429+00	2025-11-06 08:12:35.283429+00	2025-Q23
48	24	2025-12-23	2026-01-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.284442+00	2025-11-06 08:12:35.284442+00	2025-Q24
49	1	2026-01-08	2026-01-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.285443+00	2025-11-06 08:12:35.285443+00	2026-Q01
50	2	2026-01-23	2026-02-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.286442+00	2025-11-06 08:12:35.286442+00	2026-Q02
51	3	2026-02-08	2026-02-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.287441+00	2025-11-06 08:12:35.287441+00	2026-Q03
52	4	2026-02-23	2026-03-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.288437+00	2025-11-06 08:12:35.288437+00	2026-Q04
53	5	2026-03-08	2026-03-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.289431+00	2025-11-06 08:12:35.289431+00	2026-Q05
54	6	2026-03-23	2026-04-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.290424+00	2025-11-06 08:12:35.290424+00	2026-Q06
55	7	2026-04-08	2026-04-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.291428+00	2025-11-06 08:12:35.291428+00	2026-Q07
56	8	2026-04-23	2026-05-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.292434+00	2025-11-06 08:12:35.292434+00	2026-Q08
57	9	2026-05-08	2026-05-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.293426+00	2025-11-06 08:12:35.293426+00	2026-Q09
58	10	2026-05-23	2026-06-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.294429+00	2025-11-06 08:12:35.294429+00	2026-Q10
59	11	2026-06-08	2026-06-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.295432+00	2025-11-06 08:12:35.295432+00	2026-Q11
60	12	2026-06-23	2026-07-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.296437+00	2025-11-06 08:12:35.296437+00	2026-Q12
61	13	2026-07-08	2026-07-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.297433+00	2025-11-06 08:12:35.297433+00	2026-Q13
62	14	2026-07-23	2026-08-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.298427+00	2025-11-06 08:12:35.298427+00	2026-Q14
63	15	2026-08-08	2026-08-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.299425+00	2025-11-06 08:12:35.299425+00	2026-Q15
64	16	2026-08-23	2026-09-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.300436+00	2025-11-06 08:12:35.300436+00	2026-Q16
65	17	2026-09-08	2026-09-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.301429+00	2025-11-06 08:12:35.301429+00	2026-Q17
66	18	2026-09-23	2026-10-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.302446+00	2025-11-06 08:12:35.302446+00	2026-Q18
67	19	2026-10-08	2026-10-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.30345+00	2025-11-06 08:12:35.30345+00	2026-Q19
68	20	2026-10-23	2026-11-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.304456+00	2025-11-06 08:12:35.304456+00	2026-Q20
69	21	2026-11-08	2026-11-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.305447+00	2025-11-06 08:12:35.305447+00	2026-Q21
70	22	2026-11-23	2026-12-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.306443+00	2025-11-06 08:12:35.306443+00	2026-Q22
71	23	2026-12-08	2026-12-22	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.307448+00	2025-11-06 08:12:35.307448+00	2026-Q23
72	24	2026-12-23	2027-01-07	1	0.00	0.00	0.00	1	\N	2025-11-06 08:12:35.308444+00	2025-11-06 08:12:35.308444+00	2026-Q24
\.


--
-- Data for Name: system_configurations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_configurations (id, config_key, config_value, description, config_type_id, updated_by, created_at, updated_at) FROM stdin;
1	max_loan_amount	1000000	Monto máximo de préstamo permitido	2	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
2	default_interest_rate	2.5	Tasa de interés por defecto	2	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
3	default_commission_rate	2.5	Tasa de comisión por defecto	2	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
4	system_name	Credinet	Nombre del sistema	1	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
5	maintenance_mode	false	Modo de mantenimiento	3	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
6	payment_system	BIWEEKLY_v2.0	Sistema de pagos quincenal v2.0	1	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
7	perfect_dates_enabled	true	Fechas perfectas (día 15 y último)	3	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
8	cut_days	8,23	Días de corte exactos	1	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
9	payment_days	15,LAST	Días de pago permitidos	1	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
10	db_version	2.0.0	Versión de base de datos	1	2	2025-10-31 01:12:22.124383+00	2025-10-31 01:12:22.124383+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role_id, created_at) FROM stdin;
1	1	2025-10-31 01:12:22.092816+00
2	2	2025-10-31 01:12:22.092816+00
3	4	2025-10-31 01:12:22.092816+00
4	5	2025-10-31 01:12:22.092816+00
5	5	2025-10-31 01:12:22.092816+00
6	5	2025-10-31 01:12:22.092816+00
7	3	2025-10-31 01:12:22.092816+00
8	4	2025-10-31 01:12:22.092816+00
1000	5	2025-10-31 01:12:22.092816+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, password_hash, first_name, last_name, email, phone_number, birth_date, curp, profile_picture_url, created_at, updated_at, active) FROM stdin;
1	jair	$2b$12$aSMdt0Kd8I2lrCIvSNbxx.X5U.BmY9MAZAoPvM/MgK5mXOxQgq0s6	Jair	FC	jair@dev.com	5511223344	1990-01-15	FERJ900115HDFXXX01	\N	2025-10-31 01:12:22.089593+00	2025-10-31 01:12:22.089593+00	t
2	admin	$2b$12$aSMdt0Kd8I2lrCIvSNbxx.X5U.BmY9MAZAoPvM/MgK5mXOxQgq0s6	Admin	Total	admin@credinet.com	5522334455	\N	\N	\N	2025-10-31 01:12:22.089593+00	2025-10-31 01:12:22.089593+00	t
3	asociado_test	$2b$12$aSMdt0Kd8I2lrCIvSNbxx.X5U.BmY9MAZAoPvM/MgK5mXOxQgq0s6	Asociado	Prueba	asociado@test.com	5533445566	\N	\N	\N	2025-10-31 01:12:22.089593+00	2025-10-31 01:12:22.089593+00	t
4	sofia.vargas	$2b$12$aSMdt0Kd8I2lrCIvSNbxx.X5U.BmY9MAZAoPvM/MgK5mXOxQgq0s6	Sofía	Vargas	sofia.vargas@email.com	5544556677	1985-05-20	VARS850520MDFXXX02	\N	2025-10-31 01:12:22.089593+00	2025-10-31 01:12:22.089593+00	t
5	juan.perez	$2b$12$aSMdt0Kd8I2lrCIvSNbxx.X5U.BmY9MAZAoPvM/MgK5mXOxQgq0s6	Juan	Pérez	juan.perez@email.com	5555667788	1992-11-30	PERJ921130HDFXXX03	\N	2025-10-31 01:12:22.089593+00	2025-10-31 01:12:22.089593+00	t
6	laura.mtz	$2b$12$aSMdt0Kd8I2lrCIvSNbxx.X5U.BmY9MAZAoPvM/MgK5mXOxQgq0s6	Laura	Martínez	laura.martinez@email.com	5566778899	\N	\N	\N	2025-10-31 01:12:22.089593+00	2025-10-31 01:12:22.089593+00	t
7	aux.admin	$2b$12$aSMdt0Kd8I2lrCIvSNbxx.X5U.BmY9MAZAoPvM/MgK5mXOxQgq0s6	Pedro	Ramírez	pedro.ramirez@credinet.com	5577889900	\N	\N	\N	2025-10-31 01:12:22.089593+00	2025-10-31 01:12:22.089593+00	t
8	asociado_norte	$2b$12$aSMdt0Kd8I2lrCIvSNbxx.X5U.BmY9MAZAoPvM/MgK5mXOxQgq0s6	User	Norte	user@norte.com	5588990011	\N	\N	\N	2025-10-31 01:12:22.089593+00	2025-10-31 01:12:22.089593+00	t
1000	aval_test	$2b$12$aSMdt0Kd8I2lrCIvSNbxx.X5U.BmY9MAZAoPvM/MgK5mXOxQgq0s6	María	Aval	maria.aval@demo.com	6143618296	1995-05-25	FACJ950525HCHRRR04	\N	2025-10-31 01:12:22.089593+00	2025-10-31 01:12:22.089593+00	t
\.


--
-- Name: cut_periods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cut_periods_id_seq', 72, true);


--
-- Name: system_configurations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_configurations_id_seq', 10, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 1001, false);


--
-- Name: cut_periods cut_periods_cut_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cut_periods
    ADD CONSTRAINT cut_periods_cut_code_key UNIQUE (cut_code);


--
-- Name: cut_periods cut_periods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cut_periods
    ADD CONSTRAINT cut_periods_pkey PRIMARY KEY (id);


--
-- Name: system_configurations system_configurations_config_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT system_configurations_config_key_key UNIQUE (config_key);


--
-- Name: system_configurations system_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT system_configurations_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: users users_curp_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_curp_key UNIQUE (curp);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_number_key UNIQUE (phone_number);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_cut_periods_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cut_periods_active ON public.cut_periods USING btree (status_id) WHERE (status_id = ANY (ARRAY[1, 2]));


--
-- Name: idx_cut_periods_cut_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cut_periods_cut_code ON public.cut_periods USING btree (cut_code);


--
-- Name: idx_cut_periods_dates; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cut_periods_dates ON public.cut_periods USING btree (period_start_date, period_end_date);


--
-- Name: idx_cut_periods_status_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cut_periods_status_id ON public.cut_periods USING btree (status_id);


--
-- Name: idx_users_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_active ON public.users USING btree (active);


--
-- Name: idx_users_email_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email_lower ON public.users USING btree (lower((email)::text));


--
-- Name: idx_users_username_lower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_username_lower ON public.users USING btree (lower((username)::text));


--
-- Name: cut_periods audit_cut_periods_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_cut_periods_trigger AFTER INSERT OR DELETE OR UPDATE ON public.cut_periods FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_function();


--
-- Name: users audit_users_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_users_trigger AFTER INSERT OR DELETE OR UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.audit_trigger_function();


--
-- Name: cut_periods update_cut_periods_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_cut_periods_updated_at BEFORE UPDATE ON public.cut_periods FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: system_configurations update_system_configurations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_system_configurations_updated_at BEFORE UPDATE ON public.system_configurations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: cut_periods cut_periods_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cut_periods
    ADD CONSTRAINT cut_periods_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id);


--
-- Name: cut_periods cut_periods_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cut_periods
    ADD CONSTRAINT cut_periods_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: cut_periods cut_periods_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cut_periods
    ADD CONSTRAINT cut_periods_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.cut_period_statuses(id);


--
-- Name: system_configurations system_configurations_config_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT system_configurations_config_type_id_fkey FOREIGN KEY (config_type_id) REFERENCES public.config_types(id);


--
-- Name: system_configurations system_configurations_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_configurations
    ADD CONSTRAINT system_configurations_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict pFmCDeS0EbIhgwgbF43s2GZvrxJ0qHIwqY3OBeVvWcrM5ys6cfaHfgc9WdlaNUK

