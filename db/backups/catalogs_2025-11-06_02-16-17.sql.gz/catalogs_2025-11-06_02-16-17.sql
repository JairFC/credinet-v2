--
-- PostgreSQL database dump
--

\restrict 0GPBwNbcC32jYWO3gBjVYgS7xkgFUmAnyDKmthK5Ulzy0lXUIpEc5ZgmstbZ1JJ

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: associate_levels; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.associate_levels (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    max_loan_amount numeric(12,2) NOT NULL,
    credit_limit numeric(12,2) DEFAULT 0.00,
    description text,
    min_clients integer DEFAULT 0,
    min_collection_rate numeric(5,2) DEFAULT 0.00,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE associate_levels; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.associate_levels IS 'Niveles de asociados (Bronce, Plata, Oro, Platino, Diamante) con límites de préstamo y crédito.';


--
-- Name: COLUMN associate_levels.credit_limit; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.associate_levels.credit_limit IS 'Límite de crédito disponible para el asociado en este nivel (v2.0).';


--
-- Name: associate_levels_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.associate_levels_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: associate_levels_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.associate_levels_id_seq OWNED BY public.associate_levels.id;


--
-- Name: config_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.config_types (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    validation_regex text,
    example_value text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE config_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.config_types IS 'Catálogo de tipos de datos para configuraciones del sistema (STRING, NUMBER, BOOLEAN, JSON).';


--
-- Name: config_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.config_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: config_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.config_types_id_seq OWNED BY public.config_types.id;


--
-- Name: contract_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_active boolean DEFAULT true,
    requires_signature boolean DEFAULT false,
    display_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE contract_statuses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.contract_statuses IS 'Catálogo de estados posibles para contratos. Normaliza contracts.status_id.';


--
-- Name: contract_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.contract_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: contract_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.contract_statuses_id_seq OWNED BY public.contract_statuses.id;


--
-- Name: cut_period_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cut_period_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_terminal boolean DEFAULT false,
    allows_payments boolean DEFAULT true,
    display_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE cut_period_statuses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.cut_period_statuses IS 'Catálogo de estados para períodos de corte quincenal (días 8-22 y 23-7).';


--
-- Name: cut_period_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.cut_period_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: cut_period_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.cut_period_statuses_id_seq OWNED BY public.cut_period_statuses.id;


--
-- Name: document_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    display_order integer DEFAULT 0,
    color_code character varying(7),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE document_statuses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.document_statuses IS 'Catálogo de estados para documentos de clientes (PENDING, APPROVED, REJECTED).';


--
-- Name: document_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_statuses_id_seq OWNED BY public.document_statuses.id;


--
-- Name: document_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_types (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    is_required boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE document_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.document_types IS 'Tipos de documentos requeridos para clientes (INE, comprobante de domicilio, etc.).';


--
-- Name: document_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.document_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.document_types_id_seq OWNED BY public.document_types.id;


--
-- Name: level_change_types; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.level_change_types (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_automatic boolean DEFAULT false,
    display_order integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE level_change_types; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.level_change_types IS 'Catálogo de tipos de cambio de nivel de asociados (PROMOTION, DEMOTION, MANUAL).';


--
-- Name: level_change_types_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.level_change_types_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: level_change_types_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.level_change_types_id_seq OWNED BY public.level_change_types.id;


--
-- Name: loan_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.loan_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_active boolean DEFAULT true,
    display_order integer DEFAULT 0,
    color_code character varying(7),
    icon_name character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE loan_statuses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.loan_statuses IS 'Catálogo de estados posibles para préstamos. Normaliza loans.status_id.';


--
-- Name: loan_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.loan_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: loan_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.loan_statuses_id_seq OWNED BY public.loan_statuses.id;


--
-- Name: payment_methods; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_methods (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    is_active boolean DEFAULT true,
    requires_reference boolean DEFAULT false,
    display_order integer DEFAULT 0,
    icon_name character varying(50),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE payment_methods; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.payment_methods IS 'Catálogo de métodos de pago aceptados (efectivo, transferencia, OXXO, etc.).';


--
-- Name: payment_methods_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_methods_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_methods_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_methods_id_seq OWNED BY public.payment_methods.id;


--
-- Name: payment_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_active boolean DEFAULT true,
    display_order integer DEFAULT 0,
    color_code character varying(7),
    icon_name character varying(50),
    is_real_payment boolean DEFAULT true,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE payment_statuses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.payment_statuses IS 'Catálogo de estados posibles para pagos. 12 estados consolidados (6 pendientes, 2 reales, 4 ficticios).';


--
-- Name: COLUMN payment_statuses.is_real_payment; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.payment_statuses.is_real_payment IS 'TRUE si el pago es dinero real cobrado, FALSE si es ficticio (absorbido, cancelado, perdonado).';


--
-- Name: payment_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.payment_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: payment_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.payment_statuses_id_seq OWNED BY public.payment_statuses.id;


--
-- Name: rate_profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rate_profiles (
    id integer NOT NULL,
    code character varying(50) NOT NULL,
    name character varying(100) NOT NULL,
    description text,
    calculation_type character varying(20) NOT NULL,
    interest_rate_percent numeric(5,3),
    enabled boolean DEFAULT true,
    is_recommended boolean DEFAULT false,
    display_order integer DEFAULT 0,
    min_amount numeric(12,2),
    max_amount numeric(12,2),
    valid_terms integer[],
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    created_by integer,
    updated_by integer,
    commission_rate_percent numeric(5,3),
    CONSTRAINT rate_profiles_calculation_type_check CHECK (((calculation_type)::text = ANY ((ARRAY['table_lookup'::character varying, 'formula'::character varying])::text[])))
);


--
-- Name: TABLE rate_profiles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.rate_profiles IS 'Perfiles de tasa configurables. Admin puede crear, editar, habilitar/deshabilitar perfiles.';


--
-- Name: COLUMN rate_profiles.code; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rate_profiles.code IS 'Código único interno. Ejemplos: legacy, standard, premium, custom_vip.';


--
-- Name: COLUMN rate_profiles.calculation_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rate_profiles.calculation_type IS 'Método de cálculo: table_lookup (busca en legacy_payment_table) o formula (usa tasa fija).';


--
-- Name: COLUMN rate_profiles.interest_rate_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rate_profiles.interest_rate_percent IS 'Tasa de interés quincenal que paga el CLIENTE. Ejemplo: 4.250 = 4.25% quincenal. NULL para perfil legacy (usa tabla).';


--
-- Name: COLUMN rate_profiles.is_recommended; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rate_profiles.is_recommended IS 'Si TRUE, este perfil aparece destacado como "Recomendado" en UI.';


--
-- Name: COLUMN rate_profiles.valid_terms; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rate_profiles.valid_terms IS 'Array de plazos permitidos en quincenas. NULL = permite cualquier plazo.';


--
-- Name: COLUMN rate_profiles.commission_rate_percent; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.rate_profiles.commission_rate_percent IS 'Tasa de comisión que cobra la empresa al ASOCIADO sobre cada pago. Ejemplo: 2.500 = 2.5% de comisión. NULL para perfil legacy.';


--
-- Name: rate_profiles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.rate_profiles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: rate_profiles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.rate_profiles_id_seq OWNED BY public.rate_profiles.id;


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text,
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE roles; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.roles IS 'Roles de usuario en el sistema (desarrollador, admin, asociado, cliente).';


--
-- Name: roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.roles_id_seq OWNED BY public.roles.id;


--
-- Name: statement_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.statement_statuses (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    description text NOT NULL,
    is_paid boolean DEFAULT false,
    display_order integer DEFAULT 0,
    color_code character varying(7),
    created_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp with time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- Name: TABLE statement_statuses; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.statement_statuses IS 'Catálogo de estados para cuentas de pago de asociados (GENERATED, PAID, OVERDUE).';


--
-- Name: statement_statuses_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.statement_statuses_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: statement_statuses_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.statement_statuses_id_seq OWNED BY public.statement_statuses.id;


--
-- Name: associate_levels id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.associate_levels ALTER COLUMN id SET DEFAULT nextval('public.associate_levels_id_seq'::regclass);


--
-- Name: config_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_types ALTER COLUMN id SET DEFAULT nextval('public.config_types_id_seq'::regclass);


--
-- Name: contract_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_statuses ALTER COLUMN id SET DEFAULT nextval('public.contract_statuses_id_seq'::regclass);


--
-- Name: cut_period_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cut_period_statuses ALTER COLUMN id SET DEFAULT nextval('public.cut_period_statuses_id_seq'::regclass);


--
-- Name: document_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_statuses ALTER COLUMN id SET DEFAULT nextval('public.document_statuses_id_seq'::regclass);


--
-- Name: document_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_types ALTER COLUMN id SET DEFAULT nextval('public.document_types_id_seq'::regclass);


--
-- Name: level_change_types id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.level_change_types ALTER COLUMN id SET DEFAULT nextval('public.level_change_types_id_seq'::regclass);


--
-- Name: loan_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_statuses ALTER COLUMN id SET DEFAULT nextval('public.loan_statuses_id_seq'::regclass);


--
-- Name: payment_methods id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods ALTER COLUMN id SET DEFAULT nextval('public.payment_methods_id_seq'::regclass);


--
-- Name: payment_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_statuses ALTER COLUMN id SET DEFAULT nextval('public.payment_statuses_id_seq'::regclass);


--
-- Name: rate_profiles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_profiles ALTER COLUMN id SET DEFAULT nextval('public.rate_profiles_id_seq'::regclass);


--
-- Name: roles id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles ALTER COLUMN id SET DEFAULT nextval('public.roles_id_seq'::regclass);


--
-- Name: statement_statuses id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statement_statuses ALTER COLUMN id SET DEFAULT nextval('public.statement_statuses_id_seq'::regclass);


--
-- Data for Name: associate_levels; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.associate_levels (id, name, max_loan_amount, credit_limit, description, min_clients, min_collection_rate, created_at, updated_at) FROM stdin;
1	Bronce	50000.00	25000.00	\N	0	0.00	2025-10-31 01:12:22.074569+00	2025-10-31 01:12:22.074569+00
2	Plata	100000.00	50000.00	\N	0	0.00	2025-10-31 01:12:22.074569+00	2025-10-31 01:12:22.074569+00
3	Oro	250000.00	125000.00	\N	0	0.00	2025-10-31 01:12:22.074569+00	2025-10-31 01:12:22.074569+00
4	Platino	600000.00	300000.00	\N	0	0.00	2025-10-31 01:12:22.074569+00	2025-10-31 01:12:22.074569+00
5	Diamante	1000000.00	500000.00	\N	0	0.00	2025-10-31 01:12:22.074569+00	2025-10-31 01:12:22.074569+00
\.


--
-- Data for Name: config_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.config_types (id, name, description, validation_regex, example_value, created_at, updated_at) FROM stdin;
1	STRING	Cadena de texto.	\N	Hola Mundo	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
2	NUMBER	Número entero o decimal.	^-?\\d+(\\.\\d+)?$	123.45	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
3	BOOLEAN	Valor booleano.	^(true|false)$	true	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
4	JSON	Objeto JSON válido.	\N	{"key": "value"}	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
5	URL	URL válida.	^https?://[^\\s]+$	https://ejemplo.com	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
6	EMAIL	Correo electrónico.	^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$	user@example.com	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
7	DATE	Fecha ISO 8601.	^\\d{4}-\\d{2}-\\d{2}$	2025-10-30	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
8	PERCENTAGE	Porcentaje 0-100.	^(100(\\.0+)?|\\d{1,2}(\\.\\d+)?)$	15.5	2025-10-31 01:12:22.085589+00	2025-10-31 01:12:22.085589+00
\.


--
-- Data for Name: contract_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_statuses (id, name, description, is_active, requires_signature, display_order, created_at, updated_at) FROM stdin;
1	draft	Contrato en borrador.	t	f	1	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
2	pending	Pendiente de firma del cliente.	t	t	2	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
3	signed	Firmado por el cliente.	t	f	3	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
4	active	Contrato activo y vigente.	t	f	4	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
5	completed	Contrato completado, préstamo liquidado.	t	f	5	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
6	cancelled	Contrato cancelado.	t	f	6	2025-10-31 01:12:22.078957+00	2025-10-31 01:12:22.078957+00
\.


--
-- Data for Name: cut_period_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cut_period_statuses (id, name, description, is_terminal, allows_payments, display_order, created_at, updated_at) FROM stdin;
1	PRELIMINARY	Período creado, en configuración.	f	f	1	2025-10-31 01:12:22.080292+00	2025-10-31 01:12:22.080292+00
2	ACTIVE	Período activo, permite operaciones.	f	t	2	2025-10-31 01:12:22.080292+00	2025-10-31 01:12:22.080292+00
3	REVIEW	En revisión contable.	f	f	3	2025-10-31 01:12:22.080292+00	2025-10-31 01:12:22.080292+00
4	LOCKED	Bloqueado para cierre.	f	f	4	2025-10-31 01:12:22.080292+00	2025-10-31 01:12:22.080292+00
5	CLOSED	Cerrado definitivamente.	t	f	5	2025-10-31 01:12:22.080292+00	2025-10-31 01:12:22.080292+00
\.


--
-- Data for Name: document_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_statuses (id, name, description, display_order, color_code, created_at, updated_at) FROM stdin;
1	PENDING	Documento cargado, pendiente de revisión.	1	#FFA500	2025-10-31 01:12:22.083043+00	2025-10-31 01:12:22.083043+00
2	UNDER_REVIEW	En proceso de revisión.	2	#2196F3	2025-10-31 01:12:22.083043+00	2025-10-31 01:12:22.083043+00
3	APPROVED	Documento aprobado.	3	#4CAF50	2025-10-31 01:12:22.083043+00	2025-10-31 01:12:22.083043+00
4	REJECTED	Documento rechazado.	4	#F44336	2025-10-31 01:12:22.083043+00	2025-10-31 01:12:22.083043+00
\.


--
-- Data for Name: document_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_types (id, name, description, is_required, created_at, updated_at) FROM stdin;
1	Identificación Oficial	INE, Pasaporte o Cédula Profesional	t	2025-10-31 01:12:22.088252+00	2025-10-31 01:12:22.088252+00
2	Comprobante de Domicilio	Recibo de luz, agua o predial	t	2025-10-31 01:12:22.088252+00	2025-10-31 01:12:22.088252+00
3	Comprobante de Ingresos	Estado de cuenta o constancia laboral	t	2025-10-31 01:12:22.088252+00	2025-10-31 01:12:22.088252+00
4	CURP	Clave Única de Registro de Población	f	2025-10-31 01:12:22.088252+00	2025-10-31 01:12:22.088252+00
5	Referencia Personal	Datos de contacto de referencia	f	2025-10-31 01:12:22.088252+00	2025-10-31 01:12:22.088252+00
\.


--
-- Data for Name: level_change_types; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.level_change_types (id, name, description, is_automatic, display_order, created_at, updated_at) FROM stdin;
1	PROMOTION	Promoción automática a nivel superior.	t	1	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
2	DEMOTION	Descenso por incumplimiento.	t	2	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
3	MANUAL	Cambio manual por admin.	f	3	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
4	INITIAL	Nivel inicial al registrarse.	f	4	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
5	REWARD	Promoción especial por logro.	f	5	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
6	PENALTY	Descenso por sanción.	f	6	2025-10-31 01:12:22.086922+00	2025-10-31 01:12:22.086922+00
\.


--
-- Data for Name: loan_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.loan_statuses (id, name, description, is_active, display_order, color_code, icon_name, created_at, updated_at) FROM stdin;
1	PENDING	Préstamo solicitado pero aún no aprobado ni desembolsado.	t	1	#FFA500	clock	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
2	APPROVED	Préstamo aprobado, listo para desembolso y generación de cronograma.	t	2	#4CAF50	check-circle	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
3	ACTIVE	Préstamo desembolsado y activo, con pagos en curso.	t	3	#2196F3	activity	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
4	COMPLETED	Préstamo completamente liquidado.	t	4	#00C853	check-all	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
5	PAID	Préstamo totalmente pagado (sinónimo de COMPLETED).	t	5	#00C853	check-all	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
6	DEFAULTED	Préstamo en mora o incumplimiento.	t	6	#F44336	alert-triangle	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
7	REJECTED	Solicitud rechazada por administrador.	t	7	#9E9E9E	x-circle	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
8	CANCELLED	Préstamo cancelado antes de completarse.	t	8	#757575	slash	2025-10-31 01:12:22.075733+00	2025-10-31 01:12:22.075733+00
\.


--
-- Data for Name: payment_methods; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_methods (id, name, description, is_active, requires_reference, display_order, icon_name, created_at, updated_at) FROM stdin;
1	CASH	Pago en efectivo.	t	f	1	dollar-sign	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
2	TRANSFER	Transferencia bancaria.	t	t	2	arrow-right-circle	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
3	CHECK	Cheque bancario.	t	t	3	file-text	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
4	PAYROLL_DEDUCTION	Descuento de nómina.	t	f	4	briefcase	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
5	CARD	Tarjeta débito/crédito.	t	t	5	credit-card	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
6	DEPOSIT	Depósito bancario.	t	t	6	inbox	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
7	OXXO	Pago en OXXO.	t	t	7	shopping-bag	2025-10-31 01:12:22.081669+00	2025-10-31 01:12:22.081669+00
\.


--
-- Data for Name: payment_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payment_statuses (id, name, description, is_active, display_order, color_code, icon_name, is_real_payment, created_at, updated_at) FROM stdin;
1	PENDING	Pago programado, aún no vence.	t	1	#9E9E9E	clock	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
2	DUE_TODAY	Pago vence hoy.	t	2	#FF9800	calendar	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
4	OVERDUE	Pago vencido, no pagado.	t	4	#F44336	alert-circle	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
5	PARTIAL	Pago parcial realizado.	t	5	#2196F3	pie-chart	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
6	IN_COLLECTION	En proceso de cobranza.	t	6	#9C27B0	phone	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
7	RESCHEDULED	Pago reprogramado.	t	7	#03A9F4	refresh-cw	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
3	PAID	Pago completado por cliente.	t	3	#4CAF50	check	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
8	PAID_PARTIAL	Pago parcial aceptado.	t	8	#8BC34A	check-circle	t	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
9	PAID_BY_ASSOCIATE	Pagado por asociado (cliente moroso).	t	9	#FF5722	user-x	f	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
10	PAID_NOT_REPORTED	Pago no reportado al cierre.	t	10	#FFC107	alert-triangle	f	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
11	FORGIVEN	Pago perdonado por administración.	t	11	#00BCD4	heart	f	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
12	CANCELLED	Pago cancelado.	t	12	#607D8B	x	f	2025-10-31 01:12:22.077324+00	2025-10-31 01:12:22.077324+00
\.


--
-- Data for Name: rate_profiles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rate_profiles (id, code, name, description, calculation_type, interest_rate_percent, enabled, is_recommended, display_order, min_amount, max_amount, valid_terms, created_at, updated_at, created_by, updated_by, commission_rate_percent) FROM stdin;
1	legacy	Tabla Histórica v2.0	Sistema actual con montos predefinidos en tabla. Totalmente editable por admin. Permite agregar nuevos montos como $7,500, $12,350, etc.	table_lookup	\N	t	f	1	\N	\N	{12}	2025-11-05 00:58:16.105135+00	2025-11-05 00:58:16.105135+00	\N	\N	\N
2	transition	Transición Suave 3.75%	Tasa reducida para facilitar adopción gradual. Cliente ahorra vs tabla actual. Ideal para primeros 6 meses de migración.	formula	3.750	t	f	2	\N	\N	{6,12,18,24}	2025-11-05 00:58:16.105135+00	2025-11-05 00:58:16.105135+00	\N	\N	2.500
3	standard	Estándar 4.25% - Recomendado	Balance óptimo entre competitividad y rentabilidad. Tasa ~51% total (12Q), similar al promedio actual. Recomendado para mayoría de casos.	formula	4.250	t	t	3	\N	\N	{3,6,9,12,15,18,21,24,30,36}	2025-11-05 00:58:16.105135+00	2025-11-05 00:58:16.105135+00	\N	\N	2.500
4	premium	Premium 4.5%	Tasa objetivo con máxima rentabilidad (54% total en 12Q). Mantiene competitividad vs mercado (60-80%). Activar desde mes 7+ de migración.	formula	4.500	f	f	4	\N	\N	{3,6,9,12,15,18,21,24,30,36}	2025-11-05 00:58:16.105135+00	2025-11-05 00:58:16.105135+00	\N	\N	2.500
5	custom	Personalizado	Tasa ajustable manualmente para casos especiales. Requiere aprobación de gerente/admin. Rango permitido: 2.0% - 6.0% quincenal.	formula	\N	t	f	5	\N	\N	\N	2025-11-05 00:58:16.105135+00	2025-11-05 00:58:16.105135+00	\N	\N	2.500
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, name, description, created_at) FROM stdin;
1	desarrollador	\N	2025-10-31 01:12:22.07323+00
2	administrador	\N	2025-10-31 01:12:22.07323+00
3	auxiliar_administrativo	\N	2025-10-31 01:12:22.07323+00
4	asociado	\N	2025-10-31 01:12:22.07323+00
5	cliente	\N	2025-10-31 01:12:22.07323+00
\.


--
-- Data for Name: statement_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.statement_statuses (id, name, description, is_paid, display_order, color_code, created_at, updated_at) FROM stdin;
1	GENERATED	Estado de cuenta generado.	f	1	#9E9E9E	2025-10-31 01:12:22.084329+00	2025-10-31 01:12:22.084329+00
2	SENT	Enviado al asociado.	f	2	#2196F3	2025-10-31 01:12:22.084329+00	2025-10-31 01:12:22.084329+00
3	PAID	Pagado completamente.	t	3	#4CAF50	2025-10-31 01:12:22.084329+00	2025-10-31 01:12:22.084329+00
4	PARTIAL_PAID	Pago parcial recibido.	f	4	#FF9800	2025-10-31 01:12:22.084329+00	2025-10-31 01:12:22.084329+00
5	OVERDUE	Vencido sin pagar.	f	5	#F44336	2025-10-31 01:12:22.084329+00	2025-10-31 01:12:22.084329+00
\.


--
-- Name: associate_levels_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.associate_levels_id_seq', 1, false);


--
-- Name: config_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.config_types_id_seq', 8, true);


--
-- Name: contract_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.contract_statuses_id_seq', 6, true);


--
-- Name: cut_period_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.cut_period_statuses_id_seq', 5, true);


--
-- Name: document_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_statuses_id_seq', 4, true);


--
-- Name: document_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.document_types_id_seq', 1, false);


--
-- Name: level_change_types_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.level_change_types_id_seq', 6, true);


--
-- Name: loan_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.loan_statuses_id_seq', 8, true);


--
-- Name: payment_methods_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_methods_id_seq', 7, true);


--
-- Name: payment_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.payment_statuses_id_seq', 1, false);


--
-- Name: rate_profiles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.rate_profiles_id_seq', 5, true);


--
-- Name: roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.roles_id_seq', 6, false);


--
-- Name: statement_statuses_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.statement_statuses_id_seq', 5, true);


--
-- Name: associate_levels associate_levels_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.associate_levels
    ADD CONSTRAINT associate_levels_name_key UNIQUE (name);


--
-- Name: associate_levels associate_levels_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.associate_levels
    ADD CONSTRAINT associate_levels_pkey PRIMARY KEY (id);


--
-- Name: config_types config_types_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_types
    ADD CONSTRAINT config_types_name_key UNIQUE (name);


--
-- Name: config_types config_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.config_types
    ADD CONSTRAINT config_types_pkey PRIMARY KEY (id);


--
-- Name: contract_statuses contract_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_statuses
    ADD CONSTRAINT contract_statuses_name_key UNIQUE (name);


--
-- Name: contract_statuses contract_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_statuses
    ADD CONSTRAINT contract_statuses_pkey PRIMARY KEY (id);


--
-- Name: cut_period_statuses cut_period_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cut_period_statuses
    ADD CONSTRAINT cut_period_statuses_name_key UNIQUE (name);


--
-- Name: cut_period_statuses cut_period_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cut_period_statuses
    ADD CONSTRAINT cut_period_statuses_pkey PRIMARY KEY (id);


--
-- Name: document_statuses document_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_statuses
    ADD CONSTRAINT document_statuses_name_key UNIQUE (name);


--
-- Name: document_statuses document_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_statuses
    ADD CONSTRAINT document_statuses_pkey PRIMARY KEY (id);


--
-- Name: document_types document_types_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_name_key UNIQUE (name);


--
-- Name: document_types document_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_types
    ADD CONSTRAINT document_types_pkey PRIMARY KEY (id);


--
-- Name: level_change_types level_change_types_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.level_change_types
    ADD CONSTRAINT level_change_types_name_key UNIQUE (name);


--
-- Name: level_change_types level_change_types_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.level_change_types
    ADD CONSTRAINT level_change_types_pkey PRIMARY KEY (id);


--
-- Name: loan_statuses loan_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_statuses
    ADD CONSTRAINT loan_statuses_name_key UNIQUE (name);


--
-- Name: loan_statuses loan_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.loan_statuses
    ADD CONSTRAINT loan_statuses_pkey PRIMARY KEY (id);


--
-- Name: payment_methods payment_methods_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_name_key UNIQUE (name);


--
-- Name: payment_methods payment_methods_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_methods
    ADD CONSTRAINT payment_methods_pkey PRIMARY KEY (id);


--
-- Name: payment_statuses payment_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_statuses
    ADD CONSTRAINT payment_statuses_name_key UNIQUE (name);


--
-- Name: payment_statuses payment_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_statuses
    ADD CONSTRAINT payment_statuses_pkey PRIMARY KEY (id);


--
-- Name: rate_profiles rate_profiles_code_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_profiles
    ADD CONSTRAINT rate_profiles_code_key UNIQUE (code);


--
-- Name: rate_profiles rate_profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_profiles
    ADD CONSTRAINT rate_profiles_pkey PRIMARY KEY (id);


--
-- Name: roles roles_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_name_key UNIQUE (name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: statement_statuses statement_statuses_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statement_statuses
    ADD CONSTRAINT statement_statuses_name_key UNIQUE (name);


--
-- Name: statement_statuses statement_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.statement_statuses
    ADD CONSTRAINT statement_statuses_pkey PRIMARY KEY (id);


--
-- Name: idx_config_types_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_config_types_name ON public.config_types USING btree (name);


--
-- Name: idx_contract_statuses_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_statuses_name ON public.contract_statuses USING btree (name);


--
-- Name: idx_cut_period_statuses_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cut_period_statuses_name ON public.cut_period_statuses USING btree (name);


--
-- Name: idx_document_statuses_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_statuses_name ON public.document_statuses USING btree (name);


--
-- Name: idx_level_change_types_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_level_change_types_name ON public.level_change_types USING btree (name);


--
-- Name: idx_loan_statuses_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loan_statuses_active ON public.loan_statuses USING btree (is_active);


--
-- Name: idx_loan_statuses_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_loan_statuses_name ON public.loan_statuses USING btree (name);


--
-- Name: idx_payment_methods_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_methods_name ON public.payment_methods USING btree (name);


--
-- Name: idx_payment_statuses_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_statuses_active ON public.payment_statuses USING btree (is_active);


--
-- Name: idx_payment_statuses_is_real; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_statuses_is_real ON public.payment_statuses USING btree (is_real_payment);


--
-- Name: idx_payment_statuses_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_payment_statuses_name ON public.payment_statuses USING btree (name);


--
-- Name: idx_rate_profiles_code; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_profiles_code ON public.rate_profiles USING btree (code);


--
-- Name: idx_rate_profiles_display; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_profiles_display ON public.rate_profiles USING btree (display_order);


--
-- Name: idx_rate_profiles_enabled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rate_profiles_enabled ON public.rate_profiles USING btree (enabled) WHERE (enabled = true);


--
-- Name: idx_statement_statuses_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_statement_statuses_name ON public.statement_statuses USING btree (name);


--
-- Name: config_types update_config_types_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_config_types_updated_at BEFORE UPDATE ON public.config_types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: contract_statuses update_contract_statuses_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_contract_statuses_updated_at BEFORE UPDATE ON public.contract_statuses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: cut_period_statuses update_cut_period_statuses_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_cut_period_statuses_updated_at BEFORE UPDATE ON public.cut_period_statuses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: document_statuses update_document_statuses_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_document_statuses_updated_at BEFORE UPDATE ON public.document_statuses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: level_change_types update_level_change_types_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_level_change_types_updated_at BEFORE UPDATE ON public.level_change_types FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: loan_statuses update_loan_statuses_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_loan_statuses_updated_at BEFORE UPDATE ON public.loan_statuses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: payment_methods update_payment_methods_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_payment_methods_updated_at BEFORE UPDATE ON public.payment_methods FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: statement_statuses update_statement_statuses_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_statement_statuses_updated_at BEFORE UPDATE ON public.statement_statuses FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: rate_profiles rate_profiles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_profiles
    ADD CONSTRAINT rate_profiles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: rate_profiles rate_profiles_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rate_profiles
    ADD CONSTRAINT rate_profiles_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict 0GPBwNbcC32jYWO3gBjVYgS7xkgFUmAnyDKmthK5Ulzy0lXUIpEc5ZgmstbZ1JJ

