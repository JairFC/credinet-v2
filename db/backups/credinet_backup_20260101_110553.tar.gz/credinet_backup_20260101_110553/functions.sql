CREATE OR REPLACE FUNCTION public.admin_mark_payment_status(p_payment_id integer, p_new_status_id integer, p_admin_user_id integer, p_notes text DEFAULT NULL::text)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_old_status_id INTEGER;
BEGIN
    -- Obtener estado actual
    SELECT status_id INTO v_old_status_id
    FROM payments
    WHERE id = p_payment_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Pago % no encontrado', p_payment_id;
    END IF;
    
    -- Actualizar estado del pago
    UPDATE payments
    SET 
        status_id = p_new_status_id,
        marked_by = p_admin_user_id,
        marked_at = CURRENT_TIMESTAMP,
        marking_notes = p_notes,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_payment_id;
    
    RAISE NOTICE 'Pago % marcado como estado % por usuario %', p_payment_id, p_new_status_id, p_admin_user_id;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.apply_debt_payment_v2(p_associate_profile_id integer, p_payment_amount numeric, p_payment_method_id integer, p_payment_reference character varying, p_registered_by integer, p_notes text DEFAULT NULL::text)
 RETURNS TABLE(payment_id integer, amount_applied numeric, remaining_debt numeric, applied_items jsonb, credit_released numeric)
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_user_id INTEGER;
    v_remaining_amount DECIMAL(12,2);
    v_debt_record RECORD;
    v_applied_items JSONB := '[]'::jsonb;
    v_item JSONB;
    v_amount_to_apply DECIMAL(12,2);
    v_total_applied DECIMAL(12,2) := 0;
    v_payment_id INTEGER;
    v_credit_before DECIMAL(12,2);
    v_credit_after DECIMAL(12,2);
BEGIN
    -- Validaciones iniciales
    IF p_payment_amount <= 0 THEN
        RAISE EXCEPTION 'El monto del abono debe ser mayor a 0';
    END IF;
    
    -- Obtener user_id y crédito actual
    SELECT ap.user_id, ap.credit_available
    INTO v_user_id, v_credit_before
    FROM associate_profiles ap WHERE ap.id = p_associate_profile_id;
    
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Perfil de asociado % no encontrado', p_associate_profile_id;
    END IF;
    
    v_remaining_amount := p_payment_amount;
    
    -- ⭐ APLICAR FIFO: liquidar deudas más antiguas primero desde accumulated_balances
    FOR v_debt_record IN (
        SELECT 
            aab.id,
            aab.accumulated_debt,
            aab.cut_period_id,
            aab.created_at,
            cp.cut_code
        FROM associate_accumulated_balances aab
        JOIN cut_periods cp ON cp.id = aab.cut_period_id
        WHERE aab.user_id = v_user_id
          AND aab.accumulated_debt > 0
        ORDER BY aab.created_at ASC, aab.id ASC  -- ⭐ FIFO por fecha
    )
    LOOP
        EXIT WHEN v_remaining_amount <= 0;
        
        IF v_remaining_amount >= v_debt_record.accumulated_debt THEN
            -- Liquidar completamente este item
            v_amount_to_apply := v_debt_record.accumulated_debt;
            
            UPDATE associate_accumulated_balances
            SET 
                accumulated_debt = 0,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = v_debt_record.id;
            
            v_remaining_amount := v_remaining_amount - v_amount_to_apply;
            
            v_item := jsonb_build_object(
                'accumulated_balance_id', v_debt_record.id,
                'cut_period_id', v_debt_record.cut_period_id,
                'period_code', v_debt_record.cut_code,
                'original_debt', v_debt_record.accumulated_debt,
                'amount_applied', v_amount_to_apply,
                'remaining_debt', 0,
                'fully_liquidated', true
            );
        ELSE
            -- Liquidar parcialmente
            v_amount_to_apply := v_remaining_amount;
            
            UPDATE associate_accumulated_balances
            SET 
                accumulated_debt = accumulated_debt - v_remaining_amount,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = v_debt_record.id;
            
            v_item := jsonb_build_object(
                'accumulated_balance_id', v_debt_record.id,
                'cut_period_id', v_debt_record.cut_period_id,
                'period_code', v_debt_record.cut_code,
                'original_debt', v_debt_record.accumulated_debt,
                'amount_applied', v_amount_to_apply,
                'remaining_debt', v_debt_record.accumulated_debt - v_remaining_amount,
                'fully_liquidated', false
            );
            
            v_remaining_amount := 0;
        END IF;
        
        v_applied_items := v_applied_items || v_item;
        v_total_applied := v_total_applied + v_amount_to_apply;
    END LOOP;
    
    -- Si no se aplicó nada (no había deuda), advertir
    IF v_total_applied = 0 THEN
        RAISE EXCEPTION 'No se encontró deuda pendiente para aplicar el abono';
    END IF;
    
    -- Insertar registro de pago
    INSERT INTO associate_debt_payments (
        associate_profile_id,
        payment_amount,
        payment_date,
        payment_method_id,
        payment_reference,
        registered_by,
        applied_breakdown_items,
        notes
    ) VALUES (
        p_associate_profile_id,
        v_total_applied,  -- Solo el monto realmente aplicado
        CURRENT_DATE,
        p_payment_method_id,
        p_payment_reference,
        p_registered_by,
        v_applied_items,
        CASE 
            WHEN v_remaining_amount > 0 THEN 
                COALESCE(p_notes, '') || ' [Sobrante no aplicado: ' || v_remaining_amount || ']'
            ELSE p_notes
        END
    )
    RETURNING id INTO v_payment_id;
    
    -- Sincronizar debt_balance en associate_profiles
    PERFORM sync_associate_debt_balance(p_associate_profile_id);
    
    -- Recalcular crédito disponible (liberar el monto pagado)
    UPDATE associate_profiles
    SET 
        credit_available = credit_available + v_total_applied,
        credit_used = credit_used - v_total_applied,
        credit_last_updated = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_associate_profile_id
    RETURNING credit_available INTO v_credit_after;
    
    -- Retornar resultado
    RETURN QUERY SELECT 
        v_payment_id,
        v_total_applied,
        (SELECT COALESCE(SUM(accumulated_debt), 0) FROM associate_accumulated_balances WHERE user_id = v_user_id),
        v_applied_items,
        v_credit_after - v_credit_before;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.apply_excess_to_debt_fifo(p_associate_profile_id integer, p_excess_amount numeric, p_payment_reference character varying)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_remaining_amount DECIMAL(12,2);
    v_debt_record RECORD;
BEGIN
    v_remaining_amount := p_excess_amount;
    
    -- Aplicar FIFO: liquidar deudas más antiguas primero
    FOR v_debt_record IN (
        SELECT id, amount
        FROM associate_debt_breakdown
        WHERE associate_profile_id = p_associate_profile_id
          AND is_liquidated = false
        ORDER BY created_at ASC, id ASC  -- ⭐ FIFO
    )
    LOOP
        EXIT WHEN v_remaining_amount <= 0;
        
        IF v_remaining_amount >= v_debt_record.amount THEN
            -- Liquidar completamente este item
            UPDATE associate_debt_breakdown
            SET 
                is_liquidated = true,
                liquidated_at = CURRENT_TIMESTAMP,
                liquidation_reference = p_payment_reference,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = v_debt_record.id;
            
            v_remaining_amount := v_remaining_amount - v_debt_record.amount;
            
            RAISE NOTICE 'Deuda % liquidada completamente (monto: %)', 
                         v_debt_record.id, v_debt_record.amount;
        ELSE
            -- Liquidar parcialmente (reducir monto del item)
            UPDATE associate_debt_breakdown
            SET 
                amount = amount - v_remaining_amount,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = v_debt_record.id;
            
            RAISE NOTICE 'Deuda % liquidada parcialmente (abono: %, restante: %)', 
                         v_debt_record.id, v_remaining_amount, v_debt_record.amount - v_remaining_amount;
            
            v_remaining_amount := 0;
        END IF;
    END LOOP;
    
    -- Actualizar debt_balance del asociado
    UPDATE associate_profiles
    SET 
        debt_balance = (
            SELECT COALESCE(SUM(amount), 0)
            FROM associate_debt_breakdown
            WHERE associate_profile_id = p_associate_profile_id
              AND is_liquidated = false
        ),
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_associate_profile_id;
    
    RAISE NOTICE 'Excedente aplicado: % (sobrante: %)', p_excess_amount - v_remaining_amount, v_remaining_amount;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.approve_defaulted_client_report(p_report_id integer, p_approved_by integer, p_cut_period_id integer)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_associate_profile_id INTEGER;
    v_loan_id INTEGER;
    v_client_user_id INTEGER;
    v_total_debt_amount DECIMAL(12,2);
    v_paid_by_associate_id INTEGER;
BEGIN
    -- Obtener datos del reporte
    SELECT 
        associate_profile_id,
        loan_id,
        client_user_id,
        total_debt_amount
    INTO 
        v_associate_profile_id,
        v_loan_id,
        v_client_user_id,
        v_total_debt_amount
    FROM defaulted_client_reports
    WHERE id = p_report_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Reporte % no encontrado', p_report_id;
    END IF;
    
    -- Obtener ID del estado PAID_BY_ASSOCIATE
    SELECT id INTO v_paid_by_associate_id FROM payment_statuses WHERE name = 'PAID_BY_ASSOCIATE';
    
    -- Actualizar reporte como aprobado
    UPDATE defaulted_client_reports
    SET status = 'APPROVED',
        approved_by = p_approved_by,
        approved_at = CURRENT_TIMESTAMP
    WHERE id = p_report_id;
    
    -- Marcar pagos del préstamo como PAID_BY_ASSOCIATE
    UPDATE payments
    SET status_id = v_paid_by_associate_id,
        updated_at = CURRENT_TIMESTAMP
    WHERE loan_id = v_loan_id
      AND status_id NOT IN (
          SELECT id FROM payment_statuses WHERE name IN ('PAID', 'PAID_BY_ASSOCIATE')
      );
    
    -- Crear registro de deuda en associate_debt_breakdown
    INSERT INTO associate_debt_breakdown (
        associate_profile_id,
        cut_period_id,
        debt_type,
        loan_id,
        client_user_id,
        amount,
        description,
        is_liquidated
    ) VALUES (
        v_associate_profile_id,
        p_cut_period_id,
        'DEFAULTED_CLIENT',
        v_loan_id,
        v_client_user_id,
        v_total_debt_amount,
        'Cliente moroso aprobado - Reporte #' || p_report_id,
        false
    );
    
    -- Actualizar debt_balance del asociado
    UPDATE associate_profiles
    SET debt_balance = debt_balance + v_total_debt_amount
    WHERE id = v_associate_profile_id;
    
    RAISE NOTICE '✅ Reporte % aprobado. Deuda de % agregada a asociado %', 
        p_report_id, v_total_debt_amount, v_associate_profile_id;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.audit_trigger_function()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    IF (TG_OP = 'DELETE') THEN
        INSERT INTO audit_log (table_name, record_id, operation, old_data)
        VALUES (TG_TABLE_NAME, OLD.id, 'DELETE', row_to_json(OLD)::jsonb);
        RETURN OLD;
    ELSIF (TG_OP = 'UPDATE') THEN
        INSERT INTO audit_log (table_name, record_id, operation, old_data, new_data)
        VALUES (TG_TABLE_NAME, NEW.id, 'UPDATE', row_to_json(OLD)::jsonb, row_to_json(NEW)::jsonb);
        RETURN NEW;
    ELSIF (TG_OP = 'INSERT') THEN
        INSERT INTO audit_log (table_name, record_id, operation, new_data)
        VALUES (TG_TABLE_NAME, NEW.id, 'INSERT', row_to_json(NEW)::jsonb);
        RETURN NEW;
    END IF;
    RETURN NULL;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.auto_generate_statements_at_midnight()
 RETURNS TABLE(period_code character varying, statements_generated integer, total_amount numeric)
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_current_day INTEGER;
    v_is_cut_day BOOLEAN;
    v_period_id INTEGER;
    v_period_code VARCHAR(20);
    v_count INTEGER;
    v_total NUMERIC(12,2);
BEGIN
    v_current_day := EXTRACT(DAY FROM CURRENT_DATE);
    
    -- Verificar si es día de corte (8 o 23)
    v_is_cut_day := v_current_day IN (8, 23);
    
    IF NOT v_is_cut_day THEN
        RAISE NOTICE 'Hoy no es día de corte (día %, esperado 8 o 23)', v_current_day;
        RETURN;
    END IF;
    
    -- Obtener periodo correspondiente a hoy (día de impresión)
    SELECT id, cut_code INTO v_period_id, v_period_code
    FROM cut_periods
    WHERE period_end_date + 1 = CURRENT_DATE;
    
    IF v_period_id IS NULL THEN
        RAISE EXCEPTION 'No se encontró periodo para hoy: %', CURRENT_DATE;
    END IF;
    
    RAISE NOTICE '🔄 Iniciando corte automático para periodo: %', v_period_code;
    
    -- Generar statements automáticos con estado DRAFT (ID 6)
    INSERT INTO associate_payment_statements (
        cut_period_id,
        user_id,
        statement_number,
        total_payments_count,
        total_amount_collected,
        total_commission_owed,
        commission_rate_applied,
        status_id,
        generated_date,
        due_date
    )
    SELECT 
        v_period_id,
        l.associate_user_id,
        CONCAT(v_period_code, '-A', l.associate_user_id) as statement_number,
        COUNT(p.id) as total_payments,
        SUM(p.expected_amount) as total_amount,
        SUM(p.commission_amount) as total_commission,
        l.commission_rate,
        6,  -- DRAFT
        CURRENT_DATE,
        CURRENT_DATE + INTERVAL '7 days'
    FROM payments p
    JOIN loans l ON p.loan_id = l.id
    WHERE p.cut_period_id = v_period_id
      AND p.status_id = 1  -- PENDING
      AND l.associate_user_id IS NOT NULL
    GROUP BY v_period_id, l.associate_user_id, v_period_code, l.commission_rate
    ON CONFLICT DO NOTHING;
    
    GET DIAGNOSTICS v_count = ROW_COUNT;
    
    -- Calcular total generado
    SELECT COALESCE(SUM(total_amount_collected), 0) INTO v_total
    FROM associate_payment_statements
    WHERE cut_period_id = v_period_id AND status_id = 6;
    
    RAISE NOTICE '✅ Corte automático completado: % statements en DRAFT, Total: $%',
        v_count, v_total;
    
    -- Retornar resumen
    RETURN QUERY SELECT v_period_code, v_count, v_total;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.calculate_first_payment_date(p_approval_date date)
 RETURNS date
 LANGUAGE plpgsql
 IMMUTABLE PARALLEL SAFE STRICT
AS $function$
DECLARE
    v_approval_day INTEGER;
    v_approval_year INTEGER;
    v_approval_month INTEGER;
    v_first_payment_date DATE;
    v_next_month_date DATE;
    v_last_day_current_month DATE;
BEGIN
    -- Extraer componentes de la fecha
    v_approval_day := EXTRACT(DAY FROM p_approval_date)::INTEGER;
    v_approval_year := EXTRACT(YEAR FROM p_approval_date)::INTEGER;
    v_approval_month := EXTRACT(MONTH FROM p_approval_date)::INTEGER;
    
    -- Pre-calcular fechas comunes
    v_next_month_date := p_approval_date + INTERVAL '1 month';
    v_last_day_current_month := (DATE_TRUNC('month', p_approval_date) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
    
    -- Aplicar lógica del doble calendario
    v_first_payment_date := CASE
        -- CASO 1: Aprobación días 1-7 → Primer pago día 15 del mes ACTUAL
        WHEN v_approval_day >= 1 AND v_approval_day < 8 THEN
            MAKE_DATE(v_approval_year, v_approval_month, 15)
        
        -- CASO 2: Aprobación días 8-22 → Primer pago ÚLTIMO día del mes ACTUAL
        WHEN v_approval_day >= 8 AND v_approval_day < 23 THEN
            v_last_day_current_month
        
        -- CASO 3: Aprobación día 23+ → Primer pago día 15 del mes SIGUIENTE
        WHEN v_approval_day >= 23 THEN
            MAKE_DATE(
                EXTRACT(YEAR FROM v_next_month_date)::INTEGER,
                EXTRACT(MONTH FROM v_next_month_date)::INTEGER,
                15
            )
        
        ELSE NULL
    END;
    
    -- Validaciones
    IF p_approval_date IS NULL THEN
        RAISE EXCEPTION 'La fecha de aprobación no puede ser NULL';
    END IF;
    
    IF v_approval_day < 1 OR v_approval_day > 31 THEN
        RAISE EXCEPTION 'Día de aprobación inválido: %. Debe estar entre 1 y 31.', v_approval_day;
    END IF;
    
    IF v_first_payment_date < p_approval_date THEN
        RAISE WARNING 'ALERTA: La fecha de primer pago (%) es anterior a la fecha de aprobación (%).',
            v_first_payment_date, p_approval_date;
    END IF;
    
    RETURN v_first_payment_date;
    
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Error al calcular primera fecha de pago para %: % (%)',
            p_approval_date, SQLERRM, SQLSTATE;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.calculate_late_fee_for_statement(p_statement_id integer)
 RETURNS numeric
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_total_payments_count INTEGER;
    v_total_commission_owed DECIMAL(12,2);
    v_late_fee DECIMAL(12,2);
BEGIN
    -- Obtener datos del statement
    SELECT total_payments_count, total_commission_owed
    INTO v_total_payments_count, v_total_commission_owed
    FROM associate_payment_statements
    WHERE id = p_statement_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Statement % no encontrado', p_statement_id;
    END IF;
    
    -- Aplicar regla: Si NO reportó ningún pago, mora del 30% sobre comisión
    IF v_total_payments_count = 0 AND v_total_commission_owed > 0 THEN
        v_late_fee := v_total_commission_owed * 0.30;
        RAISE NOTICE 'Mora del 30%% aplicada: % (comisión: %)', v_late_fee, v_total_commission_owed;
    ELSE
        v_late_fee := 0.00;
    END IF;
    
    RETURN ROUND(v_late_fee, 2);
END;
$function$
;
CREATE OR REPLACE FUNCTION public.calculate_loan_payment(p_amount numeric, p_term_biweeks integer, p_profile_code character varying)
 RETURNS TABLE(profile_code character varying, profile_name character varying, calculation_method character varying, interest_rate_percent numeric, commission_rate_percent numeric, biweekly_payment numeric, total_payment numeric, total_interest numeric, effective_rate_percent numeric, commission_per_payment numeric, total_commission numeric, associate_payment numeric, associate_total numeric)
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_profile RECORD;
    v_legacy_entry RECORD;
    v_factor DECIMAL(10,6);
    v_total DECIMAL(12,2);
    v_payment DECIMAL(10,2);
    v_commission_per_payment DECIMAL(10,2);
BEGIN
    -- Obtener perfil
    SELECT * INTO v_profile
    FROM rate_profiles
    WHERE code = p_profile_code AND enabled = true;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Perfil de tasa no encontrado o deshabilitado: %', p_profile_code;
    END IF;
    
    -- MÉTODO 1: Table Lookup (perfil legacy)
    IF v_profile.calculation_type = 'table_lookup' THEN
        SELECT * INTO v_legacy_entry
        FROM legacy_payment_table
        WHERE amount = p_amount AND term_biweeks = p_term_biweeks;
        
        IF NOT FOUND THEN
            RAISE EXCEPTION 'Monto % no encontrado en tabla legacy para plazo %Q', p_amount, p_term_biweeks;
        END IF;
        
        v_payment := v_legacy_entry.biweekly_payment;
        v_total := v_legacy_entry.total_payment;
        v_commission_per_payment := COALESCE(v_legacy_entry.commission_per_payment, 0);
        
        RETURN QUERY SELECT
            v_profile.code,
            v_profile.name,
            v_profile.calculation_type,
            v_legacy_entry.biweekly_rate_percent AS interest_rate,
            ROUND(((COALESCE(v_legacy_entry.commission_per_payment, 0) / NULLIF(v_payment, 0)) * 100)::NUMERIC, 3) AS commission_rate,
            v_payment,
            v_total,
            v_legacy_entry.total_interest,
            v_legacy_entry.effective_rate_percent,
            ROUND(v_commission_per_payment, 2),
            ROUND(COALESCE(v_legacy_entry.total_commission, 0), 2),
            ROUND(COALESCE(v_legacy_entry.associate_biweekly_payment, 0), 2),
            ROUND(COALESCE(v_legacy_entry.associate_total_payment, 0), 2);
        
        RETURN;
    END IF;
    
    -- MÉTODO 2: Formula (perfiles standard, custom)
    IF v_profile.calculation_type = 'formula' THEN
        IF v_profile.interest_rate_percent IS NULL THEN
            RAISE EXCEPTION 'Perfil % tipo formula requiere interest_rate_percent configurado', p_profile_code;
        END IF;
        
        IF v_profile.commission_rate_percent IS NULL THEN
            RAISE EXCEPTION 'Perfil % tipo formula requiere commission_rate_percent configurado', p_profile_code;
        END IF;
        
        -- Calcular pago del CLIENTE (interés simple)
        v_factor := 1 + (v_profile.interest_rate_percent / 100) * p_term_biweeks;
        v_total := p_amount * v_factor;
        v_payment := v_total / p_term_biweeks;
        
        -- ⭐ CAMBIO CRÍTICO: Comisión sobre el MONTO, no sobre el pago
        v_commission_per_payment := p_amount * (v_profile.commission_rate_percent / 100);
        
        RETURN QUERY SELECT
            v_profile.code,
            v_profile.name,
            v_profile.calculation_type,
            v_profile.interest_rate_percent,
            v_profile.commission_rate_percent,
            ROUND(v_payment, 2) AS biweekly_payment,
            ROUND(v_total, 2) AS total_payment,
            ROUND(v_total - p_amount, 2) AS total_interest,
            ROUND(((v_total - p_amount) / p_amount * 100)::NUMERIC, 2) AS effective_rate,
            ROUND(v_commission_per_payment, 2),
            ROUND(v_commission_per_payment * p_term_biweeks, 2),
            ROUND(v_payment - v_commission_per_payment, 2),
            ROUND((v_payment - v_commission_per_payment) * p_term_biweeks, 2);
        
        RETURN;
    END IF;
    
    RAISE EXCEPTION 'Tipo de cálculo no soportado: %', v_profile.calculation_type;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.calculate_loan_payment_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric)
 RETURNS TABLE(profile_code character varying, profile_name character varying, calculation_method character varying, interest_rate_percent numeric, commission_rate_percent numeric, biweekly_payment numeric, total_payment numeric, total_interest numeric, effective_rate_percent numeric, commission_per_payment numeric, total_commission numeric, associate_payment numeric, associate_total numeric)
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
DECLARE
    v_factor DECIMAL(10,6);
    v_total DECIMAL(12,2);
    v_payment DECIMAL(10,2);
    v_commission_per_payment DECIMAL(10,2);
BEGIN
    -- Calcular pago del CLIENTE (interés simple)
    v_factor := 1 + (p_interest_rate / 100) * p_term_biweeks;
    v_total := p_amount * v_factor;
    v_payment := v_total / p_term_biweeks;
    
    -- ⭐ CAMBIO CRÍTICO: Comisión sobre el MONTO, no sobre el pago
    v_commission_per_payment := p_amount * (p_commission_rate / 100);
    
    RETURN QUERY SELECT
        'custom'::VARCHAR(50),
        'Personalizado'::VARCHAR(100),
        'formula'::VARCHAR(20),
        p_interest_rate,
        p_commission_rate,
        ROUND(v_payment, 2) AS biweekly_payment,
        ROUND(v_total, 2) AS total_payment,
        ROUND(v_total - p_amount, 2) AS total_interest,
        ROUND(((v_total - p_amount) / p_amount * 100)::NUMERIC, 2) AS effective_rate,
        ROUND(v_commission_per_payment, 2),
        ROUND(v_commission_per_payment * p_term_biweeks, 2),
        ROUND(v_payment - v_commission_per_payment, 2),
        ROUND((v_payment - v_commission_per_payment) * p_term_biweeks, 2);
END;
$function$
;
CREATE OR REPLACE FUNCTION public.calculate_loan_remaining_balance(p_loan_id integer)
 RETURNS numeric
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_total_amount DECIMAL(12,2);
    v_total_paid DECIMAL(12,2);
    v_remaining DECIMAL(12,2);
BEGIN
    -- Obtener monto total del préstamo
    SELECT amount INTO v_total_amount
    FROM loans
    WHERE id = p_loan_id;
    
    IF v_total_amount IS NULL THEN
        RAISE EXCEPTION 'Préstamo con ID % no encontrado', p_loan_id;
    END IF;
    
    -- Calcular total pagado
    SELECT COALESCE(SUM(amount_paid), 0) INTO v_total_paid
    FROM payments
    WHERE loan_id = p_loan_id;
    
    v_remaining := v_total_amount - v_total_paid;
    
    -- No permitir saldo negativo
    IF v_remaining < 0 THEN
        v_remaining := 0;
    END IF;
    
    RETURN v_remaining;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.calculate_payment_preview(p_approval_timestamp timestamp with time zone DEFAULT CURRENT_TIMESTAMP, p_term_biweeks integer DEFAULT 12, p_amount numeric DEFAULT 100000.00)
 RETURNS TABLE(payment_number integer, payment_due_date date, payment_amount numeric, payment_type text, cut_period_estimated text)
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_approval_date DATE;
    v_approval_day INTEGER;
    v_current_payment_date DATE;
    v_payment_amount DECIMAL(12,2);
    i INTEGER;
BEGIN
    v_approval_date := p_approval_timestamp::DATE;
    v_approval_day := EXTRACT(DAY FROM v_approval_date);
    v_payment_amount := ROUND(p_amount / p_term_biweeks, 2);
    
    -- Calcular primera fecha usando el oráculo
    v_current_payment_date := calculate_first_payment_date(v_approval_date);
    
    -- Generar preview de todos los pagos
    FOR i IN 1..p_term_biweeks LOOP
        RETURN QUERY SELECT 
            i,
            v_current_payment_date,
            v_payment_amount,
            CASE 
                WHEN EXTRACT(DAY FROM v_current_payment_date) = 15 THEN 'DÍA_15'
                ELSE 'ÚLTIMO_DÍA'
            END::TEXT,
            CASE 
                WHEN EXTRACT(DAY FROM v_current_payment_date) <= 8 THEN 'CORTE_8_' || EXTRACT(MONTH FROM v_current_payment_date)::TEXT
                ELSE 'CORTE_23_' || EXTRACT(MONTH FROM v_current_payment_date)::TEXT
            END::TEXT;
        
        -- Alternar fechas: día 15 ↔ último día del mes
        IF EXTRACT(DAY FROM v_current_payment_date) = 15 THEN
            v_current_payment_date := (DATE_TRUNC('month', v_current_payment_date) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
        ELSE
            v_current_payment_date := MAKE_DATE(
                EXTRACT(YEAR FROM v_current_payment_date + INTERVAL '1 month')::INTEGER,
                EXTRACT(MONTH FROM v_current_payment_date + INTERVAL '1 month')::INTEGER,
                15
            );
        END IF;
    END LOOP;
    
    RETURN;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.check_associate_credit_available(p_associate_profile_id integer, p_requested_amount numeric)
 RETURNS boolean
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_credit_available DECIMAL(12,2);
    v_credit_limit DECIMAL(12,2);
    v_credit_used DECIMAL(12,2);
    v_debt_balance DECIMAL(12,2);
BEGIN
    -- Obtener datos del asociado
    SELECT credit_limit, credit_used, debt_balance
    INTO v_credit_limit, v_credit_used, v_debt_balance
    FROM associate_profiles
    WHERE id = p_associate_profile_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Perfil de asociado % no encontrado', p_associate_profile_id;
    END IF;
    
    -- Calcular crédito disponible
    v_credit_available := v_credit_limit - v_credit_used - v_debt_balance;
    
    -- Validar si hay crédito suficiente
    IF v_credit_available >= p_requested_amount THEN
        RETURN TRUE;
    ELSE
        RAISE NOTICE 'Crédito insuficiente. Disponible: %, Solicitado: %', v_credit_available, p_requested_amount;
        RETURN FALSE;
    END IF;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.close_period_and_accumulate_debt(p_cut_period_id integer, p_closed_by integer)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_period_start DATE;
    v_period_end DATE;
    v_paid_status_id INTEGER;
    v_paid_not_reported_id INTEGER;
    v_paid_by_associate_id INTEGER;
    v_total_payments_marked INTEGER := 0;
    v_unreported_count INTEGER := 0;
    v_morosos_count INTEGER := 0;
BEGIN
    -- Obtener fechas del período
    SELECT period_start_date, period_end_date
    INTO v_period_start, v_period_end
    FROM cut_periods
    WHERE id = p_cut_period_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Período de corte % no encontrado', p_cut_period_id;
    END IF;
    
    -- Obtener IDs de estados
    SELECT id INTO v_paid_status_id FROM payment_statuses WHERE name = 'PAID';
    SELECT id INTO v_paid_not_reported_id FROM payment_statuses WHERE name = 'PAID_NOT_REPORTED';
    SELECT id INTO v_paid_by_associate_id FROM payment_statuses WHERE name = 'PAID_BY_ASSOCIATE';
    
    RAISE NOTICE '🔒 Cerrando período %: % a %', p_cut_period_id, v_period_start, v_period_end;
    
    -- PASO 1: Marcar pagos reportados como PAID
    WITH updated AS (
        UPDATE payments
        SET status_id = v_paid_status_id,
            updated_at = CURRENT_TIMESTAMP
        WHERE cut_period_id = p_cut_period_id
          AND status_id NOT IN (v_paid_status_id, v_paid_not_reported_id, v_paid_by_associate_id)
          AND amount_paid > 0
        RETURNING id
    )
    SELECT COUNT(*) INTO v_total_payments_marked FROM updated;
    
    RAISE NOTICE '✅ Pagos reportados marcados como PAID: %', v_total_payments_marked;
    
    -- PASO 2: Marcar pagos NO reportados como PAID_NOT_REPORTED
    WITH updated AS (
        UPDATE payments
        SET status_id = v_paid_not_reported_id,
            updated_at = CURRENT_TIMESTAMP
        WHERE cut_period_id = p_cut_period_id
          AND status_id NOT IN (v_paid_status_id, v_paid_not_reported_id, v_paid_by_associate_id)
          AND (amount_paid = 0 OR amount_paid IS NULL)
        RETURNING id
    )
    SELECT COUNT(*) INTO v_unreported_count FROM updated;
    
    RAISE NOTICE '⚠️  Pagos NO reportados marcados como PAID_NOT_REPORTED: %', v_unreported_count;
    
    -- PASO 3: Marcar clientes morosos como PAID_BY_ASSOCIATE
    -- (Esta lógica se implementará cuando se aprueben reportes de morosidad)
    
    -- PASO 4: Actualizar estado del período
    UPDATE cut_periods
    SET status_id = (SELECT id FROM cut_period_statuses WHERE name = 'CLOSED'),
        closed_by = p_closed_by,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_cut_period_id;
    
    -- PASO 5: Acumular deuda en associate_debt_breakdown
    -- Por cada pago PAID_NOT_REPORTED, crear registro de deuda
    INSERT INTO associate_debt_breakdown (
        associate_profile_id,
        cut_period_id,
        debt_type,
        loan_id,
        client_user_id,
        amount,
        description,
        is_liquidated
    )
    SELECT 
        ap.id,
        p.cut_period_id,
        'UNREPORTED_PAYMENT',
        l.id,
        l.user_id,
        p.amount_paid,
        'Pago no reportado al cierre del período',
        false
    FROM payments p
    JOIN loans l ON p.loan_id = l.id
    JOIN associate_profiles ap ON l.associate_user_id = ap.user_id
    WHERE p.cut_period_id = p_cut_period_id
      AND p.status_id = v_paid_not_reported_id;
    
    -- PASO 6: Actualizar debt_balance en associate_profiles
    UPDATE associate_profiles ap
    SET debt_balance = (
        SELECT COALESCE(SUM(amount), 0)
        FROM associate_debt_breakdown adb
        WHERE adb.associate_profile_id = ap.id
          AND adb.is_liquidated = false
    );
    
    RAISE NOTICE '✅ Período % cerrado exitosamente', p_cut_period_id;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.detect_suspicious_payment_changes(p_days_back integer DEFAULT 7, p_min_changes integer DEFAULT 3)
 RETURNS TABLE(payment_id integer, loan_id integer, client_name text, total_changes bigint, last_change timestamp with time zone, status_sequence text)
 LANGUAGE plpgsql
 STABLE
AS $function$
BEGIN
    RETURN QUERY
    SELECT 
        p.id,
        p.loan_id,
        CONCAT(u.first_name, ' ', u.last_name),
        COUNT(psh.id),
        MAX(psh.changed_at),
        STRING_AGG(ps.name, ' → ' ORDER BY psh.changed_at)
    FROM payments p
    JOIN payment_status_history psh ON p.id = psh.payment_id
    JOIN payment_statuses ps ON psh.new_status_id = ps.id
    JOIN loans l ON p.loan_id = l.id
    JOIN users u ON l.user_id = u.id
    WHERE psh.changed_at >= CURRENT_TIMESTAMP - (p_days_back || ' days')::INTERVAL
    GROUP BY p.id, p.loan_id, u.first_name, u.last_name
    HAVING COUNT(psh.id) >= p_min_changes
    ORDER BY COUNT(psh.id) DESC, MAX(psh.changed_at) DESC;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.finalize_statements_manual(p_cut_period_id integer)
 RETURNS TABLE(finalized_count integer, total_finalized numeric, period_code character varying)
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_draft_count INTEGER;
    v_updated_count INTEGER;
    v_total NUMERIC(12,2);
    v_period_code VARCHAR(20);
BEGIN
    -- Obtener información del periodo
    SELECT cut_code INTO v_period_code
    FROM cut_periods
    WHERE id = p_cut_period_id;
    
    IF v_period_code IS NULL THEN
        RAISE EXCEPTION 'Periodo con ID % no encontrado', p_cut_period_id;
    END IF;
    
    -- Verificar que existan statements en DRAFT
    SELECT COUNT(*) INTO v_draft_count
    FROM associate_payment_statements
    WHERE cut_period_id = p_cut_period_id
      AND status_id = 6;  -- DRAFT
    
    IF v_draft_count = 0 THEN
        RAISE EXCEPTION 'No hay statements en DRAFT para finalizar en periodo %', v_period_code;
    END IF;
    
    RAISE NOTICE '🔒 Finalizando % statements en periodo %', v_draft_count, v_period_code;
    
    -- Cambiar estado de DRAFT (6) → FINALIZED (7)
    UPDATE associate_payment_statements
    SET 
        status_id = 7,  -- FINALIZED
        updated_at = CURRENT_TIMESTAMP
    WHERE cut_period_id = p_cut_period_id
      AND status_id = 6;
    
    GET DIAGNOSTICS v_updated_count = ROW_COUNT;
    
    -- Calcular total finalizado
    SELECT COALESCE(SUM(total_amount_collected), 0) INTO v_total
    FROM associate_payment_statements
    WHERE cut_period_id = p_cut_period_id AND status_id = 7;
    
    RAISE NOTICE '✅ Corte manual completado: % statements FINALIZADOS (bloqueados), Total: $%',
        v_updated_count, v_total;
    
    RAISE NOTICE '📧 TODO: Enviar notificaciones a asociados';
    
    -- Retornar resumen
    RETURN QUERY SELECT v_updated_count, v_total, v_period_code;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.generate_amortization_schedule(p_amount numeric, p_biweekly_payment numeric, p_term_biweeks integer, p_commission_rate numeric, p_start_date date)
 RETURNS TABLE(periodo integer, fecha_pago date, pago_cliente numeric, interes_cliente numeric, capital_cliente numeric, saldo_pendiente numeric, comision_socio numeric, pago_socio numeric, saldo_asociado numeric)
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_current_date DATE;
    v_balance DECIMAL(12,2);
    v_associate_balance DECIMAL(12,2); -- ✅ NUEVO
    v_total_interest DECIMAL(12,2);
    v_period_interest DECIMAL(10,2);
    v_period_principal DECIMAL(10,2);
    v_commission DECIMAL(10,2);
    v_payment_to_associate DECIMAL(10,2);
    v_is_day_15 BOOLEAN;
BEGIN
    -- Inicializar
    v_balance := p_amount;
    v_total_interest := (p_biweekly_payment * p_term_biweeks) - p_amount;
    v_current_date := p_start_date;
    
    -- Calcular comisión y pago al asociado (fijos por periodo)
    v_commission := p_amount * (p_commission_rate / 100);
    v_payment_to_associate := p_biweekly_payment - v_commission;
    
    -- Inicializar saldo asociado (Total a pagar por asociado)
    v_associate_balance := v_payment_to_associate * p_term_biweeks;

    -- Generar cronograma completo
    FOR v_period IN 1..p_term_biweeks LOOP
        -- Calcular interés y capital del período (distribución proporcional)
        v_period_interest := v_total_interest / p_term_biweeks;
        v_period_principal := p_biweekly_payment - v_period_interest;

        -- Actualizar saldo cliente
        v_balance := v_balance - v_period_principal;
        IF v_balance < 0.01 THEN v_balance := 0; END IF;
        
        -- Actualizar saldo asociado
        v_associate_balance := v_associate_balance - v_payment_to_associate;
        IF v_associate_balance < 0.01 THEN v_associate_balance := 0; END IF;

        -- Retornar fila
        RETURN QUERY SELECT
            v_period,
            v_current_date,
            p_biweekly_payment,
            ROUND(v_period_interest, 2),
            ROUND(v_period_principal, 2),
            ROUND(v_balance, 2),
            ROUND(v_commission, 2),
            ROUND(v_payment_to_associate, 2),
            ROUND(v_associate_balance, 2); -- ✅ RETORNAR NUEVO SALDO

        -- Calcular siguiente fecha
        v_is_day_15 := EXTRACT(DAY FROM v_current_date) = 15;

        IF v_is_day_15 THEN
            v_current_date := (DATE_TRUNC('month', v_current_date) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
        ELSE
            v_current_date := MAKE_DATE(
                EXTRACT(YEAR FROM v_current_date + INTERVAL '1 month')::INTEGER,
                EXTRACT(MONTH FROM v_current_date + INTERVAL '1 month')::INTEGER,
                15
            );
        END IF;
    END LOOP;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.generate_loan_summary(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric)
 RETURNS TABLE(capital numeric, plazo_quincenas integer, tasa_interes_quincenal numeric, tasa_comision numeric, pago_quincenal_cliente numeric, pago_total_cliente numeric, interes_total_cliente numeric, tasa_efectiva_cliente numeric, comision_por_pago numeric, comision_total_socio numeric, pago_quincenal_socio numeric, pago_total_socio numeric)
 LANGUAGE plpgsql
 IMMUTABLE
AS $function$
DECLARE
    v_factor DECIMAL(10,6);
    v_total_cliente DECIMAL(12,2);
    v_pago_q_cliente DECIMAL(10,2);
    v_interes_cliente DECIMAL(12,2);
    v_comision_por_pago DECIMAL(10,2);
    v_comision_total DECIMAL(12,2);
    v_pago_q_socio DECIMAL(10,2);
BEGIN
    -- Calcular CLIENTE (Interés Simple)
    v_factor := 1 + (p_interest_rate / 100) * p_term_biweeks;
    v_total_cliente := p_amount * v_factor;
    v_pago_q_cliente := v_total_cliente / p_term_biweeks;
    v_interes_cliente := v_total_cliente - p_amount;
    
    -- Calcular SOCIO (Comisión sobre pago del cliente)
    v_comision_por_pago := v_pago_q_cliente * (p_commission_rate / 100);
    v_comision_total := v_comision_por_pago * p_term_biweeks;
    v_pago_q_socio := v_pago_q_cliente - v_comision_por_pago;
    
    RETURN QUERY SELECT
        p_amount AS capital,
        p_term_biweeks AS plazo_quincenas,
        
        p_interest_rate AS tasa_interes_quincenal,
        p_commission_rate AS tasa_comision,
        
        ROUND(v_pago_q_cliente, 2) AS pago_quincenal_cliente,
        ROUND(v_total_cliente, 2) AS pago_total_cliente,
        ROUND(v_interes_cliente, 2) AS interes_total_cliente,
        ROUND(((v_interes_cliente / p_amount * 100)::NUMERIC), 2) AS tasa_efectiva_cliente,
        
        ROUND(v_comision_por_pago, 2) AS comision_por_pago,
        ROUND(v_comision_total, 2) AS comision_total_socio,
        ROUND(v_pago_q_socio, 2) AS pago_quincenal_socio,
        ROUND(v_pago_q_socio * p_term_biweeks, 2) AS pago_total_socio;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.generate_payment_schedule()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_approval_date DATE;
    v_first_payment_date DATE;
    v_approved_status_id INTEGER;
    v_pending_status_id INTEGER;
    v_amortization_row RECORD;
    v_period_id INTEGER;
    v_total_inserted INTEGER := 0;
    v_sum_expected DECIMAL(12,2) := 0;
    v_start_time TIMESTAMP;
    v_end_time TIMESTAMP;
    v_total_associate_payment DECIMAL(12,2);
    v_cumulative_associate_paid DECIMAL(12,2) := 0;
    v_commission_rate_for_function DECIMAL(10,4);
    v_payment_day INTEGER;
    v_target_cut_day INTEGER;
    v_month_name VARCHAR(3);
    v_year_str VARCHAR(4);
    v_target_cut_code VARCHAR(20);
BEGIN
    -- Get status IDs
    SELECT id INTO v_approved_status_id FROM loan_statuses WHERE name = 'APPROVED';
    SELECT id INTO v_pending_status_id FROM payment_statuses WHERE name = 'PENDING';

    IF v_approved_status_id IS NULL THEN
        RAISE EXCEPTION 'CRITICAL: loan_statuses.APPROVED not found';
    END IF;

    IF v_pending_status_id IS NULL THEN
        RAISE EXCEPTION 'CRITICAL: payment_statuses.PENDING not found';
    END IF;

    -- Only execute if loan just got approved
    IF NEW.status_id = v_approved_status_id
       AND (OLD.status_id IS NULL OR OLD.status_id != v_approved_status_id)
    THEN
        v_start_time := CLOCK_TIMESTAMP();

        -- Validations
        IF NEW.approved_at IS NULL THEN
            RAISE EXCEPTION 'CRITICAL: Loan % marked as APPROVED but approved_at is NULL', NEW.id;
        END IF;

        IF NEW.term_biweeks IS NULL OR NEW.term_biweeks <= 0 THEN
            RAISE EXCEPTION 'CRITICAL: Loan % has invalid term_biweeks: %', NEW.id, NEW.term_biweeks;
        END IF;

        IF NEW.biweekly_payment IS NULL THEN
            RAISE EXCEPTION 'CRITICAL: Loan % does not have biweekly_payment calculated', NEW.id;
        END IF;

        v_approval_date := NEW.approved_at::DATE;
        v_first_payment_date := calculate_first_payment_date(v_approval_date);

        -- FIX: Calculate correct commission rate for the function
        IF COALESCE(NEW.commission_per_payment, 0) > 0 AND NEW.amount > 0 THEN
            v_commission_rate_for_function := (NEW.commission_per_payment / NEW.amount) * 100;
        ELSE
            v_commission_rate_for_function := 0;
        END IF;

        RAISE NOTICE 'Generating schedule for loan %: Amount=$%, Term=%, Biweekly=$%, CommPerPmt=$%, Profile=%',
            NEW.id, NEW.amount, NEW.term_biweeks, NEW.biweekly_payment,
            COALESCE(NEW.commission_per_payment, 0), COALESCE(NEW.profile_code, 'N/A');

        -- Calculate total associate payment for this loan
        SELECT SUM(pago_socio) INTO v_total_associate_payment
        FROM generate_amortization_schedule(
            NEW.amount,
            NEW.biweekly_payment,
            NEW.term_biweeks,
            v_commission_rate_for_function,
            v_first_payment_date
        );

        -- Generate complete schedule with breakdown
        FOR v_amortization_row IN
            SELECT
                periodo,
                fecha_pago,
                pago_cliente,
                interes_cliente,
                capital_cliente,
                saldo_pendiente,
                comision_socio,
                pago_socio
            FROM generate_amortization_schedule(
                NEW.amount,
                NEW.biweekly_payment,
                NEW.term_biweeks,
                v_commission_rate_for_function,
                v_first_payment_date
            )
        LOOP
            -- NUEVA LÓGICA: Asignar período basado en día de vencimiento
            v_payment_day := EXTRACT(DAY FROM v_amortization_row.fecha_pago);
            
            IF v_payment_day = 15 THEN
                v_target_cut_day := 8;
            ELSE
                v_target_cut_day := 23;
            END IF;
            
            -- Construir el cut_code esperado: MonDD-YYYY
            v_month_name := TO_CHAR(v_amortization_row.fecha_pago, 'Mon');
            v_year_str := TO_CHAR(v_amortization_row.fecha_pago, 'YYYY');
            v_target_cut_code := v_month_name || LPAD(v_target_cut_day::text, 2, '0') || '-' || v_year_str;
            
            -- Buscar el período de corte por cut_code
            SELECT id INTO v_period_id
            FROM cut_periods
            WHERE cut_code = v_target_cut_code
            LIMIT 1;

            IF v_period_id IS NULL THEN
                RAISE WARNING 'No cut_period found with code %. Inserting with period_id = NULL',
                    v_target_cut_code;
            ELSE
                RAISE NOTICE 'Payment due % -> assigned to period % (%)',
                    v_amortization_row.fecha_pago, v_target_cut_code, v_period_id;
            END IF;

            -- Calculate cumulative associate paid
            v_cumulative_associate_paid := v_cumulative_associate_paid + v_amortization_row.pago_socio;

            -- Insert payment
            INSERT INTO payments (
                loan_id, payment_number, expected_amount, amount_paid,
                interest_amount, principal_amount, commission_amount, associate_payment,
                balance_remaining, associate_balance_remaining,
                payment_date, payment_due_date, is_late, status_id, cut_period_id,
                created_at, updated_at
            ) VALUES (
                NEW.id, v_amortization_row.periodo, v_amortization_row.pago_cliente, 0.00,
                v_amortization_row.interes_cliente, v_amortization_row.capital_cliente,
                v_amortization_row.comision_socio, v_amortization_row.pago_socio,
                v_amortization_row.saldo_pendiente, v_total_associate_payment - v_cumulative_associate_paid,
                v_amortization_row.fecha_pago, v_amortization_row.fecha_pago, false,
                v_pending_status_id, v_period_id, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
            );

            v_total_inserted := v_total_inserted + 1;
            v_sum_expected := v_sum_expected + v_amortization_row.pago_cliente;
        END LOOP;

        v_end_time := CLOCK_TIMESTAMP();

        IF v_total_inserted != NEW.term_biweeks THEN
            RAISE EXCEPTION 'INCONSISTENCY: Inserted % payments but expected %',
                v_total_inserted, NEW.term_biweeks;
        END IF;

        RAISE NOTICE 'Schedule generated: % payments, Total expected: $%, Time: % ms',
            v_total_inserted, v_sum_expected,
            EXTRACT(MILLISECONDS FROM (v_end_time - v_start_time));

    END IF;

    RETURN NEW;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'CRITICAL ERROR generating payment schedule for loan %: % (%). SQLState: %',
            NEW.id, SQLERRM, SQLSTATE, SQLSTATE;
        RETURN NULL;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.get_cut_period_for_payment(p_payment_date date)
 RETURNS integer
 LANGUAGE plpgsql
 IMMUTABLE STRICT
AS $function$
DECLARE
    v_period_id INTEGER;
    v_day INTEGER;
    v_month INTEGER;
    v_year INTEGER;
BEGIN
    v_day := EXTRACT(DAY FROM p_payment_date)::INTEGER;
    v_month := EXTRACT(MONTH FROM p_payment_date)::INTEGER;
    v_year := EXTRACT(YEAR FROM p_payment_date)::INTEGER;
    
    -- Determinar si es día 15 o último día del mes
    IF v_day = 15 THEN
        -- Pago día 15 → Buscar periodo que cierra día 7-8 (aproximado) ANTES del día 15
        SELECT id INTO v_period_id
        FROM cut_periods
        WHERE EXTRACT(DAY FROM period_end_date) BETWEEN 6 AND 8  -- Cierra ~día 7
          AND period_end_date < p_payment_date  -- Cierra ANTES del vencimiento
          AND EXTRACT(MONTH FROM period_end_date) = v_month  -- Mismo mes
          AND EXTRACT(YEAR FROM period_end_date) = v_year
        ORDER BY period_end_date DESC
        LIMIT 1;
        
        -- Si no encontró en el mismo mes, buscar a fin del mes anterior
        IF v_period_id IS NULL THEN
            SELECT id INTO v_period_id
            FROM cut_periods
            WHERE EXTRACT(DAY FROM period_end_date) BETWEEN 6 AND 8
              AND period_end_date < p_payment_date
              AND (
                  (EXTRACT(MONTH FROM period_end_date) = v_month - 1 AND EXTRACT(YEAR FROM period_end_date) = v_year) OR
                  (v_month = 1 AND EXTRACT(MONTH FROM period_end_date) = 12 AND EXTRACT(YEAR FROM period_end_date) = v_year - 1)
              )
            ORDER BY period_end_date DESC
            LIMIT 1;
        END IF;
        
    ELSE
        -- Pago último día → Buscar periodo que cierra día 22-23 ANTES del último día
        SELECT id INTO v_period_id
        FROM cut_periods
        WHERE EXTRACT(DAY FROM period_end_date) BETWEEN 21 AND 23  -- Cierra ~día 22
          AND period_end_date < p_payment_date  -- Cierra ANTES del vencimiento
          AND EXTRACT(MONTH FROM period_end_date) = v_month  -- Mismo mes
          AND EXTRACT(YEAR FROM period_end_date) = v_year
        ORDER BY period_end_date DESC
        LIMIT 1;
    END IF;
    
    -- Si aún no encontró, usar lógica de fallback (contención)
    IF v_period_id IS NULL THEN
        RAISE WARNING 'No se encontró periodo con cierre antes de %. Usando fallback.', p_payment_date;
        SELECT id INTO v_period_id
        FROM cut_periods
        WHERE period_start_date <= p_payment_date
          AND period_end_date >= p_payment_date
        ORDER BY period_start_date DESC
        LIMIT 1;
    END IF;
    
    RETURN v_period_id;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.get_debt_payment_detail(p_debt_payment_id integer)
 RETURNS TABLE(breakdown_id integer, cut_period_id integer, period_description character varying, original_amount numeric, amount_applied numeric, liquidated boolean, remaining_amount numeric)
 LANGUAGE plpgsql
AS $function$
BEGIN
    RETURN QUERY
    SELECT 
        (item->>'breakdown_id')::INTEGER AS breakdown_id,
        (item->>'cut_period_id')::INTEGER AS cut_period_id,
        COALESCE(
            cp.description,
            'Período ' || TO_CHAR(cp.start_date, 'DD/MM/YYYY') || ' - ' || TO_CHAR(cp.end_date, 'DD/MM/YYYY')
        ) AS period_description,
        (item->>'original_amount')::DECIMAL(12,2) AS original_amount,
        (item->>'amount_applied')::DECIMAL(12,2) AS amount_applied,
        (item->>'liquidated')::BOOLEAN AS liquidated,
        COALESCE((item->>'remaining_amount')::DECIMAL(12,2), 0) AS remaining_amount
    FROM associate_debt_payments adp
    CROSS JOIN jsonb_array_elements(adp.applied_breakdown_items) AS item
    LEFT JOIN cut_periods cp ON cp.id = (item->>'cut_period_id')::INTEGER
    WHERE adp.id = p_debt_payment_id;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.get_payment_history(p_payment_id integer)
 RETURNS TABLE(change_id integer, old_status character varying, new_status character varying, change_type character varying, changed_by_username character varying, change_reason text, changed_at timestamp with time zone)
 LANGUAGE plpgsql
 STABLE
AS $function$
BEGIN
    RETURN QUERY
    SELECT 
        psh.id,
        ps_old.name,
        ps_new.name,
        psh.change_type,
        u.username,
        psh.change_reason,
        psh.changed_at
    FROM payment_status_history psh
    LEFT JOIN payment_statuses ps_old ON psh.old_status_id = ps_old.id
    JOIN payment_statuses ps_new ON psh.new_status_id = ps_new.id
    LEFT JOIN users u ON psh.changed_by = u.id
    WHERE psh.payment_id = p_payment_id
    ORDER BY psh.changed_at DESC;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.handle_loan_approval_status()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_approved_status_id INTEGER;
    v_rejected_status_id INTEGER;
BEGIN
    -- Obtener IDs de estados APPROVED y REJECTED
    SELECT id INTO v_approved_status_id FROM loan_statuses WHERE name = 'APPROVED';
    SELECT id INTO v_rejected_status_id FROM loan_statuses WHERE name = 'REJECTED';
    
    -- Si cambió a APPROVED, setear timestamp
    IF NEW.status_id = v_approved_status_id AND (OLD.status_id IS NULL OR OLD.status_id != v_approved_status_id) AND NEW.approved_at IS NULL THEN
        NEW.approved_at = CURRENT_TIMESTAMP;
    END IF;
    
    -- Si cambió a REJECTED, setear timestamp  
    IF NEW.status_id = v_rejected_status_id AND (OLD.status_id IS NULL OR OLD.status_id != v_rejected_status_id) AND NEW.rejected_at IS NULL THEN
        NEW.rejected_at = CURRENT_TIMESTAMP;
    END IF;
    
    RETURN NEW;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.log_payment_status_change()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_change_type VARCHAR(50);
    v_changed_by INTEGER;
BEGIN
    -- Solo registrar si el status_id cambió
    IF OLD.status_id IS DISTINCT FROM NEW.status_id THEN
        
        -- Determinar tipo de cambio
        IF NEW.marked_by IS NOT NULL THEN
            v_change_type := 'MANUAL_ADMIN';
            v_changed_by := NEW.marked_by;
        ELSE
            v_change_type := 'AUTOMATIC';
            v_changed_by := NULL;
        END IF;
        
        -- Insertar en historial
        INSERT INTO payment_status_history (
            payment_id,
            old_status_id,
            new_status_id,
            change_type,
            changed_by,
            change_reason,
            changed_at
        ) VALUES (
            NEW.id,
            OLD.status_id,
            NEW.status_id,
            v_change_type,
            v_changed_by,
            NEW.marking_notes,
            CURRENT_TIMESTAMP
        );
    END IF;
    
    RETURN NEW;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.renew_loan(p_original_loan_id integer, p_new_amount numeric, p_new_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_created_by integer)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_client_user_id INTEGER;
    v_associate_user_id INTEGER;
    v_pending_balance DECIMAL(12,2);
    v_new_loan_id INTEGER;
    v_pending_status_id INTEGER;
BEGIN
    -- Obtener datos del préstamo original
    SELECT 
        user_id,
        associate_user_id
    INTO 
        v_client_user_id,
        v_associate_user_id
    FROM loans
    WHERE id = p_original_loan_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Préstamo original % no encontrado', p_original_loan_id;
    END IF;
    
    -- Calcular saldo pendiente
    v_pending_balance := calculate_loan_remaining_balance(p_original_loan_id);
    
    -- Obtener ID del estado PENDING
    SELECT id INTO v_pending_status_id FROM loan_statuses WHERE name = 'PENDING';
    
    -- Crear nuevo préstamo
    INSERT INTO loans (
        user_id,
        associate_user_id,
        amount,
        interest_rate,
        commission_rate,
        term_biweeks,
        status_id,
        notes,
        created_at
    ) VALUES (
        v_client_user_id,
        v_associate_user_id,
        p_new_amount,
        p_interest_rate,
        p_commission_rate,
        p_new_term_biweeks,
        v_pending_status_id,
        'Renovación de préstamo #' || p_original_loan_id || '. Saldo pendiente: ' || v_pending_balance,
        CURRENT_TIMESTAMP
    ) RETURNING id INTO v_new_loan_id;
    
    -- Registrar la renovación
    INSERT INTO loan_renewals (
        original_loan_id,
        renewed_loan_id,
        renewal_date,
        pending_balance,
        new_amount,
        reason,
        created_by
    ) VALUES (
        p_original_loan_id,
        v_new_loan_id,
        CURRENT_DATE,
        v_pending_balance,
        p_new_amount,
        'Renovación estándar',
        p_created_by
    );
    
    RAISE NOTICE '✅ Préstamo % renovado como préstamo %. Saldo pendiente: %, Nuevo monto: %',
        p_original_loan_id, v_new_loan_id, v_pending_balance, p_new_amount;
    
    RETURN v_new_loan_id;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.report_defaulted_client(p_associate_profile_id integer, p_loan_id integer, p_reported_by integer, p_total_debt_amount numeric, p_evidence_details text, p_evidence_file_path character varying DEFAULT NULL::character varying)
 RETURNS integer
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_client_user_id INTEGER;
    v_report_id INTEGER;
BEGIN
    -- Obtener ID del cliente desde el préstamo
    SELECT user_id INTO v_client_user_id
    FROM loans
    WHERE id = p_loan_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Préstamo % no encontrado', p_loan_id;
    END IF;
    
    -- Insertar reporte de morosidad
    INSERT INTO defaulted_client_reports (
        associate_profile_id,
        loan_id,
        client_user_id,
        reported_by,
        total_debt_amount,
        evidence_details,
        evidence_file_path,
        status
    ) VALUES (
        p_associate_profile_id,
        p_loan_id,
        v_client_user_id,
        p_reported_by,
        p_total_debt_amount,
        p_evidence_details,
        p_evidence_file_path,
        'PENDING'
    ) RETURNING id INTO v_report_id;
    
    RAISE NOTICE '📋 Reporte de morosidad creado: ID %, Cliente %, Deuda: %', 
        v_report_id, v_client_user_id, p_total_debt_amount;
    
    RETURN v_report_id;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.revert_last_payment_change(p_payment_id integer, p_admin_user_id integer, p_reason text)
 RETURNS void
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_last_old_status_id INTEGER;
    v_current_status_id INTEGER;
BEGIN
    -- Obtener estado actual
    SELECT status_id INTO v_current_status_id
    FROM payments
    WHERE id = p_payment_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Pago % no encontrado', p_payment_id;
    END IF;
    
    -- Obtener el estado anterior (último cambio)
    SELECT old_status_id INTO v_last_old_status_id
    FROM payment_status_history
    WHERE payment_id = p_payment_id
    ORDER BY changed_at DESC
    LIMIT 1;
    
    IF v_last_old_status_id IS NULL THEN
        RAISE EXCEPTION 'No hay historial previo para revertir el pago %', p_payment_id;
    END IF;
    
    -- Revertir al estado anterior
    UPDATE payments
    SET 
        status_id = v_last_old_status_id,
        marked_by = p_admin_user_id,
        marked_at = CURRENT_TIMESTAMP,
        marking_notes = 'REVERSIÓN: ' || p_reason,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_payment_id;
    
    RAISE NOTICE 'Pago % revertido de estado % a estado % por usuario %', 
        p_payment_id, v_current_status_id, v_last_old_status_id, p_admin_user_id;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.simulate_loan(p_amount numeric, p_term_biweeks integer, p_profile_code character varying, p_approval_date date DEFAULT CURRENT_DATE)
 RETURNS TABLE(payment_number integer, payment_date date, cut_period_code character varying, client_payment numeric, associate_payment numeric, commission_amount numeric, remaining_balance numeric, associate_remaining_balance numeric)
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_calc RECORD;
    v_current_date DATE;
    v_balance DECIMAL(12,2);
    v_associate_balance DECIMAL(12,2); -- ✅ NUEVO
    v_cut_code VARCHAR(20);
    v_period_capital DECIMAL(12,2);
    v_period_id INTEGER;
    i INTEGER;
BEGIN
    -- Obtener cálculos del perfil
    SELECT * INTO v_calc
    FROM calculate_loan_payment(p_amount, p_term_biweeks, p_profile_code);

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Perfil % no encontrado', p_profile_code;
    END IF;

    v_current_date := calculate_first_payment_date(p_approval_date);
    v_balance := p_amount;
    
    -- Inicializar saldo asociado
    v_associate_balance := v_calc.associate_payment * p_term_biweeks;

    v_period_capital := p_amount / p_term_biweeks;

    FOR i IN 1..p_term_biweeks LOOP
        v_period_id := get_cut_period_for_payment(v_current_date);

        IF v_period_id IS NOT NULL THEN
            SELECT cut_code INTO v_cut_code FROM cut_periods WHERE id = v_period_id;
        ELSE
            v_cut_code := EXTRACT(YEAR FROM v_current_date)::TEXT || '-Q' || LPAD(CEIL(EXTRACT(DOY FROM v_current_date) / 15)::TEXT, 2, '0');
        END IF;

        v_balance := v_balance - v_period_capital;
        IF v_balance < 0.01 THEN v_balance := 0; END IF;
        
        -- Actualizar saldo asociado
        v_associate_balance := v_associate_balance - v_calc.associate_payment;
        IF v_associate_balance < 0.01 THEN v_associate_balance := 0; END IF;

        RETURN QUERY SELECT
            i::INTEGER,
            v_current_date::DATE,
            v_cut_code::VARCHAR(20),
            v_calc.biweekly_payment::DECIMAL(10,2),
            v_calc.associate_payment::DECIMAL(10,2),
            v_calc.commission_per_payment::DECIMAL(10,2),
            v_balance::DECIMAL(12,2),
            v_associate_balance::DECIMAL(12,2); -- ✅ RETORNAR

        IF EXTRACT(DAY FROM v_current_date) = 15 THEN
            v_current_date := (DATE_TRUNC('month', v_current_date) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
        ELSE
            v_current_date := MAKE_DATE(
                EXTRACT(YEAR FROM v_current_date + INTERVAL '1 month')::INTEGER,
                EXTRACT(MONTH FROM v_current_date + INTERVAL '1 month')::INTEGER,
                15
            );
        END IF;
    END LOOP;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.simulate_loan_complete(p_amount numeric, p_term_biweeks integer, p_profile_code character varying, p_approval_date date DEFAULT CURRENT_DATE)
 RETURNS TABLE(section_type character varying, label character varying, value_text character varying, value_numeric numeric, payment_num integer, payment_date date, cut_code character varying, client_pay numeric, associate_pay numeric, commission numeric, balance numeric)
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_calc RECORD;
    v_profile RECORD;
BEGIN
    -- Obtener información del perfil y cálculos
    SELECT 
        rp.name as profile_name,
        c.*
    INTO v_calc
    FROM calculate_loan_payment(p_amount, p_term_biweeks, p_profile_code) c
    JOIN rate_profiles rp ON rp.code = p_profile_code;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Perfil % no encontrado o deshabilitado', p_profile_code;
    END IF;
    
    -- =========================================================================
    -- SECCIÓN 1: RESUMEN DEL PRÉSTAMO
    -- =========================================================================
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20),
        'Perfil'::VARCHAR(100),
        v_calc.profile_name::VARCHAR(100),
        NULL::DECIMAL(12,2),
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20), 'Monto Solicitado'::VARCHAR(100),
        ('$' || p_amount::TEXT)::VARCHAR(100), p_amount,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20), 'Plazo'::VARCHAR(100),
        (p_term_biweeks || ' quincenas')::VARCHAR(100), p_term_biweeks::DECIMAL(12,2),
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20), 'Tasa de Interés'::VARCHAR(100),
        (v_calc.interest_rate_percent || '%')::VARCHAR(100), v_calc.interest_rate_percent,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20), 'Tasa de Comisión'::VARCHAR(100),
        (v_calc.commission_rate_percent || '%')::VARCHAR(100), v_calc.commission_rate_percent,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'RESUMEN'::VARCHAR(20), 'Fecha de Aprobación'::VARCHAR(100),
        TO_CHAR(p_approval_date, 'DD/MM/YYYY')::VARCHAR(100), NULL::DECIMAL(12,2),
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    -- Totales
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Pago Quincenal Cliente'::VARCHAR(100),
        ('$' || v_calc.biweekly_payment::TEXT)::VARCHAR(100), v_calc.biweekly_payment,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Total a Pagar (Cliente)'::VARCHAR(100),
        ('$' || v_calc.total_payment::TEXT)::VARCHAR(100), v_calc.total_payment,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Pago Quincenal Asociado'::VARCHAR(100),
        ('$' || v_calc.associate_payment::TEXT)::VARCHAR(100), v_calc.associate_payment,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Total Asociado → CrediCuenta'::VARCHAR(100),
        ('$' || v_calc.associate_total::TEXT)::VARCHAR(100), v_calc.associate_total,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Comisión por Pago'::VARCHAR(100),
        ('$' || v_calc.commission_per_payment::TEXT)::VARCHAR(100), v_calc.commission_per_payment,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    RETURN QUERY SELECT
        'TOTALES'::VARCHAR(20), 'Comisión Total Asociado'::VARCHAR(100),
        ('$' || v_calc.total_commission::TEXT)::VARCHAR(100), v_calc.total_commission,
        NULL::INTEGER, NULL::DATE, NULL::VARCHAR(20),
        NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(10,2), NULL::DECIMAL(12,2);
    
    -- =========================================================================
    -- SECCIÓN 2: TABLA DE AMORTIZACIÓN
    -- =========================================================================
    RETURN QUERY 
    SELECT 
        'AMORTIZACIÓN'::VARCHAR(20),
        NULL::VARCHAR(100),
        NULL::VARCHAR(100),
        NULL::DECIMAL(12,2),
        s.payment_number,
        s.payment_date,
        s.cut_period_code,
        s.client_payment,
        s.associate_payment,
        s.commission_amount,
        s.remaining_balance
    FROM simulate_loan(p_amount, p_term_biweeks, p_profile_code, p_approval_date) s;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.simulate_loan_custom(p_amount numeric, p_term_biweeks integer, p_interest_rate numeric, p_commission_rate numeric, p_approval_date date DEFAULT CURRENT_DATE)
 RETURNS TABLE(payment_number integer, payment_date date, cut_period_code character varying, client_payment numeric, associate_payment numeric, commission_amount numeric, remaining_balance numeric)
 LANGUAGE plpgsql
 STABLE
AS $function$
DECLARE
    v_calc RECORD;
    v_current_date DATE;
    v_balance DECIMAL(12,2);
    v_cut_code VARCHAR(20);
    v_period_capital DECIMAL(12,2);
    i INTEGER;
BEGIN
    -- Obtener cálculos con tasas custom
    SELECT * INTO v_calc
    FROM calculate_loan_payment_custom(p_amount, p_term_biweeks, p_interest_rate, p_commission_rate);
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Error al calcular préstamo custom';
    END IF;
    
    -- Calcular primera fecha de pago usando el oráculo
    v_current_date := calculate_first_payment_date(p_approval_date);
    v_balance := p_amount;
    
    -- Calcular abono a capital por periodo (interés distribuido uniformemente)
    v_period_capital := p_amount / p_term_biweeks;
    
    -- Generar tabla de amortización
    FOR i IN 1..p_term_biweeks LOOP
        -- ⭐ CORRECCIÓN CRÍTICA: Buscar período de corte REAL donde cae el pago
        -- Un pago pertenece al período donde payment_date está entre start y end
        SELECT cp.cut_code INTO v_cut_code
        FROM cut_periods cp
        WHERE v_current_date >= cp.period_start_date 
          AND v_current_date <= cp.period_end_date
        LIMIT 1;
        
        -- Si no encuentra período (ej: simulación muy futura), usar código genérico
        IF v_cut_code IS NULL THEN
            -- Formato: YYYY-QXX (año-número quincenal)
            v_cut_code := EXTRACT(YEAR FROM v_current_date)::TEXT || '-Q' || 
                LPAD(CEIL(EXTRACT(DOY FROM v_current_date) / 15)::TEXT, 2, '0');
        END IF;
        
        -- Calcular saldo restante (disminuye por el abono a capital)
        v_balance := v_balance - v_period_capital;
        IF v_balance < 0.01 THEN
            v_balance := 0;
        END IF;
        
        RETURN QUERY SELECT
            i,
            v_current_date,
            v_cut_code,
            v_calc.biweekly_payment,
            v_calc.associate_payment,
            v_calc.commission_per_payment,
            v_balance;
        
        -- ⭐ LÓGICA DEL CALENDARIO: Alternar entre día 15 y último día del mes
        IF EXTRACT(DAY FROM v_current_date) = 15 THEN
            -- Si estamos en día 15, siguiente pago es el último día del mes ACTUAL
            v_current_date := (DATE_TRUNC('month', v_current_date) + INTERVAL '1 month' - INTERVAL '1 day')::DATE;
        ELSE
            -- Si estamos en último día, siguiente pago es el 15 del mes SIGUIENTE
            v_current_date := MAKE_DATE(
                EXTRACT(YEAR FROM v_current_date + INTERVAL '1 month')::INTEGER,
                EXTRACT(MONTH FROM v_current_date + INTERVAL '1 month')::INTEGER,
                15
            );
        END IF;
    END LOOP;
    
    RETURN;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.sync_associate_debt_balance(p_associate_profile_id integer)
 RETURNS numeric
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_user_id INTEGER;
    v_total_debt DECIMAL(12,2);
BEGIN
    -- Obtener user_id del perfil
    SELECT user_id INTO v_user_id
    FROM associate_profiles WHERE id = p_associate_profile_id;
    
    IF v_user_id IS NULL THEN
        RAISE EXCEPTION 'Associate profile % not found', p_associate_profile_id;
    END IF;
    
    -- Calcular deuda total desde accumulated_balances
    SELECT COALESCE(SUM(accumulated_debt), 0)
    INTO v_total_debt
    FROM associate_accumulated_balances
    WHERE user_id = v_user_id;
    
    -- Actualizar debt_balance en associate_profiles
    UPDATE associate_profiles
    SET 
        debt_balance = v_total_debt,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = p_associate_profile_id;
    
    RETURN v_total_debt;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.trigger_update_associate_credit_on_level_change()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_new_credit_limit DECIMAL(12,2);
BEGIN
    IF NEW.level_id != OLD.level_id THEN
        SELECT credit_limit INTO v_new_credit_limit
        FROM associate_levels
        WHERE id = NEW.level_id;
        
        UPDATE associate_profiles
        SET credit_limit = v_new_credit_limit,
            credit_last_updated = CURRENT_TIMESTAMP
        WHERE id = NEW.id;
        
        RAISE NOTICE 'Límite de crédito del asociado % actualizado a %', NEW.id, v_new_credit_limit;
    END IF;
    
    RETURN NEW;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.trigger_update_associate_credit_on_loan_approval()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_associate_profile_id INTEGER;
    v_approved_status_id INTEGER;
BEGIN
    SELECT id INTO v_approved_status_id FROM loan_statuses WHERE name = 'APPROVED';
    
    IF NEW.status_id = v_approved_status_id AND (OLD.status_id IS NULL OR OLD.status_id != v_approved_status_id) THEN
        IF NEW.associate_user_id IS NOT NULL THEN
            SELECT id INTO v_associate_profile_id
            FROM associate_profiles
            WHERE user_id = NEW.associate_user_id;
            
            IF v_associate_profile_id IS NOT NULL THEN
                UPDATE associate_profiles
                SET credit_used = credit_used + NEW.amount,
                    credit_last_updated = CURRENT_TIMESTAMP
                WHERE id = v_associate_profile_id;
                
                RAISE NOTICE 'Crédito del asociado % actualizado: +%', v_associate_profile_id, NEW.amount;
            END IF;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.trigger_update_associate_credit_on_payment()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_associate_user_id INTEGER;
    v_associate_profile_id INTEGER;
    v_amount_diff DECIMAL(12,2);
BEGIN
    IF NEW.amount_paid != OLD.amount_paid THEN
        SELECT associate_user_id INTO v_associate_user_id
        FROM loans
        WHERE id = NEW.loan_id;
        
        IF v_associate_user_id IS NOT NULL THEN
            SELECT id INTO v_associate_profile_id
            FROM associate_profiles
            WHERE user_id = v_associate_user_id;
            
            IF v_associate_profile_id IS NOT NULL THEN
                v_amount_diff := NEW.amount_paid - OLD.amount_paid;
                
                UPDATE associate_profiles
                SET credit_used = GREATEST(credit_used - v_amount_diff, 0),
                    credit_last_updated = CURRENT_TIMESTAMP
                WHERE id = v_associate_profile_id;
                
                RAISE NOTICE 'Crédito del asociado % actualizado por pago: -%', v_associate_profile_id, v_amount_diff;
            END IF;
        END IF;
    END IF;
    
    RETURN NEW;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.update_legacy_payment_table_timestamp()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.update_statement_on_payment()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_total_paid DECIMAL(12,2);
    v_total_owed DECIMAL(12,2);
    v_remaining DECIMAL(12,2);
    v_new_status_id INTEGER;
    v_associate_profile_id INTEGER;
BEGIN
    -- Calcular total pagado (suma de todos los abonos)
    SELECT COALESCE(SUM(payment_amount), 0)
    INTO v_total_paid
    FROM associate_statement_payments
    WHERE statement_id = NEW.statement_id;

    -- Obtener total adeudado a CrediCuenta (nuevo campo con nombre correcto)
    SELECT
        aps.total_to_credicuenta + aps.late_fee_amount,
        ap.id
    INTO v_total_owed, v_associate_profile_id
    FROM associate_payment_statements aps
    JOIN associate_profiles ap ON aps.user_id = ap.user_id
    WHERE aps.id = NEW.statement_id;

    IF v_total_owed IS NULL THEN
        RAISE EXCEPTION 'Statement % no encontrado', NEW.statement_id;
    END IF;

    v_remaining := v_total_owed - v_total_paid;

    -- Determinar nuevo estado
    IF v_remaining <= 0 THEN
        SELECT id INTO v_new_status_id FROM statement_statuses WHERE name = 'PAID';
    ELSIF v_total_paid > 0 THEN
        SELECT id INTO v_new_status_id FROM statement_statuses WHERE name = 'PARTIAL_PAID';
    END IF;

    -- Actualizar statement
    UPDATE associate_payment_statements
    SET paid_amount = v_total_paid,
        paid_date = CASE WHEN v_remaining <= 0 THEN CURRENT_DATE ELSE paid_date END,
        status_id = COALESCE(v_new_status_id, status_id),
        updated_at = CURRENT_TIMESTAMP
    WHERE id = NEW.statement_id;

    -- Liberar crédito del asociado
    UPDATE associate_profiles
    SET debt_balance = GREATEST(debt_balance - NEW.payment_amount, 0),
        credit_last_updated = CURRENT_TIMESTAMP
    WHERE id = v_associate_profile_id;

    RAISE NOTICE '💰 Statement #% | Pagado: $% | Debe: $% | Restante: $%',
        NEW.statement_id, v_total_paid, v_total_owed, v_remaining;

    RETURN NEW;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
 RETURNS trigger
 LANGUAGE plpgsql
AS $function$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.validate_loan_calculated_fields(p_loan_id integer)
 RETURNS TABLE(campo text, valor_actual numeric, valor_esperado numeric, diferencia numeric, es_valido boolean)
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_loan RECORD;
BEGIN
    -- Obtener datos del préstamo
    SELECT 
        amount, term_biweeks, biweekly_payment, total_payment,
        total_interest, commission_per_payment, associate_payment
    INTO v_loan
    FROM loans
    WHERE id = p_loan_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Préstamo % no encontrado', p_loan_id;
    END IF;
    
    -- Validar total_payment = biweekly_payment * term_biweeks
    IF v_loan.total_payment IS NOT NULL AND v_loan.biweekly_payment IS NOT NULL THEN
        RETURN QUERY SELECT 
            'total_payment'::TEXT,
            v_loan.total_payment,
            v_loan.biweekly_payment * v_loan.term_biweeks,
            v_loan.total_payment - (v_loan.biweekly_payment * v_loan.term_biweeks),
            ABS(v_loan.total_payment - (v_loan.biweekly_payment * v_loan.term_biweeks)) < 1.00;
    END IF;
    
    -- Validar total_interest = total_payment - amount
    IF v_loan.total_interest IS NOT NULL AND v_loan.total_payment IS NOT NULL THEN
        RETURN QUERY SELECT 
            'total_interest'::TEXT,
            v_loan.total_interest,
            v_loan.total_payment - v_loan.amount,
            v_loan.total_interest - (v_loan.total_payment - v_loan.amount),
            ABS(v_loan.total_interest - (v_loan.total_payment - v_loan.amount)) < 1.00;
    END IF;
    
    -- Validar associate_payment = biweekly_payment - commission_per_payment
    IF v_loan.associate_payment IS NOT NULL AND v_loan.biweekly_payment IS NOT NULL THEN
        RETURN QUERY SELECT 
            'associate_payment'::TEXT,
            v_loan.associate_payment,
            v_loan.biweekly_payment - COALESCE(v_loan.commission_per_payment, 0),
            v_loan.associate_payment - (v_loan.biweekly_payment - COALESCE(v_loan.commission_per_payment, 0)),
            ABS(v_loan.associate_payment - (v_loan.biweekly_payment - COALESCE(v_loan.commission_per_payment, 0))) < 0.10;
    END IF;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.validate_loan_payment_schedule(p_loan_id integer)
 RETURNS TABLE(validacion text, valor numeric, esperado numeric, diferencia numeric, es_valido boolean, detalle text)
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_loan RECORD;
    v_payment_count INTEGER;
    v_sum_expected DECIMAL;
    v_sum_interest DECIMAL;
    v_sum_principal DECIMAL;
    v_sum_commission DECIMAL;
    v_last_balance DECIMAL;
    v_numbers_ok BOOLEAN;
BEGIN
    -- Obtener datos del préstamo
    SELECT 
        id, amount, term_biweeks, total_payment, total_interest,
        total_commission, biweekly_payment
    INTO v_loan
    FROM loans
    WHERE id = p_loan_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Préstamo % no encontrado', p_loan_id;
    END IF;
    
    -- Contar pagos generados
    SELECT COUNT(*) INTO v_payment_count
    FROM payments
    WHERE loan_id = p_loan_id;
    
    -- Validar: Cantidad de pagos = term_biweeks
    RETURN QUERY SELECT 
        'Cantidad de pagos'::TEXT,
        v_payment_count::DECIMAL,
        v_loan.term_biweeks::DECIMAL,
        (v_payment_count - v_loan.term_biweeks)::DECIMAL,
        v_payment_count = v_loan.term_biweeks,
        format('Se esperaban %s pagos, se encontraron %s', v_loan.term_biweeks, v_payment_count);
    
    -- Validar: payment_number son secuenciales (1, 2, 3, ..., N)
    SELECT COUNT(*) = v_payment_count INTO v_numbers_ok
    FROM (
        SELECT payment_number
        FROM payments
        WHERE loan_id = p_loan_id
        ORDER BY payment_number
    ) t
    WHERE payment_number BETWEEN 1 AND v_payment_count;
    
    RETURN QUERY SELECT 
        'Números secuenciales'::TEXT,
        CASE WHEN v_numbers_ok THEN 1::DECIMAL ELSE 0::DECIMAL END,
        1::DECIMAL,
        CASE WHEN v_numbers_ok THEN 0::DECIMAL ELSE 1::DECIMAL END,
        v_numbers_ok,
        CASE WHEN v_numbers_ok 
            THEN 'Los números de pago son secuenciales (1..N)'
            ELSE 'Los números de pago NO son secuenciales'
        END;
    
    -- Calcular sumas
    SELECT 
        COALESCE(SUM(expected_amount), 0),
        COALESCE(SUM(interest_amount), 0),
        COALESCE(SUM(principal_amount), 0),
        COALESCE(SUM(commission_amount), 0)
    INTO v_sum_expected, v_sum_interest, v_sum_principal, v_sum_commission
    FROM payments
    WHERE loan_id = p_loan_id;
    
    -- Validar: SUM(expected_amount) = loans.total_payment
    IF v_loan.total_payment IS NOT NULL THEN
        RETURN QUERY SELECT 
            'SUM(expected) = total_payment'::TEXT,
            v_sum_expected,
            v_loan.total_payment,
            v_sum_expected - v_loan.total_payment,
            ABS(v_sum_expected - v_loan.total_payment) < 1.00,
            format('Suma de pagos esperados: $%s, Total préstamo: $%s', v_sum_expected, v_loan.total_payment);
    END IF;
    
    -- Validar: SUM(interest_amount) = loans.total_interest
    IF v_loan.total_interest IS NOT NULL THEN
        RETURN QUERY SELECT 
            'SUM(interest) = total_interest'::TEXT,
            v_sum_interest,
            v_loan.total_interest,
            v_sum_interest - v_loan.total_interest,
            ABS(v_sum_interest - v_loan.total_interest) < 1.00,
            format('Suma de intereses: $%s, Total interés préstamo: $%s', v_sum_interest, v_loan.total_interest);
    END IF;
    
    -- Validar: SUM(principal_amount) = loans.amount
    RETURN QUERY SELECT 
        'SUM(principal) = amount'::TEXT,
        v_sum_principal,
        v_loan.amount,
        v_sum_principal - v_loan.amount,
        ABS(v_sum_principal - v_loan.amount) < 1.00,
        format('Suma de abonos a capital: $%s, Capital préstamo: $%s', v_sum_principal, v_loan.amount);
    
    -- Validar: SUM(commission_amount) = loans.total_commission
    IF v_loan.total_commission IS NOT NULL THEN
        RETURN QUERY SELECT 
            'SUM(commission) = total_commission'::TEXT,
            v_sum_commission,
            v_loan.total_commission,
            v_sum_commission - v_loan.total_commission,
            ABS(v_sum_commission - v_loan.total_commission) < 1.00,
            format('Suma de comisiones: $%s, Total comisión préstamo: $%s', v_sum_commission, v_loan.total_commission);
    END IF;
    
    -- Validar: Último pago tiene balance_remaining = 0
    SELECT balance_remaining INTO v_last_balance
    FROM payments
    WHERE loan_id = p_loan_id
    ORDER BY payment_number DESC
    LIMIT 1;
    
    IF v_last_balance IS NOT NULL THEN
        RETURN QUERY SELECT 
            'Último pago balance = 0'::TEXT,
            v_last_balance,
            0::DECIMAL,
            v_last_balance,
            ABS(v_last_balance) < 0.10,
            format('El saldo después del último pago es: $%s (debe ser $0.00)', v_last_balance);
    END IF;
END;
$function$
;
CREATE OR REPLACE FUNCTION public.validate_payment_breakdown(p_payment_id integer)
 RETURNS TABLE(validacion text, valor_actual numeric, valor_esperado numeric, diferencia numeric, es_valido boolean)
 LANGUAGE plpgsql
AS $function$
DECLARE
    v_payment RECORD;
BEGIN
    -- Obtener datos del pago
    SELECT 
        payment_number, expected_amount, interest_amount, principal_amount,
        commission_amount, associate_payment, amount_paid, balance_remaining
    INTO v_payment
    FROM payments
    WHERE id = p_payment_id;
    
    IF NOT FOUND THEN
        RAISE EXCEPTION 'Pago % no encontrado', p_payment_id;
    END IF;
    
    -- Validar expected_amount = interest_amount + principal_amount
    IF v_payment.expected_amount IS NOT NULL AND v_payment.interest_amount IS NOT NULL AND v_payment.principal_amount IS NOT NULL THEN
        RETURN QUERY SELECT 
            'expected = interest + principal'::TEXT,
            v_payment.expected_amount,
            v_payment.interest_amount + v_payment.principal_amount,
            v_payment.expected_amount - (v_payment.interest_amount + v_payment.principal_amount),
            ABS(v_payment.expected_amount - (v_payment.interest_amount + v_payment.principal_amount)) < 0.10;
    END IF;
    
    -- Validar associate_payment = expected_amount - commission_amount
    IF v_payment.associate_payment IS NOT NULL AND v_payment.expected_amount IS NOT NULL AND v_payment.commission_amount IS NOT NULL THEN
        RETURN QUERY SELECT 
            'associate = expected - commission'::TEXT,
            v_payment.associate_payment,
            v_payment.expected_amount - v_payment.commission_amount,
            v_payment.associate_payment - (v_payment.expected_amount - v_payment.commission_amount),
            ABS(v_payment.associate_payment - (v_payment.expected_amount - v_payment.commission_amount)) < 0.10;
    END IF;
    
    -- Validar amount_paid <= expected_amount (permitir sobrepago de hasta 100)
    IF v_payment.amount_paid IS NOT NULL AND v_payment.expected_amount IS NOT NULL THEN
        RETURN QUERY SELECT 
            'paid <= expected'::TEXT,
            v_payment.amount_paid,
            v_payment.expected_amount,
            v_payment.amount_paid - v_payment.expected_amount,
            v_payment.amount_paid <= v_payment.expected_amount + 100.00;
    END IF;
END;
$function$
;
